﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameServer.Model
{
    //用户表的数据模型
    class User
    {
        public int id { get; set; }
        public string userName { get; set; }
        public string passWord { get; set; }

        public User(int _id,string _username,string _password)
        {
            this.id = _id;
            this.userName = _username;
            this.passWord = _password;
        }
    }
}
