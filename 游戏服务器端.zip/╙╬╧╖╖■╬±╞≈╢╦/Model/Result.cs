﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameServer.Model
{
    class Result
    {
        public int id { get; set; }
        public int userId { get; set; }
        public int totalCount { get; set; }
        public int winCount { get; set; }
        public Result(int _id,int _userid,int _total,int _win)
        {
            id = _id;
            userId = _userid;
            totalCount = _total;
            winCount = _win;
        }

    }
}
