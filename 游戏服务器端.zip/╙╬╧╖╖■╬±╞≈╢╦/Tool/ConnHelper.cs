﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace GameServer.Tool
{
    class ConnHelper
    {
       
        private const string defultStr = "datasource=localhost;port=3306;dataBase=graduation_project;user=root;password=root;SslMode=None";
        public static MySqlConnection Connection(string connectionStr=defultStr)
        {
            MySqlConnection conn = new MySqlConnection(connectionStr);
            try
            {
                conn.Open();
                return conn;
            }
            catch (Exception e)
            {

                Console.WriteLine("打开数据库异常"+e);
                return null;
            }
          
        }
        public static void CloseConnection(MySqlConnection conn)
        {
            if (conn != null)
            { conn.Close(); }
            else
            {
                Console.WriteLine("连接不能为空");
            }
       
        }
    }
}
