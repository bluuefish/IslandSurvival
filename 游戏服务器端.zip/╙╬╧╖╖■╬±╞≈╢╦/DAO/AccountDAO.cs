﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using GameServer.Model;
using Common;

namespace GameServer.DAO
{
    class AccountDAO
    {
        ////验证数据是否正确
        //public User VerifyUser(MySqlConnection conn,string username,string password)
        //{
        //    MySqlDataReader reader = null;
        //    try
        //    {
        //        MySqlCommand cmd = new MySqlCommand("select * from playerinfo where name=@username and password=@password", conn); 
        //        cmd.Parameters.AddWithValue("username", username);
        //        cmd.Parameters.AddWithValue("password", password);  //避免数据恶意注入
        //        reader = cmd.ExecuteReader();  //执行该命令
        //        if(reader.Read())
        //        {
        //            int id = reader.GetInt32("id");

        //            return new User(id, username, password);


        //        }
        //        else
        //        {
        //            return null;
        //        }

        //    }
        //    catch (Exception e)
        //    {
        //        Console.WriteLine(e);
        //    }
        //    finally
        //    {
        //        if (reader != null)
        //            reader.Close();
        //    }
        //    return null;
           

        //}

        //验证数据是否正确
        public AccountInfo VerifyUser(MySqlConnection conn, string username, string password)
        {
            MySqlDataReader reader = null;
            try
            {
                MySqlCommand cmd = new MySqlCommand("select * from account where accountname=@username and accountpassword=@password", conn);
                cmd.Parameters.AddWithValue("username", username);
                cmd.Parameters.AddWithValue("password", password);  //避免数据恶意注入
                reader = cmd.ExecuteReader();  //执行该命令
                if (reader.Read())
                {
                    int id = reader.GetInt32("idaccount");
                    return new AccountInfo(id, username, password);
                }
                else
                {
                    return null;
                }

            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
            finally
            {
                if (reader != null)
                    reader.Close();
            }
            return null;


        }

        ////验证用户名是否已经注册
        //public bool GetUserByUsername(MySqlConnection conn, string username)
        //{
        //    MySqlDataReader reader = null;
        //    try
        //    {

        //        MySqlCommand cmd = new MySqlCommand("select * from playerinfo where name=@username", conn);
        //        cmd.Parameters.AddWithValue("username", username);
        //        reader = cmd.ExecuteReader();
        //        if (reader.HasRows)
        //        {
        //            return true;
        //        }
        //        else
        //            return false;
        //    }
        //    catch (Exception e)
        //    {

        //        Console.WriteLine(e);
        //    }
        //    finally
        //    {
        //        if (reader != null) reader.Close();
        //    }
        //    return false;
        //}

        //验证用户名是否已经注册
        public bool GetAccountByAccountname(MySqlConnection conn, string accountname)
        {
            MySqlDataReader reader = null;
            try
            {

                MySqlCommand cmd = new MySqlCommand("select * from account where accountname=@accountname", conn);
                cmd.Parameters.AddWithValue("accountname", accountname);
                reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    return true;
                }
                else
                    return false;
            }
            catch (Exception e)
            {

                Console.WriteLine(e);
            }
            finally
            {
                if (reader != null) reader.Close();
            }
            return false;
        }
        ////添加数据
        //public void AddUserInfo(MySqlConnection conn, string username, string password)
        //{
        //    try
        //    {
        //        MySqlCommand cmd = new MySqlCommand("insert into playerinfo set name=@username , password=@password", conn);
        //        cmd.Parameters.AddWithValue("username", username);
        //        cmd.Parameters.AddWithValue("password", password);
        //        cmd.ExecuteNonQuery();
        //    }
        //    catch (Exception e)
        //    {

        //        Console.WriteLine(e);
        //    }
           

        //}
        //添加账户数据
        public void AddAccountInfo(MySqlConnection conn, string accountname, string password)
        {
            try
            {
                MySqlCommand cmd = new MySqlCommand("insert into account set accountname=@accountname, accountpassword=@password", conn);
                cmd.Parameters.AddWithValue("accountname", accountname);
                cmd.Parameters.AddWithValue("password", password);
                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {

                Console.WriteLine(e);
            }


        }
    }
}
