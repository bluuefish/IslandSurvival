﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using GameServer.Model;
using Common;

namespace GameServer.DAO
{
    class UserDAO
    {
        //public Result GetResultByUserId(MySqlConnection conn,int _userid)
        //{
        //    MySqlDataReader reader=null;
        //    try
        //    {
        //        MySqlCommand cmm = new MySqlCommand("select * from resultinfo where userid=@userid", conn);
        //        cmm.Parameters.AddWithValue("userid", _userid);
        //        reader = cmm.ExecuteReader();
        //        if (reader.Read())
        //        {
        //            int id = reader.GetInt32("id");
        //            int total = reader.GetInt32("totalcount");
        //            int win = reader.GetInt32("wincount");
        //            return new Result(id, _userid, total, win);
        //        }
        //        else
        //        {
        //            return new Result(-1, _userid, 0, 0);
        //        }
        //    }
        //    catch (Exception e)
        //    {
        //        Console.WriteLine("在GetResultByUserid的时候出现异常：" + e);
        //    }
        //    finally
        //    {
        //        if (reader != null) reader.Close();
        //    }
        //    return null;
        //}

        /// <summary>
        /// 根据传入的账号id得到该账号的游戏数据
        /// </summary>
        /// <param name="conn"></param>
        /// <param name="accoutId"></param>
        /// <returns></returns>
        public UserInfo GetUserInfoByAccountId(MySqlConnection conn, int accountId)
        {
            MySqlDataReader reader = null;
            try
            {
                MySqlCommand cmm = new MySqlCommand("select * from user where accountid=@accountId", conn);
                cmm.Parameters.AddWithValue("accountId", accountId);
                reader = cmm.ExecuteReader();
                if (reader.Read())
                {
                    int id = reader.GetInt32("iduser");
                    int total = reader.GetInt32("totalcount");
                    int win = reader.GetInt32("wincount");
                    int treasure = reader.GetInt32("treasure");
                    return new  UserInfo(id, accountId, total, win,treasure);
                }
                else
                {
                    return new UserInfo(-1, accountId, 0, 0, 0);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("在GetResultByUserid的时候出现异常：" + e);
            }
            finally
            {
                if (reader != null) reader.Close();
            }
            return null;
        }

        //添加战绩到数据库中
        //public void UpdateOrAddResult(MySqlConnection conn,Result res)
        //{ 
        //    try
        //    {
        //        MySqlCommand cmm = null;
        //        if (res.id<=-1)
        //        {
        //            //没有战绩时执行插入语句
        //            cmm = new MySqlCommand("insert into resultinfo set totalcount=@totalcount ,wincount=@wincount,userid=@userid", conn);
        //        }
        //        else
        //        {
        //            //有战绩时执行更新语句
        //            cmm = new MySqlCommand("update  resultinfo set totalcount=@totalcount ,wincount=@wincount where userid=@userid", conn);
        //        }
        //        cmm.Parameters.AddWithValue("totalcount", res.totalCount);
        //        cmm.Parameters.AddWithValue("wincount", res.winCount);
        //        cmm.Parameters.AddWithValue("userid", res.userId);
        //        cmm.ExecuteNonQuery();
        //        if(res.id<=1)
        //        {
        //            Result remp = GetResultByUserId(conn, res.id);  //将插入后的战绩id赋给这个用户id的战绩id
        //            res.id=remp.id;
        //        }

        //    }
        //    catch (Exception e)
        //    {
        //        Console.WriteLine("UpdateOrAddResult出现错误"+e);
        //    }
        //}

        /// <summary>
        /// 添加战绩到数据库中
        /// </summary>
        /// <param name="conn"></param>
        /// <param name="res"></param>
        public void UpdateOrAddUser(MySqlConnection conn, UserInfo res)
        {
            try
            {
                MySqlCommand cmm = null;
                if (res.UserId <= -1)
                {
                    //没有战绩时执行插入语句
                    cmm = new MySqlCommand("insert into user set totalcount=@totalcount ,wincount=@wincount,accountid=@accountid", conn);
                }
                else
                {
                    //有战绩时执行更新语句
                    cmm = new MySqlCommand("update  user set totalcount=@totalcount ,wincount=@wincount where accountid=@accountid", conn);
                }
                cmm.Parameters.AddWithValue("totalcount", res.TotalCount);
                cmm.Parameters.AddWithValue("wincount", res.WinCount);
                cmm.Parameters.AddWithValue("accountid", res.AccountId);
                cmm.ExecuteNonQuery();
                if (res.UserId <= 1)
                {
                    //Result remp = GetResultByUserId(conn, res.id);  //将插入后的战绩id赋给这个用户id的战绩id
                    UserInfo remp = GetUserInfoByAccountId(conn, res.AccountId); //将插入后的战绩id赋给这个用户id的战绩id
                    //res.id = remp.id;
                    res.UserId = remp.UserId;
                }

            }
            catch (Exception e)
            {
                Console.WriteLine("UpdateOrAddResult出现错误" + e);
            }
        }
    }
}
