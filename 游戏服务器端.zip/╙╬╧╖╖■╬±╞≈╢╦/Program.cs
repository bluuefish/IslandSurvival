﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GameServer.Servers;

namespace 游戏服务器端
{
    class Program
    {
        static void Main(string[] args)
        {
            //192.168.43.108
            Server myServer = new Server("192.168.43.108", 6688);
            myServer.Start();
            Console.ReadKey();
        }
    }
}
