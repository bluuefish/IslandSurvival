﻿using  System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Common;
using GameServer.Servers;

namespace GameServer.Controller
{
    class RoomController:BaseController
    {
        public RoomController()
        {
            action = ActionCode.room;
        }

        //对应请求中的CreateRoom的选项
        public string CreateRoom(string data, Client client, Server server)
        {
            server.CreateRoom(client);
            return Enum.GetName(typeof(ReturnCode), ReturnCode.Success)+","+ Enum.GetName(typeof(RoleType), RoleType.Blue);
        }

        //对应请求中的ListRoom的选项
        public string  ListRoom(string data, Client client, Server server)
        {
            StringBuilder sb = new StringBuilder();
            foreach (var room in server.GetRooms())
            {
                if(room.IsWaitJoin())
                {
                    try
                    {
                        sb.Append(room.GetHostInfo() + "|");
                    }
                    catch (Exception e)
                    {

                        Console.WriteLine(e);
                    }
                    
                }

            }
            if(sb.Length==0)
            {
              sb.Append("0");
            }else
            {
                sb.Remove(sb.Length - 1, 1);
            }
            Console.WriteLine("加载房间列表的信息"+sb.ToString());
            return sb.ToString();
        }

        //对应请求中的JoinRoom的选项
        public string JoinRoom(string data, Client client, Server server)
        {
            int id = int.Parse(data);
            Room room=server.GetRoomById(id);
            if(room==null)
            {
                //todo
                return Enum.GetName(typeof(ReturnCode), ReturnCode.NotFound);
            }
            if(room.IsWaitJoin()==false)
            {
                return Enum.GetName(typeof(ReturnCode), ReturnCode.Fail);
                //todo
            }
            else
            {
                room.AddClient(client);
                string roomData = room.GetRoomData(); //roomData的内容为“user.id, user.name, user.tc, user.wc |user.id, user.name, user.tc, user.wc”
                room.BroadcastMessage(client, RequestCode.UpdateRoom, roomData); //对房主客户端进行发送更新面板的消息
                Console.WriteLine("加入房间的信息"+Enum.GetName(typeof(ReturnCode), ReturnCode.Success) + "-" + roomData);
                return Enum.GetName(typeof(ReturnCode), ReturnCode.Success) + "," + Enum.GetName(typeof(RoleType), RoleType.red)+ "-" + roomData;
            }
        }

        //对应请求中的ExitRoom的选项
        public string ExitRoom(string data, Client client, Server server)
        {
            bool isHost = client.IsHostClient();
            Room room = client.Room;
            if (isHost==true)  //发起退出房间请求的是房主时
            {
                Console.WriteLine("点击退出的是房主");
                room.BroadcastMessage(client, RequestCode.ExitRoom, Enum.GetName(typeof(ReturnCode), ReturnCode.Success));  //通知其他客户端退出
                room.Close(); //将这个房间关闭
                return Enum.GetName(typeof(ReturnCode), ReturnCode.Success);
            }
            else//发起退出房间请求的是对手时
            {
                Console.WriteLine("点击退出的是客户");
                client.Room.RemoveClient(client);
                room.BroadcastMessage(client, RequestCode.UpdateRoom, room.GetRoomData());  //房主端更新信息
                return Enum.GetName(typeof(ReturnCode), ReturnCode.Success);


            }
        }
    }
}
