﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Common;
using GameServer.Servers;

namespace GameServer.Controller
{
    abstract class BaseController
    {
        protected ActionCode action = ActionCode.None;
        public ActionCode Action
        {
            get
            {
                return action;
            }
        }
       // ActionCode actionCode = ActionCode.None;
        public virtual string DefaultHandle(string data,Client client,Server server)
        {
            return null;
        }
    }
}
