﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Common;
using GameServer.Servers;

namespace GameServer.Controller
{
    class GameController:BaseController
    {
        public GameController()
        {
            action = ActionCode.Game;
        }
        //处理加入房间的请求
        public string StartGame(string data,Client client,Server server)
        {
            if(client.IsHostClient())
            {
                Room room = client.Room;
                //room.BroadcastMessage(client, RequestCode.StartGame, Enum.GetName(typeof(ReturnCode), ReturnCode.Success));
                //room.StartTimer();
                if(room.IsWaitJoin())
                {
                    return Enum.GetName(typeof(ReturnCode), ReturnCode.NotFound);
                }
                else
                {
                    room.BroadcastMessage(client, RequestCode.StartGame, Enum.GetName(typeof(ReturnCode), ReturnCode.Success));
                    //room.StartTimer();
                    return Enum.GetName(typeof(ReturnCode), ReturnCode.Success);
                }
     
            }
            else
            {
                return Enum.GetName(typeof(ReturnCode), ReturnCode.Fail);
            }
        }
        //处理倒计时的请求
        public string StartPlay(string data, Client client, Server server)
        {
                Room room = client.Room;
                room.StartTimer();
                return Enum.GetName(typeof(ReturnCode), ReturnCode.Success);
        }

        public string RoleAction(string data,Client client,Server server)
        {
            Room room = client.Room;
            if (room != null)
            {
                room.BroadcastMessage(client, RequestCode.RoleAction, data);
            }     
            return string.Format("{0}#{1}", Enum.GetName(typeof(ReturnCode), ReturnCode.Success), data);
        }
        //处理角色同步的请求 
        public string Move(string data, Client client, Server server)
        {
            Room room = client.Room;
            if(room!=null)
            room.BroadcastMessage(client, RequestCode.Move, data);
            return null;

        }
        //处理角色攻击同步的请求 
        public string Shoot(string data, Client client, Server server)
        {
            Room room = client.Room;
            if (room != null)
                room.BroadcastMessage(client, RequestCode.Shoot, data);
            return null;

        }
        //处理角色击中敌人的请求 
        public string Damage(string data, Client client, Server server)
        {
            int damage = int.Parse(data);
            Room room = client.Room;
            if (room == null) return null;
             room.TakeDamage(damage, client);   //在服务器端减少生命值
            //room.BroadcastMessage(client, RequestCode.Shoot, data);
            return null;

        }
    }
}
