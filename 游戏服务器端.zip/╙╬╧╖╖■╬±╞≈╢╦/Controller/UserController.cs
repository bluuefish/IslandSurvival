﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Common;
using GameServer.Servers;
using GameServer.DAO;
using GameServer.Model;
using LitJson;
namespace GameServer.Controller
{
    //2018.7.26
    //对客户端对于用户登录相关的控制器
    //调用userDAO的方法验证信息
    //Login函数返回对用户登录状态的返回码
    class UserController:BaseController
    {
        //private UserDAO userDAO = new UserDAO();
        //private ResultDAO resultDAO = new ResultDAO();
        private AccountDAO accountDAO = new AccountDAO();
        private UserDAO userDAO = new UserDAO();
        public UserController()
        {
            action = ActionCode.user;
        }

        //public string Login(string data, Client client, Server server)
        //{
        //    string[] str = data.Split(',');
        //     User user=userDAO.VerifyUser(client.MySqlConnection, str[0], str[1]);
        //    User user = userDAO.VerifyUser(client.MySqlConnection, accoutInfo.AccoutName, accoutInfo.AccoutPassword);
        //    if (user!=null)
        //    {
        //        Result result = resultDAO.GetResultByUserId(client.MySqlConnection, user.id);
        //        client.SetUserData(user, result);
        //        //Console.WriteLine(String.Format("{0},{1},{2},{3}", Enum.GetName(typeof(ReturnCode), ReturnCode.Success), user.userName, result.totalCount, result.winCount));
        //        return String.Format("{0},{1},{2},{3}", Enum.GetName(typeof(ReturnCode), ReturnCode.Success), user.userName, result.totalCount, result.winCount);
        //        //return Enum.GetName(typeof(ReturnCode), ReturnCode.Success);
               
        //    }
        //    else
        //    {
        //        return Enum.GetName(typeof(ReturnCode), ReturnCode.Fail);
        //    }

        //}
        public string Login(string data, Client client, Server server)
        {
            Console.WriteLine(data);
            JsonReader jsonReader = new JsonReader(data);
            JsonData jsonData = JsonMapper.ToObject(jsonReader);
            var id = jsonData["AccountId"].ValueAsInt();
            var name = jsonData["AccountName"].ValueAsString();
            var password = jsonData["AccountPassword"].ValueAsString();
            AccountInfo accountInfo = new AccountInfo(id, name, password);
            Console.WriteLine(accountInfo.AccountName);
            AccountInfo backAccountInfo =accountDAO .VerifyUser(client.MySqlConnection, accountInfo.AccountName, accountInfo.AccountPassword);
            if (backAccountInfo != null)
            {
                UserInfo userInfo = userDAO.GetUserInfoByAccountId(client.MySqlConnection, backAccountInfo.AccountId);
                client.SetUserData(backAccountInfo, userInfo);
                string AccountStr = JsonMapper.ToJson(backAccountInfo);
                string UserStr = JsonMapper.ToJson(userInfo);
                return string.Format("{0}#{1}#{2}", Enum.GetName(typeof(ReturnCode), ReturnCode.Success), AccountStr, UserStr);
            }
            else
            {
                return Enum.GetName(typeof(ReturnCode), ReturnCode.Fail);
            }

        }
        public string Register(string data, Client client, Server server)
        {
            JsonReader jsonReader = new JsonReader(data);
            JsonData jsonData = JsonMapper.ToObject(jsonReader);
            var id = jsonData["AccountId"].ValueAsInt();
            var name = jsonData["AccountName"].ValueAsString();
            var password = jsonData["AccountPassword"].ValueAsString();
            AccountInfo accountInfo = new AccountInfo(id, name, password);
            bool res = accountDAO.GetAccountByAccountname(client.MySqlConnection, accountInfo.AccountName);
            if (res)
            {
                return Enum.GetName(typeof(ReturnCode), ReturnCode.Fail);
            }
            else
            {

                // userDAO.AddUserInfo(client.MySqlConnection, username, password);
                accountDAO.AddAccountInfo(client.MySqlConnection, accountInfo.AccountName, accountInfo.AccountPassword);
                return Enum.GetName(typeof(ReturnCode), ReturnCode.Success);
            }

        }
    }
}
