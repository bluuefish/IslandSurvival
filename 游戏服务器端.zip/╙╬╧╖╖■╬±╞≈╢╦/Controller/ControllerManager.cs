﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Common;
using System.Reflection;
using GameServer.Servers;

namespace GameServer.Controller
{
    //2018.06.28
    //对消息进行处理
    class ControllerManager
    {
        Dictionary<ActionCode, BaseController> controllerDir = new Dictionary<ActionCode, BaseController>();
        private  Server server;
        public ControllerManager(Server _server)
        {
            this.server = _server;
            InitController();
        }
        //初始化，向控制器字典中加入处理各种请求的控制器
        void InitController()
        {
            DefultController defultController = new DefultController();
            controllerDir.Add(defultController.Action, defultController);
            controllerDir.Add(ActionCode.user,new UserController());
            controllerDir.Add(ActionCode.room, new RoomController());
            controllerDir.Add(ActionCode.Game, new GameController());
        }
        public void HandleRequest(ActionCode _actionCode,RequestCode _requestCode,string data,Client client)
        {
            BaseController controller;
            bool isGet = controllerDir.TryGetValue(_actionCode, out controller);
            if(isGet==false)
            {
                Console.WriteLine("无法得到：[" + _actionCode + "],所对应的信息");return;
            }
            //枚举是值类型，将枚举中的值类型转换成对应的字符串
            string requestName = Enum.GetName(typeof(RequestCode), _requestCode);
            //通过反射得到控制器中具体的方法信息
            MethodInfo mi=controller.GetType().GetMethod(requestName);
            if(mi==null)
            {
                Console.WriteLine("类中不存在相应的方法：" + requestName);return;
            }
            object[] parameters = new object[] { data,client,server};
            object o=mi.Invoke(controller, parameters);
            if(o==null||string.IsNullOrEmpty(o as string))
            {
                return;
            }
            server.SendResponse(client, _requestCode, o as string);
        }
    }
}
