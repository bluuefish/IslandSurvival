﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Common;
namespace GameServer.Servers
{
    //时间：2018.06.28
    //功能：存储并解析从客户端传来的数据

    class Message
    {
        private byte[] data = new byte[1024];
        private  int startIndex = 0;

        public byte[] Data
        {
            get { return data; }
        }
        public int StartIndex
        {
            get
            {
                return startIndex;
            }
        }
        public int RemainSize
        {
            get
            {
                return data.Length - startIndex;
            }
        }
        //事件委托知识点，解析消息
        public void ReadMessage(int newAmount,Action<ActionCode, RequestCode, string> OnProcessCallback)
        {
            startIndex += newAmount;
            while (true)
            {
                if (startIndex < 4) return;
                int count = BitConverter.ToInt32(data, 0); //解析消息长度
                RequestCode requestCode = (RequestCode)BitConverter.ToInt32(data, 4); //解析请求类型
                ActionCode actionCode = (ActionCode)BitConverter.ToInt32(data, 8);     //解析对应方法类型
                if (startIndex - 4 >= count)
                {
                    string s = Encoding.UTF8.GetString(data, 12, count-8);
                    OnProcessCallback(actionCode, requestCode, s);
                    Array.Copy(data, count + 4, data, 0, startIndex - 4 - count);
                    startIndex -= (4 + count);
                }
                else
                {
                    break;
                }
            }
        }

        //打包消息
        public static byte[] PackData(RequestCode requestCode,string _data)
        {
            byte[] bytRequest = BitConverter.GetBytes((int)requestCode);
            byte[] data = Encoding.UTF8.GetBytes(_data);
            int dataLength = bytRequest.Length + data.Length;
            byte[] byteLength = BitConverter.GetBytes(dataLength);
            return byteLength.Concat(bytRequest).Concat(data).ToArray<byte>();
        }
    }
}
