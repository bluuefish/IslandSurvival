﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Sockets;
using System.Net;
using GameServer.Controller;
using Common;
namespace GameServer.Servers
{
    //2018.0.6.28
    //功能：创建服务器端,作为客户端和控制器管理器交互的一个中介
    class Server
    {
        private IPEndPoint ipEndPoint;
        private Socket serverSocket;
        private List<Client> clientList=new List<Client> ();
        private List<Room> roomList = new List<Room>();

        private ControllerManager controllerManager ;

        public Server(){}
        public Server(string ipStr,int port)  //构造函数
        {
            controllerManager=new ControllerManager (this);
            SetIPEndPoint(ipStr, port);
        }
        private  void SetIPEndPoint(string IpStr,int port)  
        {
            ipEndPoint = new IPEndPoint(IPAddress.Parse(IpStr), port);
        }
        public void Start()  //设置游戏服务器端 步骤 1：实例serversocket 2:绑定IP地址和端口号 3：开始监听 4：异步接收客户端
        {
            serverSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            serverSocket.Bind(ipEndPoint);
            serverSocket.Listen(0);
            serverSocket.BeginAccept(AcceptCallBack, null);
        }
        private void AcceptCallBack(IAsyncResult ar)
        {
            Socket clientSocket = serverSocket.EndAccept(ar);
            //客户端的操作封装到Client类中进行
            Client client=new Client(clientSocket, this);
            client.Start();
            clientList.Add(client);
            serverSocket.BeginAccept(AcceptCallBack, null);
        }
        public void RemoveClient(Client client)
        {
            lock(clientList)
            {
                clientList.Remove(client);
            }
        }
        public void SendResponse(Client client,RequestCode requestCode, string data)  //对客户端的响应
        {
           // Console.WriteLine(requestCode + "------" + data);
            client.Send(requestCode, data);
        }
        public void HandleRequest(ActionCode _actionCode, RequestCode _requestCode, string data, Client client)
        {
            controllerManager.HandleRequest(_actionCode,_requestCode,data, client);
        }

        //创建一个房间
        public void CreateRoom(Client client)
        {
            Room room = new Room(this);
            room.AddClient(client);
            roomList.Add(room);
        }

        //通过id返回一个房间信息
        public Room GetRoomById(int id)
        {
            foreach (var room in roomList)
            {
                if (room.GetId() == id)
                {
                    return room;
                }
            }
            return null;
        }

       //返回房间列表
       public List<Room> GetRooms()
        {
            return roomList;
        }

        //将房间移除
        public void RemoveRoom(Room room)
        {
            if (roomList != null && room != null)
            {
                roomList.Remove(room);
            }
        }
    }
}
