﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Common;
using System.Threading;

namespace GameServer.Servers
{
    public enum RoomState
    {
        waitJoin,
        waitBatte,
        Batte,
        end
    }
    class Room
    {
        private Server server;
        private  List<Client> clientList = new List<Client>();
        RoomState state = RoomState.waitJoin;
        const int MAX_HP= 100;
        public Room(Server ser)
        {
            server = ser;
        }

        //获取房主信息
        public string GetHostInfo()
        {
            return clientList[0].GetUserData();
        }
        //添加玩家进入
        public void AddClient(Client client)
        {
            client.hp = MAX_HP;
            clientList.Add(client);
            client.Room = this;
            if(clientList.Count>=2)
            {
                state = RoomState.waitBatte;
            }
        }
        //判断该房间是否是等待状态
        public bool IsWaitJoin()
        {
            return state == RoomState.waitJoin;
        }

        //返回房间自身的Id
        public int GetId()
        {
            if(clientList.Count>0)
            {
                return clientList[0].GetAccountId();
            }
            return -1;
        }

        //获取房间的信息
        public string GetRoomData()
        {
            StringBuilder sb = new StringBuilder();
            foreach (var e in clientList)
            {
                sb.Append(e.GetUserData() + "|"); //sb的内容为“user.id, user.name, user.tc, user.wc |user.id, user.name, user.tc, user.wc”
            }
            if(sb.Length>0)
            {
                sb.Remove(sb.Length - 1, 1);
            }
            return sb.ToString();
        }
        //判断给定客户端是否是房主
        public bool ClientIsHost(Client client)
        {
            if(client==clientList[0])
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        //删除非房主的客户端
        public void RemoveClient(Client client)
        {
            client.Room = null;
            clientList.Remove(client);
            if (clientList.Count > 2)
            {
                state = RoomState.waitBatte;
            }
            else
            {
                state = RoomState.waitJoin;
            }

        }

        //该房间向其他客户端广播消息
        public void BroadcastMessage(Client exclueClient,RequestCode requestCode,string data)
        {
            foreach (var client in clientList)
            {
                if(client!=exclueClient)
                {
                    server.SendResponse(client, requestCode, data);
                }
            }
        }

        //房间开始倒计时（使用线程来实现）
        public void StartTimer()
        {
            new Thread(TimerThread).Start();
        }
        private void TimerThread()
        {
            Thread.Sleep(1000); //将线程挂起指定的毫秒数,等待客户端的面板完全显示出来
            for (int i=60;i>0;i--)
            {
                BroadcastMessage(null, RequestCode.StartTimer, i.ToString());
                Thread.Sleep(1000); //将线程挂起指定的毫秒数
            }
           BroadcastMessage(null, RequestCode.StartDepart, "s");  //发送出发请求

        }
        //将对应的客户端移除房间
        public void QuitRoom(Client client)
        {
            if (client == clientList[0])
            {
                Close();
            }
            else
            {
                client.Room = null;
                clientList.Remove(client);
            }
        }
        //房间内特定的目标受到伤害
        public void TakeDamage(int dam,Client exclueClient)
        {
            BroadcastMessage(exclueClient, RequestCode.Damage, dam.ToString());
            bool isDie = false;
            foreach (var client in clientList)
            {
                if(client!=exclueClient)
                {
                    client.TakeDamage(dam);
                    if (client.isDie==true)
                    {
                        isDie = true;
                    }
                }
            }
            Console.WriteLine(  "------" + dam);
            if (isDie == false) return;  //房间内没有人死亡
            foreach (var client in clientList)
            {
                if(client.isDie==true)
                {
                    client.Send(RequestCode.GameOver, Enum.GetName(typeof(ReturnCode), ReturnCode.Fail));
                    client.UpdateResult(false);
                }
                else
                {
                    client.Send(RequestCode.GameOver, Enum.GetName(typeof(ReturnCode), ReturnCode.Success));
                    client.UpdateResult(true);
                }
             
            }
            Close();

        }

        //关闭房间
        public void Close()
        {
            foreach (var c in clientList)
            {
                c.Room = null;
            }
            server.RemoveRoom(this);
        }
    }
}
