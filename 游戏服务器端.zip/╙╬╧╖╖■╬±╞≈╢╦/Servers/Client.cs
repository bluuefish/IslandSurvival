﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Sockets;
using System.Net;
using Common;
using MySql.Data.MySqlClient;
using GameServer.Tool;
using GameServer.Model;
using GameServer.DAO;
namespace GameServer.Servers
{
    //2018.06.28
    //功能：对服务器端接收到相对应的客户端的功能的封装
    //
    class Client
    {
        private Socket clientSocket;
        private Server server;
        private Message msg=new Message();
        private MySqlConnection mySqlConnection;
        //玩家所在的房间
        private Room room;

        public int hp;  //玩家的生命值
        public bool isDie=false;
        public MySqlConnection MySqlConnection { get => mySqlConnection; }
        //private ResultDAO resultDAO = new ResultDAO(); 09-17
        private UserDAO userDAO = new UserDAO();

        //public void TakeDamge(int dam)  //受到伤害
        //{
        //    hp -= dam;
        //    hp = Math.Max(hp, 0);
        //    if (hp <= 0)
        //    {
        //        isDie = true;
        //    }
        //    else
        //    {
        //        isDie =false;
        //    };
        //}
        public void TakeDamage(int value)
        {
            hp -= value;
            hp = Math.Max(hp, 0);
            if (hp <= 0)
            {
                isDie = true;
            }
            else
            {
                isDie = false;
            };
        }
        //当玩家加入房间时玩家被设置
        public Room Room
        {   
            set {  room=value; }
            get { return room; }
        }

        //对应客户端的玩家数据
        //private User user;
        //private Result result;
        //保存接入服务器客户端的数据
        //public void SetUserData(User _user,Result _result)
        //{
        //    user = _user;
        //    result = _result;
        //}

       //对应的客户端的账号数据
        private AccountInfo m_account;
        private UserInfo m_user;
        /// <summary>
        ///在服务器端的对应某个客户端的Client中保存用户的数据 
        /// </summary>
        public void SetUserData(AccountInfo account,UserInfo user)
        {
            m_account = account;
            m_user = user;
        }
        ////读取用户的Id -09-17
        //public int GetId()
        //{
        //    return user.id;
        //}

        /// <summary>
        /// 返回用户账号的id
        /// </summary>
        /// <returns></returns>
        public int GetAccountId()
        {
            return m_account.AccountId;
        }
        //读取该客户端的数据
        //public string GetUserData()
        //{
        //    string data =user.id+","+ user.userName + "," + result.totalCount + "," + result.winCount;
        //    return data;
        //}

        /// <summary>
        /// 得到用户的游戏信息
        /// </summary>
        /// <returns></returns>
        public string GetUserData()
        {
            string data = m_account.AccountId + "," + m_account.AccountName + "," + m_user.TotalCount
                + "," + m_user.WinCount;
            return data;
        }
        public Client()
        {
        }
        public Client(Socket _clientSocket,Server _server)  //带参构造函数
        {
            this.clientSocket = _clientSocket;
            this.server=_server;
            mySqlConnection = ConnHelper.Connection();
        }
        public void Start()  //异步接收数据
        {
            if (clientSocket == null || clientSocket.Connected == false) return;   //如果socket被关了就不调用
            clientSocket.BeginReceive(msg.Data, msg.StartIndex, msg.RemainSize, SocketFlags.None, RecevieCallBack, null);
        }

        private void RecevieCallBack(IAsyncResult ar)
        {
            if (clientSocket == null || clientSocket.Connected == false) return;   //如果socket被关了就不调用
            try
            {
                    int count = clientSocket.EndReceive(ar);
                    if (count == 0)
                    {
                        Close();
                    }
                    //接收到数据，然后读取出来
                    msg.ReadMessage(count, OnProcessCallback);
                    Start();
            }
            catch (Exception e)
            {

                Console.WriteLine(e);
                if(clientSocket!=null)
                {
                    Close();
                }
            }

        }

        //服务器端的客户Soceket对数据处理的回调函数
        public void OnProcessCallback(ActionCode actionCode, RequestCode requestCode, string data)
        {
            server.HandleRequest(actionCode, requestCode, data, this);
        }

        //判断客户端是否是房主
        public bool IsHostClient()
        {
            return room.ClientIsHost(this);
        }
        public void Send(RequestCode requestCode, string data)   //对客户端进行相应
        {
            if (clientSocket == null || clientSocket.Connected == false) return;   //如果socket被关了就不调用
            try
            {
                byte[] dataByte = Message.PackData(requestCode, data);
                clientSocket.Send(dataByte);
            }
            catch (Exception e)
            {

                Console.WriteLine("无法向客户端发送消息" + e);
            }
            
        }
        //更新战绩
        public void UpdateResult(bool isVectory)
        {
            UpdateResultToDB(isVectory);
            UpdateResultToClient();
        }
        ////数据库更新
        //private void UpdateResultToDB(bool isVectory)
        //{
        //    result.totalCount++;
        //    if (isVectory == true)
        //    {
        //        result.winCount++;
        //    }
        //    resultDAO.UpdateOrAddResult(mySqlConnection, result);
        //}

        /// <summary>
        /// 数据库更新
        /// </summary>
        /// <param name="isVectory"></param>
        private void UpdateResultToDB(bool isVectory)
        {
            m_user.TotalCount++;
            if (isVectory == true)
            {
                m_user.WinCount++;
            }
            //resultDAO.UpdateOrAddResult(mySqlConnection, result);
            userDAO.UpdateOrAddUser(mySqlConnection, m_user);
        }
        //客户端更新
        private void UpdateResultToClient()
        {
            string data = string.Format("{0},{1}", m_user.TotalCount,m_user.WinCount);
            Send(RequestCode.UpdateResult, data);
        }
        private void Close()
        {
            ConnHelper.CloseConnection(MySqlConnection);
            if (clientSocket != null)
            {
                clientSocket.Close();
            }
            if(room!=null)
            {
                room.QuitRoom(this);
            }
            server.RemoveClient(this);

        }
    }
}
