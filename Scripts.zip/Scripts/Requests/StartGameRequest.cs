﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using Common;

public class StartGameRequest : BaseRequest {
    private RoomPanel roomPanel;
    public override void Awake()
    {
        request = RequestCode.StartGame;
        action = ActionCode.Game;
        roomPanel = GetComponent<RoomPanel>();
        base.Awake();
    }
    private void Start()
    {
        
    }
    public override void SendRequest()
    {
        base.SendRequest("start");
    }
    public override void OnResponse(string data)
    {
        ReturnCode returnCode = (ReturnCode)Enum.Parse(typeof(ReturnCode), data);
        roomPanel.StartGameResponse(returnCode);
        base.OnResponse(data);
    }
}
