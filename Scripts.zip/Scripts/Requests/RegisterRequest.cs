﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Common;
using System;
using LitJson;

public class RegisterRequest : BaseRequest {

    private RegisterPanel registerPanel;
    public override void Awake()
    {
        request = RequestCode.Register;
        action = ActionCode.user;
        base.Awake();
    }

    private void Start()
    {
        registerPanel = GetComponent<RegisterPanel>();
    }
    //public void SendRequest(string username, string password)
    //{
    //    string data = username + "," + password;
    //    base.SendRequest(data);
    //}  
    
   public void SendRequest(AccountInfo account)
    {
        string data = JsonMapper.ToJson(account);
        base.SendRequest(data);
    }

    //处理服务器的回应
    public override void OnResponse(string data)
    {
        ReturnCode returnCode = (ReturnCode)Enum.Parse(typeof(ReturnCode), data);
        registerPanel.OnResponseRegister(returnCode);
    }
}
