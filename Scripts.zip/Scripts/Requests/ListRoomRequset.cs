﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Common;

public class ListRoomRequset : BaseRequest {

    private HallPanel hallPanel;
    public override void Awake()
    {
        request = RequestCode.ListRoom;
        action = ActionCode.room;
        hallPanel = GetComponent<HallPanel>();
        base.Awake();
    }
    public override void SendRequest()
    {
        string data = "listRoom";
        base.SendRequest(data);
    }

    public override void OnResponse(string data)
    {
        List<UserData> userDatas = new List<UserData>();
        if (data!= "0")
        {
            string[] strs = data.Split('|');
            foreach (var e in strs)
            {
                Debug.Log(e + "ssssss");
                string[] udstr = e.Split(',');  //每个房间需显示的信息
                userDatas.Add(new UserData(udstr[0], udstr[1], udstr[2], udstr[3]));
            }
        }
        // roomListPanel.LoadRoomListSync(userDatas);
        hallPanel.LoadRoomListSync(userDatas);
    }

}
