﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Common;
using System;

public class CreateRoomRequest : BaseRequest{
    private RoomPanel roomPanel;
    public override void Awake()
    {
        request = RequestCode.CreateRoom;
        action = ActionCode.room;
        base.Awake();
       // roomPanel = GetComponent<RoomPanel>();
    }

    //设置room的面板
    public void SetPanel(BasePanel panel)
    {
        roomPanel = panel as RoomPanel ;
    }
    //发送消息
    public override void SendRequest()
    {
        string data = "r";
        base.SendRequest(data);
    }

    //相应消息
    public override void OnResponse(string data)
    {
        string[] strArray = data.Split(','); 
        base.OnResponse(data);
        ReturnCode returnCode = (ReturnCode)Enum.Parse(typeof(ReturnCode), strArray[0]);
        RoleType roleType= (RoleType)Enum.Parse(typeof(RoleType), strArray[1]);
        if (returnCode==ReturnCode.Success)
        {
            UserData userData = gameFac.GetUserData();
            gameFac.SetCurrentRoleType(roleType);
            roomPanel.SetHostInfSync(userData);
        }
    }
}
