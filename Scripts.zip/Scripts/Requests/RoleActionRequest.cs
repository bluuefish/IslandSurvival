﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Common;
using LitJson;
using System;

public class RoleActionRequest : BaseRequest {

    /// <summary>
    /// 当前客户端的角色类
    /// </summary>
    private CharacterMotor localMotor;
    /// <summary>
    /// 远程客户端的映射的角色类
    /// </summary>
    private CharacterMotor RomateMotor;
    private int SyncRate = 60;
    public void SetLocalMotor(CharacterMotor motor)
    {
        localMotor = motor;
    }

    public void SetRomateMotor(CharacterMotor motor)
    {
        RomateMotor = motor;
    }

    public override void Awake()
    {
        request = RequestCode.RoleAction;
        action = ActionCode.Game;
        base.Awake();
    }
    private void Start()
    {
        InvokeRepeating("SyncLocalPlayer", 1f, 1f / SyncRate);
    }
    private void FixedUpdate()
    {
      // SendRequest(localMotor.Commend);
    }
    private void SyncLocalPlayer()
    {
        SendRequest(localMotor.Commend);
    }
    public void SendRequest(InputCommend commend)
    {
        string data = JsonMapper.ToJson(commend);
        base.SendRequest(data);
    }

    public override void OnResponse(string data)
    {
        string[] str = data.Split('#');
        //Debug.Log(data);
        if(str.Length>1)   //服务器返回的是自身的输入
        {
            string returnCodeStr = str[0];
            ReturnCode returnCode = (ReturnCode)Enum.Parse(typeof(ReturnCode), returnCodeStr);
            if(returnCode==ReturnCode.Success)
            {

                InputCommend commend = ParseFrom(str[1]);
                localMotor.SetSyncInputCommed(commend);
            }

        }
        else   //服务器返回的其他客户端的输入
        {
            InputCommend commend = ParseFrom(str[0]);
            RomateMotor.SetSyncInputCommed(commend);
        }
      
        
        base.OnResponse(data);
    }

    /// <summary>
    /// 字符串解析成对应类
    /// </summary>
    /// <param name="data"></param>
    /// <returns></returns>
    private InputCommend ParseFrom(string data)
    {
        JsonData jsonData = JsonMapper.ToObject(data);

        var posX = jsonData["PositionX"].ValueAsDouble();
        var posY = jsonData["PositionY"].ValueAsDouble();
        var posZ = jsonData["PositionZ"].ValueAsDouble();

        var eulerX = jsonData["EulerX"].ValueAsDouble();
        var eulerY = jsonData["EulerY"].ValueAsDouble();
        var eulerZ = jsonData["EulerZ"].ValueAsDouble();

        var movedirX = jsonData["InputMoveDirX"].ValueAsDouble();
        var movedirY = jsonData["InputMoveDirY"].ValueAsDouble();
        var movedirZ = jsonData["InputMoveDirZ"].ValueAsDouble();
        var absmovedirX = jsonData["InputAbsMoveDirX"].ValueAsDouble();
        var absmovedirY = jsonData["InputAbsMoveDirY"].ValueAsDouble();
        var absmovedirZ = jsonData["InputAbsMoveDirZ"].ValueAsDouble();

        var forwordX = jsonData["InputForwordDirX"].ValueAsDouble();
        var forwordY = jsonData["InputForwordDirY"].ValueAsDouble();
        var forwordZ = jsonData["InputForwordDirZ"].ValueAsDouble();
        var magnitude = jsonData["InputMoveMagnitude"].ValueAsDouble();
        var jump = jsonData["InputJump"].ValueAsBoolean();
        var crouch = jsonData["InputCrouch"].ValueAsBoolean();
        var weaponType = jsonData["InputWeaponType"].ValueAsInt();
        var fire = jsonData["InputFire"].ValueAsBoolean();
        var reload = jsonData["InputReload"].ValueAsBoolean();
        var take = jsonData["InputTake"].ValueAsBoolean();
        var lookHeight = jsonData["InputLookHightAngle"].ValueAsDouble();
        InputCommend commend = new InputCommend();

        commend.PositionX = (float)posX;
        commend.PositionY = (float)posY;
        commend.PositionZ = (float)posZ;

        commend.EulerX = (float)eulerX;
        commend.EulerY = (float)eulerY;
        commend.EulerZ = (float)eulerZ;

        commend.InputMoveDirX = (float)movedirX;
        commend.InputMoveDirY = (float)movedirY;
        commend.InputMoveDirZ = (float)movedirZ;
        commend.InputAbsMoveDirX = (float)absmovedirX;
        commend.InputAbsMoveDirY = (float)absmovedirY;
        commend.InputAbsMoveDirZ = (float)absmovedirZ;
        commend.InputForwordDirX = (float)forwordX;
        commend.InputForwordDirY= (float)forwordY;
        commend.InputForwordDirZ = (float)forwordZ;
        commend.InputMoveMagnitude = (float)magnitude;
        commend.InputJump = jump;
        commend.InputCrouch = crouch;
        commend.InputWeaponType = weaponType;
        commend.InputFire = fire;
        commend.InputReload = reload;
        commend.InputTake = take;
        commend.InputLookHightAngle = lookHeight;
        return commend;
    }
}
