﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Common;
using System;

public class ShootRequest : BaseRequest {
    public PlayerManage PlayerMan { get; set; }
    private RoleType rt;
    private Vector3 pos;
    private Vector3 rot;
    private bool isShoot=false;
    public override void Awake()
    {
        action = ActionCode.Game;
        request = RequestCode.Shoot;
        base.Awake();
    }

    private void Update()
    {
        if(isShoot)
        {
            PlayerMan.RomateShoot(rt, pos, rot);
            isShoot = false;
        }
    }
    public void SendRequest(RoleType type,Vector3 pos,Vector3 rot)
    {
        string data = string.Format("{0}|{1},{2},{3}|{4},{5},{6}", Enum.GetName(typeof(RoleType), type), pos.x, pos.y, pos.z,
            rot.x, rot.y, rot.z);
        base.SendRequest(data);
    }
    public override void OnResponse(string data)
    {
        string[] str = data.Split('|');
        rt = (RoleType)Enum.Parse(typeof(RoleType), str[0]);
        pos = UnityTools.ParseVector3(str[1]);
        rot = UnityTools.ParseVector3(str[2]);
        isShoot = true;
    }
}
