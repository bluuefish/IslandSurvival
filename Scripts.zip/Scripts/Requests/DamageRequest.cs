﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Common;

public class DamageRequest : BaseRequest {
    private CharacterHealth characterHealth;
    private BasePanel gamePanel;
    public override void Awake()
    {
        action = ActionCode.Game;
        request = RequestCode.Damage;
        base.Awake();
    }
    private void Start()
    {
        characterHealth = GetComponent<CharacterHealth>();
        gamePanel = gameFac.GetExistPanel(UIPanelType.Game);
    }
    public  void SendRequest(float dam)
    {
        string data = dam.ToString();
        base.SendRequest(data);
    }
    public override void OnResponse(string data)
    {
        base.OnResponse(data);
        characterHealth.DamageAsync(float.Parse(data));
        if (float.Parse(data) > 0)
        {
            (gamePanel as GamePanel).TakeDamageResponse();
        }
    }
}
