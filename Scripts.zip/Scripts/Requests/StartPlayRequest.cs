﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Common;
using System;

public class StartPlayRequest : BaseRequest {

    //private bool isStartPlaying = false;
    public override void Awake()
    {
        action = ActionCode.Game;
        request = RequestCode.StartPlay;
        base.Awake();
    }
    //private void Start()
    //{
    //    SendRequest();
    //}
    //private void Update()
    //{
    //    if (isStartPlaying == true)
    //    {
    //        gameFac.StartPlaying();
    //        isStartPlaying = false;
    //    }
    //}
    public override  void SendRequest()
    {
        string data = "p";
        base.SendRequest(data);
    }
    public override void OnResponse(string data)
    {
        ReturnCode returnCode = (ReturnCode)Enum.Parse(typeof(ReturnCode), data);
        //  Debug.Log(data);
        //
        if(returnCode==ReturnCode.Success)
        {
            //isStartPlaying = true;
            gameFac.EnterPlayingSync();
        }
        base.OnResponse(data);

    }
}
