﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Common;
public class StartDepartRequest : BaseRequest {
    private bool isStart = false;
    private Vector3 pos;
    private GameObject transitPrafab;  //过渡的船
    private GameObject ship;
    private GamePanel gamePanel;
    private bool isReach = false;
    /// <summary>
    /// 当前客户端的角色类
    /// </summary>
    private CharacterMotor localMotor;
    /// <summary>
    /// 远程客户端的映射的角色类
    /// </summary>
    private CharacterMotor RomateMotor;

    public void SetLocalMotor(CharacterMotor motor)
    {
        localMotor = motor;
    }

    public void SetRomateMotor(CharacterMotor motor)
    {
        RomateMotor = motor;
    }

    public override void Awake()
    {
        request = RequestCode.StartDepart;
        action = ActionCode.Game;
        base.Awake();
    }
    private void Start()
    {
        pos = GameObject.Find("ShipPos").transform.position;
        transitPrafab = Resources.Load<GameObject>("Prefabs/DepartTransit");
    }
    private void Update()
    {
        if(isStart&&ship==null)
        {
           
            ship=Instantiate(transitPrafab, pos, Quaternion.identity);
            localMotor.transform.position = ship.transform.position;
            RomateMotor.transform.position = ship.transform.position;
            localMotor.gameObject.SetActive(false);
            RomateMotor.gameObject.SetActive(false);
            BasePanel panel=gameFac.GetExistPanel(UIPanelType.Game);
            gamePanel = (panel as GamePanel);
            gamePanel.HideTime();
            Debug.Log("是否激活"+gamePanel.timer.gameObject.activeSelf);
            gamePanel.HideHealthTip();
            gamePanel.HideAim();
            for (int i = 0; i < localMotor.holdHand.childCount; i++)
            {
                Destroy(localMotor.holdHand.GetChild(i).gameObject);
            }
            for (int i = 0; i <  RomateMotor.holdHand.childCount; i++)
            {
                Destroy(RomateMotor.holdHand.GetChild(i).gameObject);
            }
            for (int i = 0; i < localMotor.weapons.Length; i++)
            {
                localMotor.weapons[i].Item = null;
            }
            for (int i = 0; i < RomateMotor.weapons.Length; i++)
            {
                RomateMotor.weapons[i].Item = null;
            }
            localMotor.inputWeaponType = 0;
            RomateMotor.inputWeaponType = 0;
            gameFac.SetCanDamageSign(true);
            isStart = false;
        }
        if(ship != null&&ship.GetComponentInChildren<ShipMove>().moveing==false&&isReach==false )
        {
            gamePanel.ShowHealthTip();
            gamePanel.ShowAim();
            ShipMove shipMove = ship.GetComponentInChildren<ShipMove>();
            //TODO开始正式的冒险
           localMotor.transform.position = localMotor.GetComponent<RoleInfo>().roleType == RoleType.Blue ?
                    shipMove.pos1.localPosition : shipMove.pos2.localPosition;
          RomateMotor.transform.position = RomateMotor.GetComponent<RoleInfo>().roleType == RoleType.Blue ?
                shipMove.pos1.localPosition : shipMove.pos2.localPosition;
            localMotor.gameObject.SetActive(true);
            RomateMotor.gameObject.SetActive(true);
            Debug.Log(localMotor.transform.position + "_lo" + shipMove.pos1 + "sh1" + RomateMotor.transform.position);
            ship.SetActive(false);
            isReach = true;
        }
    }
    public override void OnResponse(string data)
    {
        base.OnResponse(data);
        isStart = true;
    }
}
