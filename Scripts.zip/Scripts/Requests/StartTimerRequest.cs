﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Common;

public class StartTimerRequest : BaseRequest {
    private GamePanel gamePanel;
    public override void Awake()
    {
        action = ActionCode.Game;
        request = RequestCode.StartTimer;
        gamePanel = GetComponent<GamePanel>();
        base.Awake();
    }
    public override void SendRequest()
    {
        string data = "t";
        base.SendRequest(data);
    }
    public override void OnResponse(string data)
    {
        int timer = int.Parse(data);
        //Debug.Log("倒计时" + timer);
        gamePanel.ShowTimeync(timer);
        base.OnResponse(data);
    }
}
