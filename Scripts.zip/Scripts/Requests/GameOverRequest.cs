﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Common;
using System;

public class GameOverRequest : BaseRequest {
    private GamePanel gamePanel;
    private ReturnCode returnCode;
    private bool isGameOver = false;
    public override void Awake()
    {
        action = ActionCode.Game;
        request = RequestCode.GameOver;
        base.Awake();
    }
    private void Start()
    {
        gamePanel = GetComponent<GamePanel>();
    }
    private void Update()
    {
        if(isGameOver==true)
        {
            gamePanel.GameOverResponse(returnCode);
            isGameOver = false;
        }
        
    }
    public override void OnResponse(string data)
    {
       returnCode = (ReturnCode)Enum.Parse(typeof(ReturnCode), data);
        isGameOver = true;
        base.OnResponse(data);
    }
}
