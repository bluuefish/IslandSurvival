﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Common;

public class UpdataRoomRequest : BaseRequest {
    private RoomPanel roomPanel;

    private UserData usd1 = null;
    private UserData usd2 = null;
    public override void Awake()
    {
        request = RequestCode.UpdateRoom;
        action = ActionCode.room;
        base.Awake();
    }
    // Use this for initialization
    void Start () {
        roomPanel = GetComponent<RoomPanel>();
	}

    //房主端当有玩家加入时更新
    public override void OnResponse(string data)
    {  //数据的表示为 username,usertotalcount,userwincount|username,usertotalcount,userwincount
        string[] userStrArray = data.Split('|');
      
            usd1 = new UserData(userStrArray[0]);
        if(userStrArray.Length>1)
            usd2 = new UserData(userStrArray[1]);  //当有人加入房间的情况

        roomPanel.SetAllInfSync(usd1, usd2);
        base.OnResponse(data);
    }
}
