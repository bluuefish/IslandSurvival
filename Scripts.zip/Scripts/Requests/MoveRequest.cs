﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Common;
public class MoveRequest : BaseRequest {
    private Transform localPlayerTran;
    private PlayerMove localPlayMove;

    private Transform romatePlayerTran;
    private Animator romatePlayerAni;
    private Vector3 romatePos;
    private Vector3 romateRot;
    private float romateForward;
    private int SyncRate = 20;
    private bool isSyncRomate = false;
    public void SetLoaclPlayer(Transform tran,PlayerMove playerMove)
    {
        this.localPlayerTran = tran;
        this.localPlayMove = playerMove;
    }
    public void SetRomatePlayer(Transform tran, Animator playerAni)
    {
        this.romatePlayerTran = tran;
        this.romatePlayerAni =playerAni;
    }
    public override void Awake()
    {
        action = ActionCode.Game;
        request = RequestCode.Move;
        base.Awake();
    }
    private void Start()
    {
        InvokeRepeating("SyncLocalPlayer", 1f, 1f / SyncRate);
    }
    private void FixedUpdate()
    {
        if(isSyncRomate)
        {
            SyncRomatePlayer();
            isSyncRomate = false;
        }
    }
    private void SyncLocalPlayer()
    {
        SendRequest(localPlayerTran.position.x, localPlayerTran.position.y, localPlayerTran.position.z,
            localPlayerTran.eulerAngles.x, localPlayerTran.eulerAngles.y, localPlayerTran.eulerAngles.z, localPlayMove.forward);
    }
    private void SyncRomatePlayer()
    {
        romatePlayerTran.position = romatePos;
        romatePlayerTran.eulerAngles = romateRot;
        romatePlayerAni.SetFloat("Forward", romateForward);
    }

    private  void SendRequest(float posx,float posy,float posz,float rotx,float roty,float rotz,float forward)
    {
        string data = string.Format("{0},{1},{2}|{3},{4},{5}|{6}", posx, posy, posz, rotx, roty, rotz, forward);
        base.SendRequest(data);
    }
    public override void OnResponse(string data)
    {
        string[] str1 = data.Split('|');
        romatePos = UnityTools.ParseVector3(str1[0]);
        romateRot = UnityTools.ParseVector3(str1[1]);
        romateForward = float.Parse(str1[2]);
        isSyncRomate = true;

        base.OnResponse(data);
    }
}
