﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Common;
public class UpdateResultRequest : BaseRequest {
 
    private string tatol;
    private string win;
    private bool isUpdate = false;
    public override void Awake()
    {
        request = RequestCode.UpdateResult;
        base.Awake();
    }
    private void Update()
    {
        if(isUpdate==true)
        {
            gameFac.UpdateUserData(tatol, win);
            isUpdate = false;
        }
    }
    public override void OnResponse(string data)
    {
        string[] str = data.Split(',');
        tatol = str[0];
        win = str[1];
        isUpdate = true;
        base.OnResponse(data);
    }
}
