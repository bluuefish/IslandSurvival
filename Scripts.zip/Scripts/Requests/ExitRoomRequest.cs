﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Common;
using System;

public class ExitRoomRequest : BaseRequest {
    private RoomPanel roomPanel;
    public override void Awake()
    {
        request = RequestCode.ExitRoom;
        action = ActionCode.room;
        base.Awake();
    }
    private void Start()
    {
        roomPanel = GetComponent<RoomPanel>();
    }
    public override void SendRequest()
    {
        base.SendRequest("e");
    }
    public override void OnResponse(string data)
    {
        ReturnCode returnCode = (ReturnCode)Enum.Parse(typeof(ReturnCode), data);
        if(returnCode==ReturnCode.Success)
        {
            roomPanel.ExitResponseSync();
        }
        base.OnResponse(data);
    }
}
