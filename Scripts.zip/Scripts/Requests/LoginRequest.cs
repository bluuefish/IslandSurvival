﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Common;
using System;
using LitJson;

public class LoginRequest : BaseRequest {
    private LoginPanel loginPanel;
    public override void Awake()
    {
        action = ActionCode.user;
        request = RequestCode.Login;
        base.Awake();
      
    }
    private void Start()
    {
        loginPanel = GetComponent<LoginPanel>();
        Debug.Log(request + this.name+"sss");
    }
    /// <summary>
    /// 以字符串拼接的方式发送消息
    /// </summary>
    /// <param name="username"></param>
    /// <param name="password"></param>
    public void SendRequest(string username, string password)
    {
        string data = username + "," + password;
        base.SendRequest(data);
    }

    public void SendRequest(AccountInfo info)
    {
        string data = JsonMapper.ToJson(info);
           JsonData account= JsonMapper.ToObject(data);

        Debug.Log(account[2].ValueAsString());
        base.SendRequest(data);
    }
    public override void OnResponse(string data)
    {
        string[] str = data.Split('#');  //改 09-17
        string returnCodeStr = str[0];
        ReturnCode returnCode = (ReturnCode)Enum.Parse(typeof(ReturnCode), returnCodeStr);  //字符串转化为对应的枚举类型

        // var  account=JsonUtility.FromJson<object>(returnAccountStr);
        //JsonReader accountjsonReader = new JsonReader(returnAccountStr);
        //JsonReader userjsonReader = new JsonReader(returnUserStr);
        //JsonData accountJsonData = JsonMapper.ToObject(returnAccountStr);
        //JsonData userJsonData = JsonMapper.ToObject(returnUserStr);
        //var name = accountJsonData["AccountName"].ValueAsString();
        
        if (returnCode==ReturnCode.Success)  //改 09-19
        {
            string returnAccountStr = str[1];
            string returnUserStr = str[2];
            JsonReader accountjsonReader = new JsonReader(returnAccountStr);

            JsonData accountJsonData = JsonMapper.ToObject(returnAccountStr);
            var id = accountJsonData["AccountId"].ValueAsInt();
            var name = accountJsonData["AccountName"].ValueAsString();
            var password = accountJsonData["AccountPassword"].ValueAsString();
            AccountInfo account = new AccountInfo(id, name, password);

            JsonReader userjsonReader = new JsonReader(returnUserStr);
            JsonData userJsonData = JsonMapper.ToObject(returnUserStr);

            var userId = userJsonData["UserId"].ValueAsInt();
            var totalCount = userJsonData["TotalCount"].ValueAsInt();
            var winCount = userJsonData["WinCount"].ValueAsInt();
            var treasure = userJsonData["Treasure"].ValueAsInt();
            UserInfo user = new UserInfo(userId, id, totalCount, winCount, treasure);

            UserData userData = new UserData(id.ToString(), name, totalCount.ToString(), winCount.ToString());
            gameFac.SetPlayerInfo(account, user); //改 09-17
            gameFac.SetPlayData(userData);
        }
        loginPanel.LoginOnReponse(returnCode);   //调用loginpanel对返回转态码相应
        base.OnResponse(data);
    }
}
