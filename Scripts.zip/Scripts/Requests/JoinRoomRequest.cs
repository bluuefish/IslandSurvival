﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Common;
using System;

public class JoinRoomRequest : BaseRequest {
    private HallPanel hallPanel;
    public override void Awake()
    {
        request = RequestCode.JoinRoom;
        action = ActionCode.room;
        hallPanel = GetComponent<HallPanel>();
        base.Awake();
    }

    public void SendRequest(int id)
    {
        base.SendRequest(id.ToString());
    }

    //响应消息
    public override void OnResponse(string data)
    {
        //数据的表示为 returnCode,roleType-username,usertotalcount,userwincount|username,usertotalcount,userwincount
        string[] resData = data.Split('-');
        string[] codeStr = resData[0].Split(',');
        ReturnCode returnCode = (ReturnCode)Enum.Parse(typeof(ReturnCode), codeStr[0]);  //返回的状态码，
        string[] userStrArray = resData[1].Split('|');
        UserData usd1 = null;
        UserData usd2 = null;
        if(returnCode==ReturnCode.Success)
        {
            usd1 = new UserData(userStrArray[0]);
            usd2 = new UserData(userStrArray[1]);
            RoleType roleType = (RoleType)Enum.Parse(typeof(RoleType), codeStr[1]);
            gameFac.SetCurrentRoleType(roleType);
        }
        hallPanel.OnResponseJoinRoom(returnCode, usd1, usd2);
        base.OnResponse(data);
    
    }
}
