﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Common;

public class BaseRequest : MonoBehaviour {

    protected ActionCode action = ActionCode.None;
    protected RequestCode request = RequestCode.None;
    private GameFacade _gameFac;
    protected GameFacade gameFac
    {
        get
        {
            if(_gameFac==null)
            {
                _gameFac = GameFacade.Instance;
            }
            return _gameFac;
        }
    }
    public virtual void Awake()
    {
        GameFacade.Instance.AddRequest(request, this);
       
    }

    protected void SendRequest(string data)
    {
        gameFac.SendMessage(request, action, data);
    }

    public virtual void SendRequest(){}

    public virtual void OnResponse(string data) { }

    public virtual void OnDestroy()
    {
        GameFacade.Instance.RemoveRequest(request);
    }
}
