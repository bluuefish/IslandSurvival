﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerInput{
  public   static void DoMovement(Transform root,Transform camera,ref Vector3 direction,out Vector3 absDir, ref bool isJump,ref bool isCrouch)
    {
        float h = Input.GetAxis("Horizontal");
        float v = Input.GetAxis("Vertical");
        absDir = new Vector3(h, 0, v);
        Vector3 cam_Forward = Vector3.Scale(camera.forward, new Vector3(1, 0, 1));  //得到摄像机在水平面的前方向
        direction = v * cam_Forward + h * camera.right;
        if(direction.magnitude>1)  direction.Normalize(); //将方向向量的长度归一化
        isJump = Input.GetButtonDown("Jump");
        isCrouch = Input.GetButton("Crouch");

    }
  public   static void DoArmed(Transform root, Transform camera,ref int weaponType,ref bool IsReload)
    {
        if (Input.GetKey(KeyCode.Alpha0)) { weaponType = 0; }
        if (Input.GetKey(KeyCode.Alpha1)) { weaponType = 1; }
        if (Input.GetKey(KeyCode.Alpha2)) { weaponType = 2; }
        if (Input.GetKey(KeyCode.Alpha3)) { weaponType = 3; }
        if (Input.mouseScrollDelta.y<0)
        {
            weaponType -= weaponType;
        }
        if(Input.mouseScrollDelta.y>0)
        {
            weaponType += weaponType;
        }
        IsReload = Input.GetButtonDown("Reload");
    }

	
}
