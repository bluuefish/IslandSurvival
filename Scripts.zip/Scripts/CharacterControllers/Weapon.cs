﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


[System.Serializable]
public struct WeaponDescription
{
    /// <summary>
    /// 包含Gun组件的预制体
    /// </summary>
    public GameObject Item;
    /// <summary>
    /// 枪收起时显示的枪
    /// </summary>
    public GameObject Holster;
    public WeaponType Type;
    public Gun Gun
    {
        get
        {
            if (_cacheItem == Item)
                return _cachedGun;
            else
            {
                Cache();
                return _cachedGun;
            }
        }
    }

    private Gun _cachedGun;
    private GameObject _cacheItem;
    private void Cache()
    {
        _cacheItem = Item;
        _cachedGun = Item == null ? null : Item.GetComponent<Gun>();
    }
}
/// <summary>
/// 定义了与武器一起使用的角色动画。
/// </summary>
public enum WeaponType
{
    Pistol,
    Rifle
}

/// <summary>
/// 定义一个角色用武器时他所处在的转态
/// </summary>
public struct WeaponAnimationStates
{
    /// <summary>
    ///换弹状态的名称
    /// </summary>
    public string Reload;

    /// <summary>
    /// 近身攻击状态的名称
    /// </summary>
    public string Hit;

    /// <summary>
    /// 当武器被充分使用时，动画机的名字就会出现。
    /// </summary>
    public string[] Common;

    /// <summary>
    ///装备武器状态的名称
    /// </summary>
    public string Equip;

    /// <summary>
    /// 返回一个状态
    /// </summary>
    public static WeaponAnimationStates Default()
    {
        var states = new WeaponAnimationStates();
        states.Reload = "Reload"; 
        states.Hit = "Hit";
        states.Common = new string[] { "Idle", "Aim", "Cover", "Empty state", "Jump","Reload" };
        states.Equip = "Equip";
        return states;
    }
}