﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BodyPartHealth : MonoBehaviour {
    /// <summary>
    /// 角色的生命值
    /// </summary>
    public CharacterHealth TargetOveride;
    /// <summary>
    ///角色伤害的倍数
    /// </summary>
    public float DamageScale = 1.0f;
    private CharacterHealth _target;
    public void OnHit(Hit hit)
    {
        var target = TargetOveride;
        if(target==null)
        {
            target = _target;
        }
        if(target==null)
        {
            var obj = transform;
            while(obj!=null&&target==null)
            {
                target = obj.GetComponent<CharacterHealth>();
                obj = obj.transform.parent;
            }
            _target = target;
        }

        if (target == null)
            return;
        hit.Damage *= DamageScale;
        target.SendMessage("OnHit", hit, SendMessageOptions.DontRequireReceiver);
    }
}
