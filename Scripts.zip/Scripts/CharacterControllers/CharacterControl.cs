﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
[RequireComponent(typeof(CharacterMotor))]
public class CharacterControl : MonoBehaviour {
    private CharacterMotor motor;
    private Camera m_camera;
	void Start () {
        motor = GetComponent<CharacterMotor>();
        m_camera = Camera.main;
	}
	
	// Update is called once per frame
	void Update () {
        UpdateFireAndZoom();
        UpdateWeapons();
        UpdateReload();
        UpdateTake();
    }
    private void FixedUpdate()
    {
        UpdateMovement();
    }
    //基本运动的输入
    private void UpdateMovement()
    {
        float h = Input.GetAxis("Horizontal");
        float v = Input.GetAxis("Vertical");
        Vector3 AbsDirection = new Vector3(h, 0, v);
        Vector3 cam_Forword=Vector3.Scale(m_camera.transform.forward, new Vector3(1, 0, 1));
        Vector3 direction = cam_Forword * AbsDirection.z + m_camera.transform.right * AbsDirection.x; //得到以摄像机为原点，x,z轴都在水平面的一个方向向量
                                                                                        //基本的速率
        float baseMagnitude = Mathf.Sqrt(h * h + v * v);
        motor.inputAbsMoveDir= AbsDirection;
        motor.inputMoveDir = direction;
        motor.inputMoveMagnitude = baseMagnitude;
        motor.inputJump = Input.GetButtonDown("Jump");
        motor.inputCrouch = Input.GetButton("Crouch"); 
    }

    //更新开火和开镜
    private void UpdateFireAndZoom()
    {
        //开火请求
        motor.inputFire = Input.GetButtonDown("Fire1");


        if(Input.GetButtonDown("Fire2"))
        {

        }
        if(Input.GetButtonUp("Fire2"))
        {

        }
        
    }

    //更新更换武器
    private void UpdateWeapons()
    {
        if (Input.GetKey(KeyCode.Alpha0)) { motor.InputWeapon(0); }
        if (Input.GetKey(KeyCode.Alpha1)) { motor.InputWeapon(1); }
        if (Input.GetKey(KeyCode.Alpha2)) { motor.InputWeapon(2); }
        if (Input.GetKey(KeyCode.Alpha3)) { motor.InputWeapon(3); }
        if(Input.mouseScrollDelta.y<0)
        {
            if (motor.currentWeapon == 0)
            {
                motor.InputWeapon(motor.weapons.Length);
            }
            else
                motor.InputWeapon(motor.currentWeapon - 1);
        }
        else if(Input.mouseScrollDelta.y>0)
        {
            if(motor.currentWeapon== motor.weapons.Length)
            {
                motor.InputWeapon(0);
            }
            else
            {
                motor.InputWeapon(motor.currentWeapon + 1);
            }
        }
    }
   
    //更新换弹
    private void UpdateReload()
    {
        motor.inputReload= Input.GetButtonDown("Reload");
    }

    //更新捡物品
    private void UpdateTake()
    {
        motor.inputTake = Input.GetButtonDown("Take");
    }
}
