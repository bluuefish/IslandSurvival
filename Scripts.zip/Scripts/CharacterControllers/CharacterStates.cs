﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CharacterStates {
    private Vector3 direction;
    private float speedMagnitude;
    private bool jump;
    private bool isCrouch;
    private bool isArmed;
    private bool beath;
    private bool isReloading;
    private float gunVariant;
    private int weaponType;

    public Vector3 Direction
    {
        get
        {
            return direction;
        }

        set
        {
            direction = value;
        }
    }

    public float SpeedMagnitude
    {
        get
        {
            return speedMagnitude;
        }

        set
        {
            speedMagnitude = value;
        }
    }

    public bool Jump
    {
        get
        {
            return jump;
        }

        set
        {
            jump = value;
        }
    }

    public bool IsCrouch
    {
        get
        {
            return isCrouch;
        }

        set
        {
            isCrouch = value;
        }
    }

    public bool IsArmed
    {
        get
        {
            return isArmed;
        }

        set
        {
            isArmed = value;
        }
    }

    public bool Beath
    {
        get
        {
            return beath;
        }

        set
        {
            beath = value;
        }
    }

    public bool IsReloading
    {
        get
        {
            return isReloading;
        }

        set
        {
            isReloading = value;
        }
    }

    public float GunVariant
    {
        get
        {
            return gunVariant;
        }

        set
        {
            gunVariant = value;
        }
    }

    public int WeaponType
    {
        get
        {
            return weaponType;
        }

        set
        {
            weaponType = value;
        }
    }
}
