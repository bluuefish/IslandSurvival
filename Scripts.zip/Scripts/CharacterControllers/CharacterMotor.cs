﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Common;
[RequireComponent(typeof(Rigidbody))]
[RequireComponent(typeof(Animator))]
[RequireComponent(typeof(Locomotion))]
public class CharacterMotor : MonoBehaviour
{

    public bool IsLoaclPlay = false;

    private  float lerp=5;
    #region 角色的本地属性设置
    public const int FirstWeaponLayer = 0;
    const float k_half = 0.5f;
    protected Animator m_animator;
    protected Camera m_camera;
    Rigidbody m_rigibody;
    CapsuleCollider m_capsule;
    Locomotion locomotion;
    FreeLookCam freeLookCam;
    float capsuleHeight;
    Vector3 capsuleCenter;
    public   CharacterHealth characterHealth;

    public Vector3 IronOffset;
    public Transform holdHand;
    private DamageRequest damageRequest;
    private PlayerManage playerManage;   //管理角色的类
    public bool isUseCustom;
    public WeaponDescription[] weapons;
    public float m_jumpPower = 12f;
    public float m_origCheckGroundDis;
    public float m_gravityMultiplier = 2f;
    public float moveSpeed = 0f;
    private Vector3 m_groundNormal;
    private float m_checkGroundDistance;
    private Vector3 m_moveDir;
    private int m_weaponType;
    Vector3 cam_Forward;
    #endregion
    #region 用户键盘输入的指令变量
    [HideInInspector] public Vector3 inputAbsMoveDir = Vector3.zero;
    [HideInInspector] public Vector3 inputMoveDir=Vector3.zero;
    [HideInInspector] public float inputMoveMagnitude=0;
    [HideInInspector] public bool inputJump = false;
    [HideInInspector] public bool inputCrouch = false;
    [HideInInspector] public int inputWeaponType = 0;
    [HideInInspector] public bool inputFire = false;
    [HideInInspector] public bool inputReload = false;
    [HideInInspector] public bool inputTake = false;
    private Vector3 inputForward;
    private float inputLookHightAngle;
    #endregion

    #region 服务器传输过来的指令变量
    private Vector3 inputAbsMoveDirAsync = Vector3.zero;
    private Vector3 inputMoveDirAsync=Vector3.zero;
    private float inputMoveMagnitudeAsyn=0;
    private bool inputJumpAsync=false ;
    private bool inputCrouchAsync=false;
    private int inputWeaponTypeAsync=0;
    private bool inputFireAsync=false;
    private bool inputReloadAsync=false;
    private bool inputTakeAsync = false;
    private Vector3 inputForwardAsync = Vector3.zero;
    private Vector3 positionAsync ;
    private Vector3 eulerAsync;
    private float inputLookHightAngleAsync=0;
    #endregion
    //角色的使能判定标志
    private bool canFire;
    private bool isLoalRole=false;

    //游戏结束角色不再向服务器发送消息
    [HideInInspector]public bool gameEnd = false;
    private InputCommend commend=new InputCommend();

    #region 角色的状态标志
    /// <summary>
    /// 枪是否能够被换下或换弹夹
    /// </summary>
    public bool IsGunReady
    {
        get
        {
            if (reLoading) return false;
            if (weapons[currentWeapon - 1].Gun != null)
                return _gun != null;
            return false;
        }
    }
    /// <summary>
    /// 目前手里拿着的的武器id
    /// </summary>
    [Tooltip("目前手里拿着的的武器id")]
    public  int currentWeapon = 0;
    //武器的动作类型
    private int WeaponType
    {
        get
        {
            if (_weapon != null)
            {
                for (int i = 0; i < weapons.Length; i++)
                    if (weapons[i].Item == _weapon)
                        return (int)weapons[i].Type + 1;

                return 0;
            }

            if (currentWeapon > 0 && currentWeapon <= weapons.Length)
                return (int)weapons[currentWeapon - 1].Type + 1;

            return 0;
        }
    }
    private bool m_crouching;
    private bool m_isJumping;
    private bool m_isFalling;
    private bool m_isArmed;
    private bool m_onGround;
    private bool reLoading;
    private bool hasBeganReloading = false;
    private bool _isLive = true;
    #endregion
    #region private变量
    private bool _isChangingWeapon = false;
    private bool _isPreviousWeaponHidden = false;
    private WeaponAnimationStates _weaponStates = WeaponAnimationStates.Default();
    private float _reloadTime = 0;
    private float normalizedReloadTime = 0;
    private Vector3 _fireTarget;
    private Gun _gun;
    private GameObject _weapon;
    /// <summary>
    /// 目前使用的武器的枪组件。设置一个值将搜索武器数组，以获得适当的索引来输入
    /// </summary>
    public Gun Gun
    {
        get { return _gun; }
        set
        {
            for (int i = 0; i < weapons.Length; i++)
            {
                if (weapons[i].Gun == value)
                {
                    InputWeapon(i + 1);
                    break;
                }
            }
        }
    }

    /// <summary>
    /// 角色是否是要控制的角色
    /// </summary>
    public bool IsLoalRole
    {
        get
        {
            return isLoalRole;
        }

        set
        {
            isLoalRole = value;
        }
    }
    /// <summary>
    /// 角色要传输的动作命令
    /// </summary>
    public InputCommend Commend
    {
        get
        {
            return commend;
        }
    }


    #endregion
    public void SetFireFrom(Vector3 pos)
    {
        if (_gun != null)
            _gun.SetFireFrom(pos);
    }
    public void SetFireTarget(Vector3 dir)
    {
        _fireTarget = dir;
    }
    /// <summary>
    /// 角色是否处于一个可以瞄准的状态
    /// </summary>
    //public bool IsInAimableState
    //{
    //    get
    //    {
    //        if (currentWeapon <= 0 || currentWeapon > weapons.Length)
    //            return false;
    //        if()
    //    }
    //}

    #region Behaviour
    private void Awake()
    {
        characterHealth = GetComponent<CharacterHealth>();
    }
    void Start()
    {
        m_animator = GetComponent<Animator>();
        m_rigibody = GetComponent<Rigidbody>();
        m_capsule = GetComponent<CapsuleCollider>();
        capsuleCenter = m_capsule.center;
        capsuleHeight = m_capsule.height;
        currentWeapon = 0;
        inputWeaponType = currentWeapon;
        m_camera = Camera.main;
        locomotion = GetComponent<Locomotion>();
        freeLookCam = m_camera.transform.parent.parent.GetComponent<FreeLookCam>();
        damageRequest = GetComponent<DamageRequest>();
        positionAsync = transform.position;
        eulerAsync = transform.eulerAngles;

}
void Update()
    {
      
    }
    private void FixedUpdate()
    {
        ////向服务器端发送同步的消息
        //if (m_roleActionRequest != null)
        //{
        //    SendCharActionCommend();
        //}
     


        float Angle = freeLookCam.VerticalLookAngle;
        if(Angle>0)
        {
            inputLookHightAngle = Mathf.Clamp(Angle / 45f, -1, 1);
        }
        else
        {
            inputLookHightAngle = Mathf.Clamp(Angle / 75f, -1, 1);
        }
        inputForward = Vector3.Scale(m_camera.transform.forward, new Vector3(1, 0, 1));  //得到摄像机在水平面的前方向
                                                                                         // Debug.Log("inputForward" + inputForward);

        if (IsLoaclPlay)
        {
            inputAbsMoveDirAsync = inputAbsMoveDir;
            inputMoveDirAsync = inputMoveDir;
            inputMoveMagnitudeAsyn = inputMoveMagnitude;
            inputJumpAsync = inputJump;
            inputCrouchAsync = inputCrouch;
            inputWeaponTypeAsync = inputWeaponType;
            inputFireAsync = inputFire;
            inputReloadAsync = inputReload;
            inputTakeAsync = inputTake;
            inputForwardAsync = inputForward;
            inputLookHightAngleAsync = inputLookHightAngle;
            positionAsync = transform.position;
            eulerAsync = transform.eulerAngles;
        }
        else
        {
            if(gameEnd==false)   //游戏结束不再向服务器发送消息
            {
                SetActionCommend();
            }
            //同步位置和旋转角度
            transform.position = Vector3.Lerp(transform.position,positionAsync,lerp*Time.deltaTime);
            transform.eulerAngles = Vector3.Lerp(transform.eulerAngles,eulerAsync, lerp * Time.deltaTime);
        }
       
        Movement(inputMoveDirAsync, inputCrouchAsync, inputJumpAsync);
        if (Gun != null)
            //Debug.Log(reLoading + "__" + Gun.+ "___" + inputFire);
            if (!reLoading && inputFireAsync)
            {
                if (Gun != null && Gun.IsClipEmpty)
                    InputReload();
                else
                    InputFire();
            }
        //if(IsLoalRole==true)
        //{
           // Debug.Log("inputForwardAsync"+inputForwardAsync);
            //cam_Forward = inputForwardAsync;
            cam_Forward = inputForwardAsync;
            FollowCamForward(cam_Forward);
        //}

    }
    private void LateUpdate()
    {
        SetWeapon(inputWeaponTypeAsync);
        SetFireTarget(m_camera.transform.position + m_camera.transform.forward);
        UpdateAnimator();
        UpdateWeapons();
        UpdateFire();
        UpdateReload();
        canFire = false;
        hasBeganReloading = false;

    }

    private void OnAnimatorMove()
    {
        if (m_onGround && Time.deltaTime > 0)
        {
            Vector3 v = m_moveDir * moveSpeed * Time.deltaTime;
            if (m_crouching)
            {
                v *= 0.5f;
            }
            v.y = m_rigibody.velocity.y;
            m_rigibody.velocity = v;
        }
    }

    //private void OnTriggerEnter(Collider other)
    //{

    //}
    private GameObject previousHandItem = null;
    private WeaponType wantHandWeaponType;
    private void OnTriggerStay(Collider other)
    {
        if (other.gameObject.tag == "good" && other.GetComponent<Goods>() != null)
        {

            Vector3 vector = other.transform.position;
            vector = Camera.main.WorldToScreenPoint(vector);
            vector = vector + IronOffset;
            if(IsLoalRole)
            {
                ShowTakeIron(vector);
            }
            if (inputTakeAsync)
            {
                //Debug.Log(wantHandWeaponType);
                Goods goods = other.GetComponent<Goods>();
                WeaponType findType = goods.weaponDescription.Type;
                GameObject goodItem = goods.weaponDescription.Item;
                if(wantHandWeaponType!=findType)
                {
                    wantHandWeaponType = findType;
                }
                else if (wantHandWeaponType == findType && previousHandItem != null)   //角色捡起的武器的类型和手上拿的武器类型一致把之前手里的武器销毁掉
                {
                    Destroy(previousHandItem);
                }
                //else if (wantHandWeaponType != findType && previousHandItem != null)   //角色捡起的武器的类型和手上拿的武器类型不一致把之前手里的武器替换成要捡起的武器
                //{

                //    wantHandWeaponType = findType;
                //}
                for (int i = 0; i < weapons.Length; i++)
                {
                    if (findType == weapons[i].Type)
                    {
                        GameObject holdObj = GameObject.Instantiate(goodItem, holdHand);
                        if (previousHandItem == null)
                        {
                            previousHandItem = holdObj;
                        }
                        weapons[i].Item = holdObj;
                        inputWeaponType = i + 1;
                        Destroy(other.gameObject);
                        HideTakeIron();
                    }
                }

                //for (int i = 0; i < weapons.Length; i++)
                //{
                //    if (findType == weapons[i].Type)
                //    {
                //        GameObject holdObj = GameObject.Instantiate(goodItem, holdHand);
                //        if(previousItem==null)
                //        {
                //            previousItem = holdObj;
                //        }
                //        else if(previousItem!=holdObj)

                //        weapons[i].Item = holdObj;
                //        inputWeaponType = i + 1;
                //        Destroy(other.gameObject);
                //        HideTakeIron();
                //    }
                //}

            }


        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.gameObject.tag == "good" && other.GetComponent<Goods>() != null)
        {
            HideTakeIron();
        }
    }
    #endregion
    #region Private methods
    /// <summary>
    /// 设置要向服务器端发送动作指令
    /// </summary>
    private void SetActionCommend()
    {
        commend.PositionX = transform.position.x;
        commend.PositionY = transform.position.y;
        commend.PositionZ = transform.position.z;

        commend.EulerX = transform.eulerAngles.x;
        commend.EulerY = transform.eulerAngles.y;
        commend.EulerZ = transform.eulerAngles.z;

        commend.InputCrouch = inputCrouch;
        commend.InputFire = inputFire;
        commend.InputJump = inputJump;
        commend.InputMoveDirX = inputMoveDir.x;
        commend.InputMoveDirY = inputMoveDir.y;
        commend.InputMoveDirZ = inputMoveDir.z;
        commend.InputAbsMoveDirX = inputAbsMoveDir.x;
        commend.InputAbsMoveDirY = inputAbsMoveDir.y;
        commend.InputAbsMoveDirZ = inputAbsMoveDir.z;
        commend.InputForwordDirX = inputForward.x;
        commend.InputForwordDirY = inputForward.y;
        commend.InputForwordDirZ = inputForward.z;
        commend.InputMoveMagnitude = inputMoveMagnitude;
        commend.InputReload = inputReload;
        commend.InputTake = inputTake;
        commend.InputWeaponType = inputWeaponType;
        commend.InputLookHightAngle = inputLookHightAngle;
    }

    //角色的状态转变
    private void Movement(Vector3 dir, bool crouch, bool jump)
    {
       
       // dir = cam_Forward * dir.z + m_camera.transform.right * dir.x;   //得到以摄像机为原点，x,z轴都在水平面的一个方向向量
                                                                        // dir = transform.InverseTransformDirection(dir);   //转换为以角色为原点的一个方向向量
        CheckGroundStatus();
        m_moveDir = Vector3.ProjectOnPlane(dir, m_groundNormal); //使方向始终与平面平行
        if (m_onGround)
        {
            m_isJumping = false;
            HandleGroundMovement(crouch, jump);
        }
        else
        {
            HandleAirBorneMovement();
        }
        ScaleCapsuleForCrouch(crouch);
        PreventStandInLowRoom();
    }
    //检测地面
    private void CheckGroundStatus()
    {
        RaycastHit hitInfo;
#if UNITY_EDITOR
        Debug.DrawRay(transform.position + (Vector3.up * 0.1f), Vector3.down, Color.red, m_checkGroundDistance);
#endif
        if (Physics.Raycast(transform.position + (Vector3.up * 0.1f), Vector3.down, out hitInfo, m_checkGroundDistance))
        {
            m_groundNormal = hitInfo.normal;
            m_onGround = true;
        }
        else
        {
            m_onGround = false;
            m_groundNormal = Vector3.up;
        }
    }
    //处理在地面时跳的命令
    private void HandleGroundMovement(bool crouch, bool jump)
    {
        if (jump && !crouch)
        {
            if (m_isJumping || m_isFalling) return; //正在跳和正在下落不做处理
            m_rigibody.velocity = new Vector3(m_rigibody.velocity.x, m_jumpPower, m_rigibody.velocity.z);
            m_onGround = false;  //离开地面
            m_isJumping = true;
            m_checkGroundDistance = 0.1f;  //检测是否地面的射线变短

        }
    }
    //处理跳起后角色的运动
    private void HandleAirBorneMovement()
    {
        Vector3 extraForce = (Physics.gravity * m_gravityMultiplier) - Physics.gravity;
        m_rigibody.AddForce(extraForce);
        m_checkGroundDistance = m_rigibody.velocity.y < 0 ? m_origCheckGroundDis : 0.01f;  //调整检测的射线长度
        m_isFalling = m_onGround == false && m_rigibody.velocity.y < -9 ? true : false;  //当角色在空中开始下落时标志为true
                                                                                         //a Debug.Log(m_rigibody.velocity.y);
    }
    //处理蹲下时碰撞器的改变
    private void ScaleCapsuleForCrouch(bool crouch)
    {
        if (m_onGround && crouch)
        {
            if (m_crouching) return;  //角色此时正在蹲下
            m_capsule.center = m_capsule.center / 2f;
            m_capsule.height = m_capsule.height / 2f;
            m_crouching = true;
        }
        else
        {
            Ray crouchRay = new Ray(m_rigibody.position + Vector3.up * m_capsule.radius * k_half, Vector3.up);
            float RayLegth = capsuleHeight - m_capsule.radius * k_half;
            //发射一个椭圆射线射线的末端高出角色的头部半个m_capsule.radius
            if (Physics.SphereCast(crouchRay, m_capsule.radius * k_half, RayLegth, Physics.AllLayers, QueryTriggerInteraction.Ignore))
            {
                m_crouching = true;
                m_capsule.center = m_capsule.center / 2f;
                m_capsule.height = m_capsule.height / 2f;
            }
            m_crouching = false;
            m_capsule.center = capsuleCenter;
            m_capsule.height = capsuleHeight;
        }
    }
    //角色站立时在头上有障碍物时蹲下的ai处理
    private void PreventStandInLowRoom()
    {
        if (!m_crouching)
        {
            Ray crouchRay = new Ray(m_rigibody.position + Vector3.up * m_capsule.radius * k_half, Vector3.up);
            float RayLegth = capsuleHeight - m_capsule.radius * k_half;
            //发射一个椭圆射线射线的末端高出角色的头部半个m_capsule.radius
            if (Physics.SphereCast(crouchRay, m_capsule.radius * k_half, RayLegth, Physics.AllLayers, QueryTriggerInteraction.Ignore))
            {
                m_crouching = true;
                m_capsule.center = m_capsule.center / 2f;
                m_capsule.height = m_capsule.height / 2f;
            }
        }
    }
    //处理射击
    private void UpdateFire()
    {
        if (canFire)
        {
            _gun.CancelFire();
            _gun.TryFireNow();
        }
    }
    //设置枪的种类和是否换弹
    private void SetWeapon(int weaponType)
    {
        if (weaponType != -1)
        {
            m_weaponType = weaponType;
            currentWeapon = m_weaponType;
        }
        m_isArmed = currentWeapon != 0 ? true : false;
    }
    /// <summary>
    /// 尝试给枪换弹夹
    /// </summary>
    private void InputReload()
    {
        if (reLoading || _gun == null) return;

        reLoading = true;
        hasBeganReloading = false;
        _reloadTime = 0;
        normalizedReloadTime = 0;
    }

    private void InputFire()
    {
        if (currentWeapon <= 0) return;
        if (weapons[currentWeapon - 1].Gun != null)
        {
            canFire = true;
            //_gun.CancelFire();
            //_gun.TryFireNow();
        }
    }

    private void UpdateReload()
    {

        //if (Gun != null && Gun.AutoReload && Gun.Clip <= 0)
        //{
        //    InputReload();
        //}
        if (reLoading)
        {
            _reloadTime += Time.deltaTime;
            var info = m_animator.GetCurrentAnimatorStateInfo(FirstWeaponLayer + WeaponType);
            if (info.IsName(_weaponStates.Reload))
            {

                hasBeganReloading = true;
                reLoading = false;
                Debug.Log(reLoading + "c" + hasBeganReloading);
            }
            if (hasBeganReloading)
            {
                Debug.Log(reLoading + "d" + hasBeganReloading);
                if (info.normalizedTime >= 0.2f && _gun != null)
                    _gun.Reload();

                if (info.normalizedTime > normalizedReloadTime)
                    normalizedReloadTime = info.normalizedTime;

                if (normalizedReloadTime > 0.8f)
                    reLoading = false;
            }
            if (_reloadTime > 10)
                reLoading = false;
        }
        else
            _reloadTime = 0;
    }
    //根据输入的枪的种类选择相应的枪
    private void UpdateWeapons()
    {
        var weaponToShow = 0;
        if (inputWeaponTypeAsync < 0) inputWeaponTypeAsync = 0;
        else if (inputWeaponTypeAsync > weapons.Length) inputWeaponTypeAsync = currentWeapon;
        for (int i = 0; i < weapons.Length; i++)
        {
            if (_weapon == weapons[i].Item)
                weaponToShow = i + 1;
        }
        if (!_isChangingWeapon && !reLoading && inputWeaponTypeAsync != currentWeapon)
        {
            _isPreviousWeaponHidden = false;
            _isChangingWeapon = true;
            currentWeapon = inputWeaponTypeAsync;
        }
        if (_isChangingWeapon && !reLoading)
        {
            if (!_isPreviousWeaponHidden)
            {
                //if (_weapon == null)
                _isPreviousWeaponHidden = true;
            }
        }
        if (_isPreviousWeaponHidden)
        {
            if (currentWeapon == 0)
            {
                weaponToShow = 0;
                _isChangingWeapon = false;
            }
        }
        if (!_isChangingWeapon)
        {
            var previousWeapon = _weapon;
            var previousGun = _gun;
            if (currentWeapon > 0 && currentWeapon <= weapons.Length)
            {
                _weapon = weapons[currentWeapon - 1].Item;
                _gun = weapons[currentWeapon - 1].Gun;
            }
            else
            {
                _weapon = null;
                _gun = null;
            }

            if (previousGun != _gun)
            {
                if (previousGun != null) previousGun.CancelFire();
                if (_gun != null) _gun.CancelFire();
            }
        }

        for (int i = 0; i < weapons.Length; i++)
        {
            var show = weaponToShow == i + 1;
            var weapon = weapons[i];
            if (weapon.Item != null && weapon.Item.activeSelf != show) weapon.Item.SetActive(show);
            if (weapon.Holster != null && weapon.Holster.activeSelf != !show) weapon.Holster.SetActive(!show);
        }
        if (_gun != null)
        {
            _gun.Character = this;
            _gun.Allow(!m_isFalling);
            SetFireFrom(m_camera.transform.position);
            _gun.UpdateIntendedRotation();
            _gun.Target = _fireTarget;
        }

    }

    private void UpdateAnimator()
    {
        locomotion.DoMove(inputMoveDirAsync, inputAbsMoveDirAsync, m_isJumping, m_crouching);
        locomotion.DoArmed(inputWeaponTypeAsync, reLoading, inputLookHightAngleAsync);
        locomotion.CharacterChange(m_isJumping, m_isFalling, m_isArmed, m_onGround);
        locomotion.CharacterHealth(!_isLive);
        if(_fireTarget!=null&&_gun!=null)
        {
            locomotion.SetIKPos(_fireTarget, _gun.LeftHandDefault);
        }
  
    }

    private  void FollowCamForward(Vector3 forward)
    {
        transform.rotation = Quaternion.LookRotation(forward);
    }

    /// <summary>
    ///在固定的坐标下显示拾起的图标
    /// </summary>
    /// <param name="vector"></param>
    private void ShowTakeIron(Vector3 vector)
    {
        playerManage.ShowTakeIron(vector);
    }

    private void HideTakeIron()
    {
        playerManage.HidenTakeIron();
    }
    #endregion

    #region Public methods
   
    /// <summary>
    /// 角色是否受到伤害
    /// </summary>
    public void  IsCanDamage(bool can)
    {
        characterHealth.IsTakingDamage = can;
    }



    public void SendDamgeRequset(float value)
    {
       damageRequest.SendRequest(value);
    }

    public void SetPlayManage(PlayerManage player)
    {
        playerManage = player;
    }
    ////设置向其他客户端发送请求的类
    //public void SetRoleActionRequest(RoleActionRequest Request)
    //{
    //    m_roleActionRequest =Request;
    //}

    /// <summary>
    /// 设置异步的数据指令
    /// </summary>
    /// <param name="commend"></param>
    public void SetSyncInputCommed(InputCommend commend)
    {
        positionAsync.x = (float)commend.PositionX;
        positionAsync.y = (float)commend.PositionY;
        positionAsync.z = (float)commend.PositionZ;

        eulerAsync.x = (float)commend.EulerX;
        eulerAsync.y = (float)commend.EulerY;
        eulerAsync.z = (float)commend.EulerZ;

        inputMoveDirAsync.x = (float)commend.InputMoveDirX;
        inputMoveDirAsync.y = (float)commend.InputMoveDirY;
        inputMoveDirAsync.z = (float)commend.InputMoveDirZ;
        inputAbsMoveDirAsync.x = (float)commend.InputAbsMoveDirX;
        inputAbsMoveDirAsync.y = (float)commend.InputAbsMoveDirY;
        inputAbsMoveDirAsync.z = (float)commend.InputAbsMoveDirZ;
        // Debug.Log(commend.InputForwordDirX + "_" + commend.InputForwordDirY + "_" + commend.InputForwordDirZ);
        inputForwardAsync.x = (float)commend.InputForwordDirX;
        inputForwardAsync.y = (float)commend.InputForwordDirY;
        inputForwardAsync.z = (float)commend.InputForwordDirZ;
        inputMoveMagnitudeAsyn = (float)commend.InputMoveMagnitude;
        inputJumpAsync =commend.InputJump;
        inputCrouchAsync =commend.InputCrouch;
        inputWeaponTypeAsync =commend.InputWeaponType;
        inputTakeAsync = commend.InputTake;
        inputFireAsync = commend.InputFire;
        inputReloadAsync = commend.InputReload;
        inputLookHightAngleAsync = (float)commend.InputLookHightAngle;
}
    public void InputWeapon(int id)
    {
        if (id < 0)
            id = 0;
        else if (id > weapons.Length)
        {
            id = weapons.Length;
           
        }
        if (id != inputWeaponType)
            inputWeaponType = id;
        if (id > 0&&weapons[id - 1].Item == null)  //人物的武器列表里中的武器为空时
        {
            inputWeaponType = 0;
        }

    }
    public void OnDead()
    {
        _isLive = false;
    }


    #endregion
}


