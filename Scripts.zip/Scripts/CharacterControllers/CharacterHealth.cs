﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CharacterHealth : MonoBehaviour {
    /// <summary>
    /// 角色目前的生命值
    /// </summary>
    public float Health = 100f;
    /// <summary>
    /// 角色的最大生命值
    /// </summary>
    public float MaxHealth = 100f;
    /// <summary>
    /// 角色生命每秒回复值
    /// </summary>
    public float Regeneration = 0f;
    private float damageValue = 0;
    /// <summary>
    /// 角色是否受到伤害 调试时用
    /// </summary>
    [Tooltip(" 角色是否受到伤害 调试时用")]
    public bool IsTakingDamage = true;
    /// <summary>
    /// 子弹是否对主碰撞体造成伤害
    /// </summary>
    public bool IsRegisteringHits = true;

    private bool _isDead;

    private bool _isDamaging = false;

   //在编辑器模式下被调用，当检视面板的值改变时被调用
    private void OnValidate()
    {
        Health = Mathf.Max(0, Health); //保证生命值不小于0
        MaxHealth = Mathf.Max(0, MaxHealth);
    }
    private void LateUpdate()
    {
        if (_isDead)
        {
            Health = 0;
        }
        else
            Health = Mathf.Clamp(Health + Regeneration * Time.deltaTime, 0, MaxHealth);

        if(_isDamaging)
        {       
            //服务器传回来的伤害值
            Deal(damageValue);
            _isDamaging = false;
        }


    }


    public void OnDead()
    {
        _isDead = true;
    }
    /// <summary>
    ///枪的伤害值减少生命
    /// </summary>
    /// <param name="hit"></param>
    public void OnHit(Hit hit)
    {
        Deal(hit.Damage);
    }
    /// <summary>
    /// 生命值减少量
    /// </summary>
    /// <param name="amount"></param>
    public void Deal(float amount)
    {
        if (Health <= 0 || !IsTakingDamage)
            return;
        Health -= amount;
        if (Health <= 0)
            SendMessage("OnDead");
    }
    
    //异步显示受到伤害
    public void DamageAsync(float value)
    {
        _isDamaging = true;
        damageValue = value;
    }

}
