﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Locomotion : MonoBehaviour {

    private Vector3 target;
    private Transform leftHand;
    private Animator m_animator;
    private void Start()
    {
        m_animator = GetComponent<Animator>();
    }

    //用户输入影响的角色的基础动画状态
    public void DoMove(Vector3 dir, Vector3 absdir, bool isJumping,bool isCrounch)
    {
        m_animator.SetFloat("MovementInput", dir.magnitude);
        m_animator.SetFloat("MovementX", absdir.x);
        m_animator.SetFloat("MovementZ", absdir.z);
        m_animator.SetFloat("JumpLeg", absdir.x);
        m_animator.SetBool("IsJumping", isJumping);
        m_animator.SetBool("IsCrouch", isCrounch);
    }
    //用户输入影响的角色的武器动画状态
    public void DoArmed(int weaponType, bool reload,float hight)
    {
        m_animator.SetInteger("WeaponType", weaponType);
        m_animator.SetBool("IsReloading", reload);
        m_animator.SetFloat("LookHeight", hight);
    }
    //角色本身变化
    public void CharacterChange(bool isJumping,bool isFalling,bool isArmed,bool onGround)
    {
        m_animator.SetBool("IsJumping", isJumping);
        m_animator.SetBool("IsFalling", isFalling);
        m_animator.SetBool("IsArmed", isArmed);
        m_animator.SetBool("OnGround", onGround);
    }

    public void CharacterHealth(bool death)
    {
        m_animator.SetBool("Death", death);
    }

    public void  SetIKPos(Vector3 _tar,Transform _hand)
    {
        target = _tar;
        leftHand = _hand;
    }
    //private void OnAnimatorIK(int layerIndex)
    //{
    //    if (layerIndex == 1 || layerIndex == 2)
    //    {
    //        AnimatorStateInfo currentStateInfo = m_animator.GetCurrentAnimatorStateInfo(layerIndex);
    //        AnimatorStateInfo nextStateInfo = m_animator.GetNextAnimatorStateInfo(layerIndex);
    //        if (currentStateInfo.IsTag("aim") || nextStateInfo.IsTag("aim"))
    //        {
    //            m_animator.SetIKPositionWeight(AvatarIKGoal.LeftHand, 1f);
    //            m_animator.SetIKRotationWeight(AvatarIKGoal.LeftHand, 1f);
    //            m_animator.SetLookAtWeight(1.0f, 0.3f, 0.6f, 1.0f, 0.5f);
    //            if (target != null)
    //            {
    //                m_animator.SetLookAtPosition(target);
    //            }
    //            if (leftHand != null)
    //            {
    //                m_animator.SetIKPosition(AvatarIKGoal.LeftHand, leftHand.position);
    //                m_animator.SetIKRotation(AvatarIKGoal.LeftHand, leftHand.rotation);
    //            }
    //        }
    //        else
    //        {
    //            m_animator.SetIKPositionWeight(AvatarIKGoal.LeftHand, 0f);
    //            m_animator.SetIKRotationWeight(AvatarIKGoal.LeftHand, 0f);
    //            m_animator.SetLookAtWeight(0f);
    //        }


    //    }
    //}

}
