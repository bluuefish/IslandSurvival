﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
/// <summary>
/// 在枪的事件中产生效果和声音
/// </summary>
[RequireComponent(typeof(Gun))]
public class GunEffects : MonoBehaviour {
    /// <summary>
    /// 当弹出一个弹夹时产生的对象
    /// </summary>
    [Tooltip("当喷射一个弹夹时产生的对象")]
    public GameObject Eject;
    /// <summary>
    /// 当一个弹夹被放入枪中被实例化的对象
    /// </summary>
    [Tooltip("当一个弹夹被放入枪中被实例化的对象")]
    public GameObject Rechamber;
    /// <summary>
    /// 子弹开火实例化的火花
    /// </summary>
    [Tooltip("子弹开火实例化的火花")]
    public GameObject Fire;
    [Tooltip("模拟弹壳产生的粒子")]
    public GameObject Shell;

    private List<GameObject> _particles = new List<GameObject>();
    private Gun _gun;

    private void Awake()
    {
        _gun = GetComponent<Gun>();
    }

    public void OnReloadStart()
    {
        StartCoroutine(ReloadSequence());
    }
    /// <summary>
    /// 在几秒钟内，按一定的时间来播放火焰效果
    /// </summary>
    /// <param name="delay"></param>
    public void OnFire(float delay)
    {
        if (_gun != null && _gun.Aim != null)

            StartCoroutine(Play(delay, Fire, _gun.Aim.transform, Vector3.zero, Quaternion.identity));
        StartCoroutine(Play(delay, Shell, null, transform.position, Quaternion.identity));

    }
    private void LateUpdate()
    {
        int i = 0;
        while(i<_particles.Count)
        {
            if (_particles[i] == null)
                _particles.RemoveAt(i);
            else
                i++;
        }
        foreach (var item in _particles)
        {
            if (item == null)
                _particles.Remove(item);
        }
    }
    private void OnDisable()
    {
        foreach (var paeticle in _particles)
            if (paeticle != null)
                GameObject.Destroy(paeticle);

        _particles.Clear();

        StopAllCoroutines();

    }

    private IEnumerator ReloadSequence()
    {
        yield return Play(0.1f, Eject, null, transform.position, Quaternion.identity);
        yield return Play(0.6f, Rechamber, null, transform.position, Quaternion.identity);
    }
    private IEnumerator Play(float delay, GameObject prefab, Transform parent, Vector3 position, Quaternion rotation, float destroyAfter = 4f)
    {
        if (prefab == null)
            yield break;
    
            yield return new WaitForSeconds(delay);
            var particle = GameObject.Instantiate(prefab);
            particle.transform.parent = parent;
            particle.transform.localPosition = position;
            particle.transform.localRotation = rotation;
            particle.SetActive(true);
            _particles.Add(particle);
            GameObject.Destroy(particle, destroyAfter);
       
    }
}
