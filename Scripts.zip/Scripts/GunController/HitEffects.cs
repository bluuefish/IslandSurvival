﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HitEffects : MonoBehaviour {
    /// <summary>
    /// 产生的弹痕预制体
    /// </summary>
    public GameObject Effect;
    //弹痕消失的时间
    public float DestroyAfter = 5;

    public void OnHit(Hit hit)
    {
        if (Effect == null)
            return;

        var effect = GameObject.Instantiate(Effect);
        effect.transform.parent = null;
        effect.transform.position = hit.Position + hit.Normal * 0.1f;
        effect.SetActive(true);
        GameObject.Destroy(effect, 4);
    }
    private void OnValidate()
    {
        DestroyAfter = Mathf.Max(0, DestroyAfter);
    }
}
