﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//后座力的信息，在Gun脚本被调用
public struct RecoilImpulse
{
    /// <summary>
    /// 世界坐标下后坐力的方向
    /// </summary>
    public Vector3 Direction;
    /// <summary>
    /// 后座力的变化大小
    /// </summary>
    public float Progress;
    /// <summary>
    /// 实例化一个后座力
    /// </summary>
    /// <param name="dir"></param>
    public RecoilImpulse(Vector3 dir)
    {
        Direction = dir;
        Progress = 0.0f;
    }
}
