﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
[System.Serializable]
public struct RecoilSettings
{
    /// <summary>
    /// 一颗子弹开火的强度
    /// </summary>
    [Range(0,1)]
    public float Strength;
    /// <summary>
    /// 反冲力作用到右手的时间
    /// </summary>
    [Range(0, 1)]
    public float AttackTime;
    /// <summary>
    /// 反冲力衰退的时间
    /// </summary>
    [Range(0, 1)]
    public float DecayTime;
    /// <summary>
    /// 枪的抬起力
    /// </summary>
    [Range(-5, 5)]
    public float UpForce;
    /// <summary>
    /// 枪的反冲力的总和
    /// </summary>
    [Range(0, 1)]
    public float Limit;
    /// <summary>
    /// 默认的反冲力设置
    /// </summary>
    /// <returns></returns>
    public static RecoilSettings Default()
    {
        var settings = new RecoilSettings();
        settings.Strength = 0.1f;
        settings.AttackTime = 0.05f;
        settings.DecayTime = 0.25f;
        settings.UpForce = 0.5f;
        settings.Limit = 0.1f;

        return settings;
    }
    public static RecoilSettings RecoilSettingByValue(float str,float att,float dec,float upf,float lim)
    {
        var setting = new RecoilSettings();
        setting.Strength = str;
        setting.AttackTime = att;
        setting.DecayTime = dec;
        setting.UpForce = upf;
        setting.Limit = lim;
        return setting;
    }

}
