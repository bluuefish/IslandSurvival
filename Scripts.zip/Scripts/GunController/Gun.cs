﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Gun : MonoBehaviour{

    private Vector3 _lastAimOrigin;

    private float _recoilIntensity;

    private Vector3 _recoil;

    private bool _hasJustFired;

    private bool _isAllowed;

    private Renderer _renderer;
    /// <summary>
    /// 在世界坐标下产生子弹的坐标
    /// </summary>
    public Vector3 Origin
    {
        get { return _lastAimOrigin; }
    }
    /// <summary>
    /// 枪后座力改变时发射子弹的方向
    /// </summary>
    public Vector3 Direction
    {
        get { return GetRecoiledDirectionFrom(Origin); }
    }
    /// <summary>
    /// 从弹口到瞄准目标的最佳向量
    /// </summary>
    public Vector3 TargetDirection
    {
        get { return GetTargetDirectionFrom(Origin); }
    }
    /// <summary>
    /// 枪的后坐力强度 范围从0到1
    /// </summary>
    public float RecoilIntensity
    {
        get { return _recoilIntensity; }
    }
    /// <summary>
    /// 世界坐标下右手的偏移
    /// </summary>
    public Vector3 RecoilShift
    {
        get { return _recoil; }
    }
    /// <summary>
    /// 返回弹夹是否为空
    /// </summary>
    public bool IsClipEmpty
    {
        get { return Clip <= 0; }
    }
    /// <summary>
    ///返回true如果最近一次更新开火了
    /// </summary>

    public bool HasJustFired
    {
        get { return _hasJustFired; }
    }
    /// <summary>
    ///枪是否可以开火
    /// </summary>
    public bool IsAllowed
    {
        get { return _isAllowed; }
    }
    /// <summary>
    /// 打到物体上的弹孔
    /// </summary>
    public Renderer Renderer
    {
        get { return _renderer; }
    }
    /// <summary>
    /// 枪的名字
    /// </summary>
    public string Name = "Gun";
    /// <summary>
    /// 枪的图标
    /// </summary>
    public Sprite NameIcon;
    /// <summary>
    ///枪开镜时的相机深度
    /// </summary>
    public float Zoom = 0;
    /// <summary>
    /// 开镜的图标
    /// </summary>
    public Sprite Scope;
    /// <summary>
    /// 枪每秒的发射子弹个数，即速率
    /// </summary>
    public float Rate = 7;
    /// <summary>
    /// 枪的最远射击距离，超出距离被忽略
    /// </summary>
    public float Distance = 50;
    /// <summary>
    /// 一颗子弹的伤害
    /// </summary>
    public float Damag = 10;
    /// <summary>
    /// 在换弹时重新设置的弹夹容量
    /// </summary>
    public int ClipSize = 10;
    /// <summary>
    /// 枪的弹夹容量
    /// </summary>
    public int Clip = 10;
    /// <summary>
    /// 是否自动换挡
    /// </summary>
    public bool AutoReload = false;
    /// <summary>
    /// 枪的近身伤害
    /// </summary>
    public float MeleeDamage = 20;
    /// <summary>
    /// 在角色前面检测球的最远检测的距离
    /// </summary>
    public float MeleeDistance = 1.5f;
    /// <summary>
    /// 角色的近战检测球的半径
    /// </summary>
    public float MeleeRadius = 1.0f;
    /// <summary>
    /// 角色的近战检测的高度
    /// </summary>
    public float MeleeHeight = 0.5f;
    /// <summary>
    /// 下一次近身攻击的等待时间
    /// </summary>
    public float HitCooldown = 0.4f;
    /// <summary>
    /// 在编辑器下是否显示射线
    /// </summary>
    public bool DebugAim = false;
    /// <summary>
    /// 控制瞄准的方向的物体
    /// </summary>
    public GameObject Aim;
    /// <summary>
    /// 实例化的子弹
    /// </summary>
    public GameObject Bullet;
    /// <summary>
    /// 设置枪的反冲力
    /// </summary>
    public RecoilSettings recoilSettings = RecoilSettings.Default();
    /// <summary>
    /// 角色的左手相对于枪的位置
    /// </summary>
    public Transform LeftHandDefault;
    [HideInInspector]
    public CharacterMotor Character;
    /// <summary>
    /// 角色瞄准的目标位置
    /// </summary>
    [HideInInspector]
    public Vector3 Target;
    private bool _isUsingCustomRaycastOrigin;
    private Vector3 _customRaycastOrigin;

    private float _fireWait = 0;
    private bool _isGoingToFire;
    private bool _isFiringOnNextUpdate;
    private bool _wasAllowedAndFiring;

    private Vector3 _intendedForward;

    private float _hitWait = 0;

    private List<RecoilImpulse> _recoillmpulses = new List<RecoilImpulse>();
    private RaycastHit[] _hits = new RaycastHit[16];
    private LineRenderer _laser;
    private float _laserIntensity;

    private bool _isIgnoringSelf = true;
    private bool _hasFireCondition;
    private int _fireConditionSide; 

    /// <summary>
    /// 使用武器的命令
    /// </summary>
    public void ToUse()
    {
        TryFireNow();
    }

    /// <summary>
    /// 设置枪在下次更新时开火
    /// 枪只有在开火模式开着并且枪允许开火时才能开火
    /// </summary>
    public void TryFireNow()
    {
        _isFiringOnNextUpdate = true;
    }

    /// <summary>
    /// 设置枪的开火模式开，一直持续到CancekFir()被调用，或者枪正在开火
    /// 枪开火只有当枪开火模式开着而且枪时被允许开火
    /// </summary>
    public void FireWhenReady()
    {
        _isGoingToFire = true;
    }

    /// <summary>
    /// 设置开火模式为关闭
    /// </summary>
    public void CancelFire()
    {
        _isGoingToFire = false;
    }

    /// <summary>
    /// 设置枪是否可以开火，在更换武器和换弹夹时被调用
    /// </summary>
    /// <param name="value"></param>
    public void Allow(bool value)
    {
        _isAllowed = value;
    }
    /// <summary>
    ///返回子弹射线的起始点 
    /// </summary>
    private Vector3 RaycastOrigin
    {
        get { return _isUsingCustomRaycastOrigin ? _customRaycastOrigin : Origin; }
    }

    /// <summary>
    /// 设置子弹产生的位置，游戏中通常设置它为摄像机的位置
    /// </summary>
    /// <param name="point"></param>
    public void SetFireFrom(Vector3 point)
    {
        _isUsingCustomRaycastOrigin = true;
        _customRaycastOrigin = point;
    }
    /// <summary>
    /// 停止使用自定义的子弹产生点，默认从枪口的瞄准点开火
    /// </summary>
    public void StopFiringFromCustom()
    {
        _isUsingCustomRaycastOrigin = false;
    }

    /// <summary>
    /// 当通过Ik操作时设置瞄准点
    /// </summary>
    public void UpdateAimOrigin()
    {
        _lastAimOrigin = Aim == null ? transform.position : Aim.transform.position;
    }

    /// <summary>
    /// 在移动它之前，先设置好枪的前矢量。操作后的差值用于计算反冲方向。
    /// </summary>
    public void UpdateIntendedRotation()
    {
        _intendedForward = transform.forward;
    }

    private void LateUpdate()
    {
        _hasJustFired = false;
        if (_isGoingToFire)
            _isFiringOnNextUpdate = true;
        if (_hitWait >= 0)
            _hitWait -= Time.deltaTime;
        if(DebugAim)
        {
           // Debug.Log("RaycastOrigin" + RaycastOrigin + "Target"+ Target);
            Debug.DrawLine(RaycastOrigin, RaycastOrigin + GetRecoiledDirectionFrom(RaycastOrigin) * Distance, Color.red);
            Debug.DrawLine(_customRaycastOrigin, Target, Color.green);
        }
        //如果按下开火键，通知角色开火
        {
            var isAllowedAndFiring = _isGoingToFire && _isAllowed;

            if(Character!=null)
            {
                if (isAllowedAndFiring && !_wasAllowedAndFiring) Character.gameObject.SendMessage("OnStaetGunFire", SendMessageOptions.DontRequireReceiver);
                if (!isAllowedAndFiring && _wasAllowedAndFiring) Character.SendMessage("OnStopGunFire", SendMessageOptions.DontRequireReceiver);
            }
            _wasAllowedAndFiring = isAllowedAndFiring;
        }
        //更新后座力
        {
            //从射出一颗子弹开始力从一衰减到0
            _recoilIntensity -= Time.deltaTime * 10;

            //后座的衰减
            if(recoilSettings.DecayTime<=float.Epsilon)
            {
                //如果衰减时间是零或更少，清除后座的强度
                _recoil = Vector3.zero;
            }
            else
            {
                var recoilLeft = _recoil.magnitude;
                if(recoilLeft>float.Epsilon)
                {
                    var value = _recoil / recoilLeft;
                    var decrease = recoilSettings.Strength * Time.deltaTime / recoilSettings.DecayTime;
                    if (decrease >= recoilLeft)
                        _recoil = Vector3.zero;
                    else
                        _recoil -= value * decrease;
                }
            }
            //所有当前的反冲脉冲，并将其加到反冲位移
            if(recoilSettings.AttackTime<=float.Epsilon)
            {
                //如果攻击时间是零或者更少立即将所有的脉冲加起来
                foreach (var recoil in _recoillmpulses)
                    _recoil += recoil.Direction * recoilSettings.Strength;
                _recoillmpulses.Clear();
            }
            else
                for(int index=_recoillmpulses.Count-1;index>=0;index--)
                {
                    var recoil = _recoillmpulses[index];
                    recoil.Progress += Time.deltaTime / recoilSettings.AttackTime;
                    if (recoil.Progress >= 1)
                        _recoillmpulses.RemoveAt(index);
                    else
                    {
                        _recoillmpulses[index] = recoil;
                        _recoil += recoil.Direction * recoilSettings.Strength * Mathf.Clamp01(Time.deltaTime / recoilSettings.AttackTime);
                    }
                }
            if (_recoil.magnitude > recoilSettings.Limit)
                _recoil = _recoil.normalized * recoilSettings.Limit;
        }
        _fireWait -= Time.deltaTime;
       
        //检测触发是否按下
        if(_isFiringOnNextUpdate&&_isAllowed)
        {
            var fireDelay = 1.0f / Rate;

            var delay = 0f;
            
            if(_fireWait<0.5f*fireDelay&&fireDelay<recoilSettings.DecayTime+recoilSettings.AttackTime)
            {
                _recoilIntensity += Time.deltaTime * 20;
            }
            while(_fireWait<0)
            {
                if (!IsClipEmpty)
                    Fire(delay);
                delay += fireDelay;
                _fireWait += fireDelay;
                _isGoingToFire = false;
            }
        }
        _isFiringOnNextUpdate = false;
        _recoilIntensity = Mathf.Clamp01(_recoilIntensity);
        if (_fireWait < 0) _fireWait = 0;
    }
    /// <summary>
    /// 用射线投射出一颗子弹
    /// </summary>
    /// <param name="delay"></param>
    private void Fire(float delay=0)
    {
        //var hit = Raycast(RaycastOrigin, GetRecoiledDirectionFrom(RaycastOrigin));
        RaycastHit hit;
        var hits = Physics.Raycast(RaycastOrigin, GetRecoiledDirectionFrom(RaycastOrigin), out hit ,Distance );
        var end = hit.point;

        SendMessage("OnFire", delay, SendMessageOptions.DontRequireReceiver);
        _recoillmpulses.Add(new RecoilImpulse(Vector3.Lerp(-Direction, Vector3.up, recoilSettings.UpForce)));

        Clip--;

        if (hit.collider == null)
            end = RaycastOrigin + Distance * Direction;
        if (Bullet != null)
        {
            var bullet = GameObject.Instantiate(Bullet);
            bullet.transform.position = Origin;
            bullet.transform.parent = null;
            bullet.transform.LookAt(end);

            //手榴弹处理TODO
            if (hit.collider != null)
            {

                hit.collider.SendMessage("OnHit", new Hit(hit.point, -Direction, Damag, Character.gameObject, hit.collider.gameObject),
                 SendMessageOptions.DontRequireReceiver);
                bullet.SetActive(true);
                if (hit.collider.GetComponent<CharacterHealth>() != null&&Character.characterHealth.IsTakingDamage)  //当子弹打到敌人身上时
                {
                    Character.SendDamgeRequset(Damag);
                    Debug.Log("伤害请求");
                }
            }


        }
        else if (hit.collider != null)
        {
            hit.collider.SendMessage("OnHit", new Hit(hit.point, -Direction, Damag, Character.gameObject, hit.collider.gameObject),
                   SendMessageOptions.DontRequireReceiver);
            if(hit.collider.GetComponent<CharacterHealth>()!=null && Character.characterHealth.IsTakingDamage)  //当子弹打到敌人身上时
            {
                Character.SendDamgeRequset(Damag);
                Debug.Log("伤害请求");
            }
        }
        Debug.Log(hit.collider==null);
        if(hit.collider!=null&&Character!=null)
        {
            Character.SendMessage("OnSuccessfulHit", new Hit(hit.point, -Direction, Damag, Character.gameObject, hit.collider.gameObject),
                   SendMessageOptions.DontRequireReceiver);
            //if (hit.collider.GetComponent<CharacterHealth>() != null)  //当子弹打到敌人身上时
            //{
            //    Character.SendDamgeRequset(Damag);
            //    Debug.Log("伤害请求");
            //}

        }
           

        _hasJustFired = true;
    }
    /// <summary>
    /// 如果枪有线渲染器得到射线
    /// </summary>
    private void Start()
    {
        _laser = GetComponent<LineRenderer>();
        if(_laser!=null)
        {
            var material = _laser.material == null ? null : Material.Instantiate(_laser.material);
            _laser.material = material;
        }
    }
    /// <summary>
    /// 设置枪是否忽视射击到自己
    /// </summary>
    /// <param name="value"></param>
    public void IgnoreSelf(bool value=true)
    {
        _isIgnoringSelf = value;
    }
    /// <summary>
    /// 设置如果枪瞄准了同伴不射击
    /// </summary>
    /// <param name="side"></param>
    public void SetFirCondition(int side)
    {
        _hasFireCondition = true;
        _fireConditionSide = side;
    }
    /// <summary>
    /// 设置枪在任何情况下的射击
    /// </summary>
    public void CancelFireCondition()
    {
        _hasFireCondition = false;
    }
    /// <summary>
    /// 返回枪目前正在瞄准的对象
    /// </summary>
    /// <returns></returns>
    public GameObject FindCurrentAimedTarget()
    {
        var hit = Raycast();
        if (hit.collider != null)
            return hit.collider.gameObject;
        else
            return null;
    }
    /// <summary>
    /// 返回枪目前瞄准的具有CharacterHealth组件的游戏对象
    /// </summary>
    /// <returns></returns>
    public GameObject FindCurrentAimedHealthTarget()
    {
        return GetHealthTarget(FindCurrentAimedTarget());
    }
    /// <summary>
    /// 根据传入的对象找到具有该对象的具有CharacterHealth组件的对象
    /// </summary>
    /// <param name="target"></param>
    /// <returns></returns>
    public GameObject GetHealthTarget(GameObject target)
    {
        while(target!=null)
        {
            var health = target.GetComponent<CharacterHealth>();
            if(health!=null)
            {
                if (health.Health <= float.Epsilon)
                    target = null;
                //从这里跳出循环target等于具有CharacterHealth组件的对象
                break;
            }

            var parent = target.transform.parent;
            if (parent != null)
                target = parent.gameObject;
            else
                target = null;
        }
        return target;
    }

    private void OnValidate()
    {
        Distance = Mathf.Max(0, Distance);
    }
    /// <summary>
    /// 计算从给定的定的原点到目标的方向并且随着后座力调整方向
    /// </summary>
    /// <param name="origin"></param>
    /// <returns></returns>
    private Vector3 GetRecoiledDirectionFrom(Vector3 origin)
    {
        var rotation = Quaternion.FromToRotation(_intendedForward, transform.forward);
        var vector = GetTargetDirectionFrom(origin);
        vector.y = (rotation * vector).y;
        return vector.normalized;
    }
    /// <summary>
    /// 计算从起始点到目标的向量
    /// </summary>
    /// <param name="origin"></param>
    /// <returns></returns>
    private Vector3 GetTargetDirectionFrom(Vector3 origin)
    {
        var value = Target - origin; //目标到起始点的距离
        if (value.magnitude > float.Epsilon)
            value.Normalize();
        return value;
    }
    /// <summary>
    /// 发现射线
    /// </summary>
    private void Awake()
    {
        _renderer = GetComponent<Renderer>();
    }
    /// <summary>
    /// 清除枪的后座力，当枪再次被使用时时无后座力的
    /// </summary>
    private void OnDisable()
    {
        _recoillmpulses.Clear();
    }
    /// <summary>
    /// 设置弹药数为弹夹的容量
    /// </summary>
    public void Reload()
    {
        Clip = ClipSize;
    }

    /// <summary>
    /// 执行近身攻击，动画由角色执行
    /// </summary>
    public void Hit()
    {
        if (Character == null || _hitWait > 0)
            return;
        _hitWait = HitCooldown;
        var positon = Character.transform.position + Vector3.up * MeleeHeight;
        var bestHit = new RaycastHit();
        var bestHitHasHealth = false;
        //近身攻击检测
        for(int i=0;i<Physics.SphereCastNonAlloc(positon,MeleeRadius,Character.transform.forward,_hits,MeleeDistance);i++)
        {
            if(_hits[i].collider!=null&&_hits[i].collider.gameObject!=null&&_hits[i].collider.gameObject!=Character)
         {
            var hit = _hits[i];
            var hasHealth = hit.collider.GetComponent<CharacterHealth>() != null;
                if (bestHit.collider == null || (hasHealth && !bestHitHasHealth)
                    || (hit.distance < bestHit.distance && (!bestHitHasHealth || hasHealth)))
                    {
                    bestHit = hit;
                    bestHitHasHealth = hasHealth;
                }
            }
        }
        if (bestHit.collider != null)
            bestHit.collider.SendMessage("OnHit", new Hit(bestHit.point, bestHit.normal, MeleeDamage, Character.gameObject, bestHit.collider.gameObject)
                , SendMessageOptions.DontRequireReceiver);
    }

    public RaycastHit Raycast()
    {
        return Raycast(RaycastOrigin, Direction);
    }
    /// <summary>
    /// 如果开火找到打击到的物体和打击的位置，检测是否是同伴
    /// </summary>
    /// <param name="origin"></param>
    /// <param name="direction"></param>
    /// <param name="isFriend"></param>
    /// <param name="friendCheck"></param>
    /// <returns></returns>
    public RaycastHit Raycast(Vector3 origin,Vector3 direction/*,bool friendCheck*/)
    {
        RaycastHit closesHit = new RaycastHit();
        float closetDistance = Distance * 10;
        var minDistance = 0f;
        if(_isUsingCustomRaycastOrigin)
        {
            minDistance = Vector2.Distance(Origin, RaycastOrigin);
            for(int i=0;i<Physics.RaycastNonAlloc(origin,direction,_hits,Distance); i++)
            {
                var hit = _hits[i];
                if (Character != null) continue;
                if(hit.distance<closetDistance&&hit.distance>minDistance)
                {
                    var isOk = true;
                    if(hit.collider.isTrigger)
                    {
                        isOk = hit.collider.GetComponent<BodyPartHealth>() != null;

                    }
                    else
                    {
                        var health = hit.collider.GetComponent<CharacterHealth>();
                        if (health != null)
                            isOk = health.IsRegisteringHits;
                    }
                    if(isOk)
                    {
                        closesHit = hit;
                        closetDistance = hit.distance;
                    }
                }
            }
        }
        return closesHit;
    }

  

}
