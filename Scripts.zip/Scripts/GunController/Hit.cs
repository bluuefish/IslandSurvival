﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Hit : MonoBehaviour {
    //表示一颗子弹的打击，在OnHit事件发生时调用
    /// <summary>
    /// 在世界坐标下打击的位置
    /// </summary>
    public Vector3 Position;
    /// <summary>
    ///世界坐标下的打击位置的法向量，打击的物体表面从内往外
    /// </summary>

    public Vector3 Normal;
    /// <summary>
    /// 打击的对象所受的伤害
    /// </summary>
    public float Damage;
    /// <summary>
    /// 造成伤害的武器的使用者
    /// </summary>
    public GameObject Attacker;
    /// <summary>
    /// 被打击的对象
    /// </summary>
    public GameObject Target;
    public Hit(Vector3 pos,Vector3 normal,float damage,GameObject attacker,GameObject target)
    {
        Position = pos;
        Normal = normal;
        Damage = damage;
        Attacker = attacker;
        Target = target;
    }
}

