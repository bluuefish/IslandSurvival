﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(ThirdPersonCharacter))]
public class ThirdPersonControl : MonoBehaviour {

    private ThirdPersonCharacter m_character;
    private Transform m_cam;
    private Vector3 camForward;
    private Vector3 move;
    private bool m_jump;
    private void Start()
    {
        if (Camera.main != null)
        {
            m_cam = Camera.main.transform;
        }
        else
        {
            Debug.LogWarning("场景中缺少主摄像机");
        }
        m_character = GetComponent<ThirdPersonCharacter>();
    }
    private void Update()
    {
        if(!m_jump)
        {
            m_jump = Input.GetButtonDown("Jump");
        }
    }
    private void FixedUpdate()
    {
        //读取输入
        float h = Input.GetAxis("Horizontal");
        float v = Input.GetAxis("Vertical");
        bool crouch = Input.GetKey(KeyCode.C);
        if(m_cam!=null)
        {
            camForward = Vector3.Scale(m_cam.forward, new Vector3(1, 0, 1)).normalized;
            move = v * camForward + h * m_cam.right;
        }
        else
        {
            move = v * Vector3.forward + h * Vector3.right;
        }
        if (Input.GetKey(KeyCode.LeftShift)) move *= 0.5f;

        m_character.Move(move, crouch, m_jump);
        if(Mathf.Abs(h)<0.1f)
        {
            m_character.FollowCamForward(camForward);
        }
        m_jump = false;
    }
}
