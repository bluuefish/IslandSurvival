﻿using System;
using UnityEngine;

    public static class UnityTools
    {
    public static Vector3 ParseVector3(string data)
    {
        string[] str = data.Split(',');
        float x = float.Parse(str[0]);
        float y = float.Parse(str[1]);
        float z = float.Parse(str[2]);
        return new Vector3(x, y, z);
    }
    }

