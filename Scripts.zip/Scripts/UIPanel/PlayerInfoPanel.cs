﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerInfoPanel : BasePanel {
    [SerializeField] private Text nameText;
    [SerializeField] private Text winCountText;
    [SerializeField] private Text totalCountText;
    [SerializeField] private Button closeButton;
    protected override void Awake()
    {
        base.Awake();
    }
    private void Start()
    {
        if (closeButton != null) closeButton.onClick.AddListener(OnCloseCallBack);
    }

    public override void OnEnter()
    {
        base.OnEnter();
        UpdateUserInfo();
    }

    private void OnCloseCallBack()
    {
        uiMng.PopPanel();
    }


    private void UpdateUserInfo()
    {
       nameText.text=gameFac.GetAccountinfo().AccountName;
       totalCountText.text="总场数："+gameFac.GetUserInfo().TotalCount.ToString();
        winCountText.text ="胜场数："+ gameFac.GetUserInfo().WinCount.ToString();
    }


}
