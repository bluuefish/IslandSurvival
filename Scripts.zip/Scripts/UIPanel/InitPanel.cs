﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class InitPanel : BasePanel {
    [SerializeField] private Button loginButton;
    //private Animator BtnAni;
    private void Update()
    {
        if (uiMng != null && uiMng.CurPanelNotInteract)
        {
            NotInteract();
        }
        else
        {
            Interactable();
        }
    }
    public override void OnEnter()
    {
        base.OnEnter();
        //loginButton = transform.Find("LoginButton").GetComponent<Button>();
       // BtnAni = transform.Find("LoginButton").GetComponent<Animator>();
        loginButton.onClick.AddListener(OnClickCall);
    }
    private void OnClickCall()
    {
            uiMng.PushPanel(UIPanelType.Login);
            
    }
    public override void OnPause()
    {
        base.OnPause();
        //BtnAni.enabled = false;
        gameObject.SetActive(false);
    }
    public override void OnResume()
    {
        base.OnResume();
        gameObject.SetActive(true);
       // BtnAni.enabled = true;
    }
    public void Interactable()
    {
        if (canvasGroup == null) return;
        canvasGroup.alpha = 1;
        if (canvasGroup.interactable || canvasGroup.alpha == 1) return;
        canvasGroup.interactable = true;
    }
    public void NotInteract()
    {
        if (canvasGroup == null) return;
        canvasGroup.alpha = 0;
        canvasGroup.interactable = false;

    }
}
