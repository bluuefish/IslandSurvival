﻿using System.Collections;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using UnityEngine;
using DG.Tweening;
using UnityEngine.UI;
using Common;
using LitJson;

public class LoginPanel : BasePanel {

    [SerializeField] private Button closeButton;
    [SerializeField] private Button loginButton;
    [SerializeField] private Button registerButton;
    [SerializeField] private InputField nameInput;
    [SerializeField] private InputField passwordInput;
    private  LoginRequest loginReq;
    private AccountInfo accountInfo;

    private string m_nameText;
    private string m_passwordText;

    private bool IsLoadSuccess = false;
    /// <summary>
    /// 判定用户输入是否合法
    /// </summary>
    private bool isRegularInput;
    protected override void Awake()
    {
        base.Awake();
    }
    protected  void Start()
    {
        loginReq = GetComponent<LoginRequest>();
        if (closeButton != null) closeButton.onClick.AddListener(CloseCallBack);
        if (loginButton != null) loginButton.onClick.AddListener(OnLoginCallBack);
        if (registerButton != null) registerButton.onClick.AddListener( () => { PlayClickSound(); uiMng.PushPanel(UIPanelType.Register); });
       
    }

    private void Update()
    {
        if (IsLoadSuccess)
        {
            gameFac.SetWantJumpScene("MainScene");
            gameFac.LoadTransitionScene();
            IsLoadSuccess = false;
        }
    }
    public override void OnEnter()
    {
        base.OnEnter();
        transform.gameObject.SetActive(true);
       
        //transform.localScale = Vector3.zero;
        //transform.DOScale(1, 0.3f);
    }

    //点击关闭按钮回调
    private void CloseCallBack()
    {
        PlayClickSound();
        transform.DOScale(0, 0.3f).OnComplete(DoScaleCallBack);
        //DoScaleCallBack();
    }


    //点击登录按钮回调
    private void OnLoginCallBack()
    {
        PlayClickSound();
        m_nameText = nameInput.text;
        m_passwordText = passwordInput.text;
        accountInfo = new AccountInfo(0, m_nameText, m_passwordText);
        FilterInput();
        if(isRegularInput)
        {
           // string data = JsonMapper.ToJson(accoutInfo);
            // loginReq.SendRequest(_nameText, _passwordText);
            loginReq.SendRequest(accountInfo);
        }

    }

    private void DoScaleCallBack()
    {
        uiMng.PopPanel();    //Bug每次运行都会自动加一次运行   
    }

    //对服务器返回的不同状态值进行反应
    public void LoginOnReponse(ReturnCode returnCode)
    {
        if(returnCode==ReturnCode.Success)
        {
            //  uiMng.PushPanelAsyn(UIPanelType.RoomList);
            //TODO进入房间
            uiMng.ShowMessageAsyn("登入成功");
            IsLoadSuccess = true;
        }
        if(returnCode==ReturnCode.Fail)
        {
            uiMng.ShowMessageAsyn("登入失败，账号或密码错误，请重新输入");
            IsLoadSuccess = false;
        }
        
    }
  
    public override void OnPause()
    {
        base.OnPause();
        nameInput.text = "";
        passwordInput.text = "";
        transform.gameObject.SetActive(false);
    }
    public override void OnResume()
    {
        base.OnResume();
        transform.gameObject.SetActive(true);
    }
    public override void OnExit()
    {
        base.OnExit();
        nameInput.text = "";
        passwordInput.text = "";
        transform.gameObject.SetActive(false);
    }

    /// <summary>
    /// 过滤不合理的输入
    /// </summary>
    private void FilterInput()
    {
        if (string.IsNullOrEmpty(m_nameText) && string.IsNullOrEmpty(m_passwordText))
        {
            uiMng.ShowMessage("账号和密码不可为空");
            isRegularInput = false;
        }
        else if (string.IsNullOrEmpty(m_nameText))
        {
            uiMng.ShowMessage("账号不可为空");
            isRegularInput = false;
        }
        else if (string.IsNullOrEmpty(m_passwordText))
        {
            uiMng.ShowMessage("密码不可为空");
            isRegularInput = false;
        }
        else   //进行正则表达判定
        {
            string namePattern = @"^[a-zA-Z0-9]{4,16}$";
            string passwordPattern = @"^[a-zA-Z]\w{5,17}$";
            bool regexName=Regex.IsMatch(m_nameText, namePattern);
            bool regexPassword=Regex.IsMatch(m_passwordText, passwordPattern);
            isRegularInput = regexName && regexPassword;
            Debug.Log(isRegularInput+"name"+regexName+"pass"+regexPassword);
            if(isRegularInput==false)
            {
                uiMng.ShowMessage("请输入正确的用户名或密码格式");
            }
        }
    }
}
