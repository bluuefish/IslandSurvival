﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;
using Common;
public class GamePanel : BasePanel {
    public Image aiming;
    public  Text timer;
    public Text healthText;
    public Text clipText;
    public Slider healthSlider;
    public Image gunIron;
    public GameObject damgeIron;
    public GameObject endPanel;
    public Text endTip;
    public Button ensurebtn;
    public RectTransform takeTip;
    private StartTimerRequest startTimerRequest;
    private StartPlayRequest startPlayRequest;
    private int t = -1;
    private bool isStartTimer = false;

    private bool isDamage = false;
    // Use this for initialization
    protected override void Awake()
    {
        base.Awake();
        startPlayRequest = GetComponent<StartPlayRequest>();
        startTimerRequest = GetComponent<StartTimerRequest>();
    }
    void Start () {
        timer.gameObject.SetActive(false);
       // StartPlayerRequest();
        //successTip.gameObject.SetActive(false);
        //defeatedTip.gameObject.SetActive(false);
        //ensurebtn.gameObject.SetActive(false);
        ensurebtn.onClick.AddListener(OnclickEnsure);
    }
    private void Update()
    {
        UpdateRoleData();
        if (t>-1)
        {
            ShowTime(t);
            t = -1;
        }
        //if(isStartTimer)
        //{
        //    startPlayRequest.SendRequest();
        //    isStartTimer = false;
        //}
        if(isDamage)
        {
            ShowDamageTip();
            isDamage = false;
        }
    }
    public void ShowTimeync(int _t)
    {
        t = _t;
    }

    public void OnclickEnsure()
    {
        gameFac.SetWantJumpScene("MainScene");
        gameFac.LoadTransitionScene();
        gameFac.GameOver();
    }

    public void StartPlayerRequest()
    {
        Debug.Log("dog"+startPlayRequest.name);
        startPlayRequest.SendRequest();
        //isStartTimer = true;
    }

    public void UpdateRoleData()
    {
        healthText.text = "HP " + gameFac.GetRoleHealth() + "/" + gameFac.GetRoleMaxHealth();
        if(Input.GetKeyDown(KeyCode.M))
        {
            Debug.Log(gameFac.GetRoleHealth());
        }
       
        healthSlider.value = gameFac.GetRoleHealth() / gameFac.GetRoleMaxHealth();
        if (gameFac.IsUseWeapon())
        {
            clipText.gameObject.SetActive(true);
            gunIron.gameObject.SetActive(true);
            clipText.text = gameFac.GetRoleGunClip() + "/" + gameFac.GetRoleGunClipSize();
            gunIron.sprite = gameFac.GetRoleGunIron();
        }
        else
        {
            clipText.gameObject.SetActive(false);
            gunIron.gameObject.SetActive(false);
        }
      
    }
    public void ShowTime(int t)
    {
        timer.gameObject.SetActive(true);
        timer.text = "00:" + t;
        timer.transform.localScale = Vector3.one;
       // Color tempColor = timer.color;
        //tempColor.a = 1;
        //timer.color = tempColor;
        //timer.transform.DOScale(2, 0.3f).SetDelay(0.3f);
        //timer.DOFade(0, 0.3f).SetDelay(0.3f).OnComplete(()=>timer.gameObject.SetActive(false));
        //gameFac.PlayEffectSound(AudioManager.sound_Alert);

    }
    public void HideTime()
    {
        timer.text = "bbbbb";
        timer.transform.localScale = Vector3.zero;
        timer.gameObject.SetActive(false);
    }
        public void ShowTakeIronIn(Vector3 vector)
    {
        takeTip.gameObject.SetActive(true);
        takeTip.position = vector;

    }

   public void HideHealthTip()
    {
        healthSlider.gameObject.SetActive(false);
        healthText.gameObject.SetActive(false);
    }

    public void ShowHealthTip()
    {
        healthSlider.gameObject.SetActive(true);
        healthText.gameObject.SetActive(true);
    }

    public void ShowAim()
    {
        aiming.gameObject.SetActive(true);
    }

    public void HideAim()
    {
        aiming.gameObject.SetActive(false);
    }

    public void HideTakeIronIn()
    {
        takeTip.position = Vector3.zero;
        takeTip.gameObject.SetActive(false);
    }
    public void GameOverResponse(ReturnCode returnCode)
    {
            switch (returnCode)
            {
                case ReturnCode.Fail:
                    gameFac.WhileGameEnd();
                    gameFac.GetLookCam().m_lockCursor = false;
                    endPanel.SetActive(true);
                    endTip.gameObject.SetActive(true);
                    endTip.text = "失败";
                    break;
                case ReturnCode.Success:
                    gameFac.WhileGameEnd();
                    gameFac.GetLookCam().m_lockCursor = false;
                    endPanel.SetActive(true);
                    endTip.gameObject.SetActive(true);
                    endTip.text = "成功";
                    break;
                default:
                    break;
            }
       
    }

    /// <summary>
    /// 响应服务器发送的受伤回应
    /// </summary>
    public void TakeDamageResponse()
    {
        isDamage = true;
    }

    /// <summary>
    /// 显示角色受伤的UI
    /// </summary>
    public void ShowDamageTip()
    {
        CanvasGroup canvasGroup = damgeIron.GetComponent<CanvasGroup>();
        canvasGroup.alpha = 1;
        canvasGroup.DOFade(0, 0.5f);
    }

    public override void OnEnter()
    {
        gameObject.SetActive(true);
        endPanel.SetActive(false);
        StartPlayerRequest();
        base.OnEnter();
    }
    public override void OnExit()
    {
        gameObject.SetActive(false);
        //successTip.gameObject.SetActive(false);
        //defeatedTip.gameObject.SetActive(false);
        //ensurebtn.gameObject.SetActive(false);
        base.OnExit();
    }
}
