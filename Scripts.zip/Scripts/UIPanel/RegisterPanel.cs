﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;
using Common;
using System.Text.RegularExpressions;

public class RegisterPanel : BasePanel{


    [SerializeField] private InputField userNameIF;
    [SerializeField] private InputField passwordIF;
    [SerializeField] private InputField rePasswordIF;
    [SerializeField] private Button registerButton;
    [SerializeField] private Button backLoginButton;
    [SerializeField] private Button closeButton;
    [SerializeField] private Toggle isShowPwd;
    [SerializeField] private Toggle isShowRePwd;
    private RegisterRequest registerRequest;

    private string m_userName;
    private string m_password;
    private string m_repassword;
    private bool isRegularInput;
    protected void Start()
    {
        registerRequest = GetComponent<RegisterRequest>();
      if(closeButton!=null)  closeButton.onClick.AddListener(OnCloseBack);
        if (backLoginButton != null) backLoginButton.onClick.AddListener(OnBackLoginCallBack);
        if (registerButton!=null)  registerButton.onClick.AddListener(OnRegisterCallBack);
      if (isShowPwd != null) isShowPwd.onValueChanged.AddListener(OnShowPwdCallBack);
      if (isShowRePwd != null) isShowRePwd.onValueChanged.AddListener(OnShowRePwdCallBack);

    }


    /// <summary>
    /// 点击关闭按钮
    /// </summary>
    private void OnCloseBack()
    {
        PlayClickSound();
        uiMng.PopPanel();
    }

    /// <summary>
    /// 点击返回登录按钮
    /// </summary>
    private void OnBackLoginCallBack()
    {
        OnCloseBack();
    }
    /// <summary>
    /// 点击注册按钮
    /// </summary>
    private void OnRegisterCallBack()
    {
        PlayClickSound();
        m_userName = userNameIF.text;
        m_password = passwordIF.text;
        m_repassword = rePasswordIF.text;
        AccountInfo accountInfo = new AccountInfo(0, m_userName, m_password);
        FilterInput();
        if (isRegularInput == false) return;
        else
        {
            registerRequest.SendRequest(accountInfo);
        }
    }

    /// <summary>
    /// 显示密码
    /// </summary>
    /// <param name="ison"></param>
    private void OnShowPwdCallBack(bool ison)
    {

      passwordIF.contentType = ison ? InputField.ContentType.Standard: InputField.ContentType.Password;
        passwordIF.Select();

    }
    /// <summary>
    /// 显示重复密码
    /// </summary>
    /// <param name="ison"></param>
    private void OnShowRePwdCallBack(bool ison)
    {
        rePasswordIF.contentType = ison ? InputField.ContentType.Standard : InputField.ContentType.Password;
        rePasswordIF.Select();
    }

    /// <summary>
    /// 过滤不合理的输入
    /// </summary>
    private void FilterInput()
    {
        if (string.IsNullOrEmpty(m_userName) && string.IsNullOrEmpty(m_password))
        {
            uiMng.ShowMessage("账号和密码不可为空");
            isRegularInput = false;
        }
        else if (string.IsNullOrEmpty(m_userName))
        {
            uiMng.ShowMessage("账号不可为空");
            isRegularInput = false;
        }
        else if (string.IsNullOrEmpty(m_password))
        {
            uiMng.ShowMessage("密码不可为空");
            isRegularInput = false;
        }else if(m_repassword!=m_password)
        {
            uiMng.ShowMessage("两次密码不一致");
            isRegularInput = false;
        }
        else   //进行正则表达判定
        {
            string namePattern = @"^[a-zA-Z0-9]{4,16}$";
            string passwordPattern = @"^[a-zA-Z]\w{5,17}$";
            bool regexName = Regex.IsMatch(m_userName, namePattern);
            bool regexPassword = Regex.IsMatch(m_password, passwordPattern);
            isRegularInput = regexName && regexPassword;
            if (!isRegularInput)
            {
                uiMng.ShowMessage("请输入正确的用户名或密码格式");
            }
        }
    }

    ////发送注册消息
    //private void SendRegister()
    //{
    //    PlayClickSound();

    //    string msg = " ";
    //    if(string.IsNullOrEmpty(userNameIF.text))
    //    {
    //        msg+="用户名不能为空";
    //    }
    //    if(string .IsNullOrEmpty(passwordIF.text))
    //    {
    //        msg += "\n密码不能为空";
    //    }
    //    if(rePasswordIF.text!= passwordIF.text)
    //    {
    //        msg += "\n输入的密码不一致";
    //    }
    //    if(msg!=" ")
    //    {
    //        uiMng.ShowMessage(msg); return;
    //    }
    //    registerRequest.SendRequest(userNameIF.text, passwordIF.text);
    //}


    //UI面板处理服务器的回应
    public void OnResponseRegister(ReturnCode returnCode)
    {
        if(returnCode==ReturnCode.Success)
        {
            uiMng.ShowMessageAsyn("注册成功");
        }
        else
        {
            uiMng.ShowMessageAsyn("注册失败，用户名重复");
        }
    }

    public override void OnEnter()
    {
        base.OnEnter();
        gameObject.SetActive(true);
        transform.localScale = Vector3.zero;
        transform.DOScale(1, 0.3f);
    }

    public override void OnExit()
    {
        base.OnExit();
        userNameIF.text = " ";
        passwordIF.text = " ";
        rePasswordIF.text = " ";
        gameObject.SetActive(false);
    }
}
