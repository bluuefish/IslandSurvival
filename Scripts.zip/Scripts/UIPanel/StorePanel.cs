﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class StorePanel : BasePanel {
    [SerializeField] private Button closeBtn;
    [SerializeField] private Toggle toggle_role;
    [SerializeField] private Toggle toggle_skin;
    protected override void Awake()
    {
        base.Awake();
    }
    protected void Start()
    { 
        if (closeBtn != null) closeBtn.onClick.AddListener(OnCloseCallBack);
    }

    private void OnCloseCallBack()
    {
        uiMng.PopPanel();
    }


}
