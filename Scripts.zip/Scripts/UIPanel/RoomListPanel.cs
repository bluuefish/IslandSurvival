﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Common;

public class RoomListPanel :BasePanel{

    public Text userName;
    public Text totalCount;
    public Text winCount;
    public Button closeButton;
    public Button CreateRoomButton;
    public Button RefreButton;

    private VerticalLayoutGroup verGroup;
    private GameObject perRoomPrefab;

    private ListRoomRequset listRoomRequset;
    private CreateRoomRequest createRoomRequest;
    private JoinRoomRequest joinRoomRequest;
    //处理显示房间列表相应的线程冲突
    private List<UserData> userDatas = null;
    //处理加入房间相应的线程冲突
    private UserData usd1 = null;
    private UserData usd2 = null;
    private void Start()
    {
        listRoomRequset = GetComponent<ListRoomRequset>();
        createRoomRequest = GetComponent<CreateRoomRequest>();
        joinRoomRequest = GetComponent<JoinRoomRequest>();
        verGroup = GetComponentInChildren<VerticalLayoutGroup>();
        closeButton.onClick.AddListener(() => uiMng.PopPanel());
        perRoomPrefab = Resources.Load("UIPanel/perRoom") as GameObject;
        CreateRoomButton.onClick.AddListener(CreateBoom);
        RefreButton.onClick.AddListener(RefreList);
       // listRoomRequset.SendRequest();
    }

    private void Update()
    {
        if (userDatas!=null)
        {
            LoadRoomList(userDatas);
            userDatas = null;
        }
        if(usd1!=null&&usd2!=null)
        {
            BasePanel panel = uiMng.PushPanel(UIPanelType.Room);
            (panel as RoomPanel).SetAllInfSync(usd1, usd2);
            usd1 = null;
            usd2 = null;
        }
    }

    public override void OnEnter()
    {
        SetUserinfo();
        transform.gameObject.SetActive(true);
        if (listRoomRequset == null)
            listRoomRequset = GetComponent<ListRoomRequset>();
        listRoomRequset.SendRequest();
    }
    public override void OnExit()
    {
        transform.gameObject.SetActive(false);
    }
    public override void OnPause()
    {
        base.OnPause();
        transform.gameObject.SetActive(false);
    }
    public override void OnResume()
    {
        
        base.OnResume();
        transform.gameObject.SetActive(true);
        listRoomRequset.SendRequest();
    }

    public void SetUserinfo()
    {
       // userName.text = gameFac.GetUserData().userName;
        //totalCount.text = "总场数: " + gameFac.GetUserData().totalCount;
       // winCount.text = "胜场数： " + gameFac.GetUserData().winCount;
    }

    public void UpdateUserinfoResponse(string total,string win)
    {
        gameFac.UpdateUserData(total, win);
        SetUserinfo();
    }
    //异步加载
    public void LoadRoomListSync(List<UserData> _userDatas)
    {
        userDatas = _userDatas;
    }

    //通过用户数据加载列表
    private void LoadRoomList(List<UserData> userDatas)
    {
        //先清空列表
        PerRoom[] perRooms = GetComponentsInChildren<PerRoom>();
        foreach (var per in perRooms)
        {
            per.OnDestroySelf();
        }

        int count = userDatas.Count;
        for (int i = 0; i < count; i++)
        {
            GameObject perRoom = Instantiate(perRoomPrefab);
            perRoom.transform.SetParent(verGroup.transform);
            PerRoom per = perRoom.GetComponent<PerRoom>();
            UserData data = userDatas[i];
          //  per.SetRoomInfo(data.RoomID, data.userName, data.totalCount, data.winCount,this);
        }
        int roomCount=verGroup.transform.GetComponentsInChildren<PerRoom>().Length;
        Vector2 size = verGroup.GetComponent<RectTransform>().sizeDelta;
        verGroup.GetComponent<RectTransform>().sizeDelta = new Vector2(size.x,
            roomCount * (perRoomPrefab.GetComponent<RectTransform>().sizeDelta.y + verGroup.spacing) + verGroup.padding.top + verGroup.padding.bottom);
    }

    private void CreateBoom()
    {
        BasePanel panel = uiMng.PushPanel(UIPanelType.Room);
        createRoomRequest.SetPanel(panel);
        createRoomRequest.SendRequest();

    }
    private void RefreList()
    {
        listRoomRequset.SendRequest();
    }


    //加入对应的房间
    public  void OnJoinRoomById(int id)
    {
        joinRoomRequest.SendRequest(id);
    }

    //响应服务器对加入房间的请求
    public void OnResponse(ReturnCode returnCode,UserData _usd1,UserData _usd2)
    {
        switch(returnCode)
        {
            case ReturnCode.NotFound:
                gameFac.ShowMessage("房间以摧毁不存在");
                break;
            case ReturnCode.Fail:
                gameFac.ShowMessage("房间人数已满");
                break;
            case ReturnCode.Success:
                usd1 = _usd1;
                usd2 = _usd2;
                break;
        }
    }
}
