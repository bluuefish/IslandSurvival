﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;

public class MessagePanel : BasePanel {
    [SerializeField] private Text messageText;
    private string message = null;
    //客户端的数据接收是异步进行，而ShowMessage函数的设置实在unity的主线程中进行 对此问题的解决方法

    protected override void Awake()
    {
        base.Awake();
    }
    protected  void Start()
    {
        canvasGroup.alpha = 0;
    }
    private void Update()
    {
        if(message!=null)
        {
            ShowMessage(message);
            message = null;
        }
    }
    public override void OnEnter()
    {
        //messageText = GetComponent<Text>();
        //messageText.enabled = false;
        transform.gameObject.SetActive(true);
        uiMng.InjectMessagePanel(this);
    }

    public void ShowMessage(string msg)  
    {
        transform.gameObject.SetActive(true);
        canvasGroup.DOFade(1, 1f);
        //messageText.enabled = true;
        //messageText.CrossFadeAlpha(1, 0, false);
        messageText.text = msg;
        Invoke("HideMessage", 2);
    }

    public void ContinueShowMessage(string msg)
    {
        transform.gameObject.SetActive(true);
        canvasGroup.DOFade(1, 1f);
        messageText.text = msg;
    }

    //异步显示，由于客户端的数据接收是异步进行，而ShowMessage函数的设置实在unity的主线程中进行，会报错 2018.7.26
    public void ShowMessageAsyn(string msg)
    {
        message = msg;
    }
    private  void HideMessage()
    {
        canvasGroup.DOFade(0, 2);     
    }
}
