﻿using UnityEngine;
using System.Collections;

public class BasePanel : MonoBehaviour {
    protected CanvasGroup canvasGroup;
    protected UIManager uiMng;
    protected GameFacade gameFac;
   protected virtual void Awake()
    {
        canvasGroup = GetComponent<CanvasGroup>();
    }
    public GameFacade GameFac
    {
        set
        {
            gameFac = value;
        }
    }

    public UIManager UiMng
    {
        set
        {
            uiMng=value;
        }
    }
    protected void PlayClickSound()
    {
        gameFac.PlayEffectSound(AudioManager.sound_ButtonClick);
    }
    /// <summary>
    /// 界面被显示出来
    /// </summary>
    public virtual void OnEnter()
    {
        gameObject.SetActive(true);
        canvasGroup.alpha = 1;
        canvasGroup.interactable = true;
    }

    /// <summary>
    /// 界面暂停
    /// </summary>
    public virtual void OnPause()
    {
        canvasGroup.alpha = 0;
        canvasGroup.interactable = false;
    }

    /// <summary>
    /// 界面继续
    /// </summary>
    public virtual void OnResume()
    {
        canvasGroup.alpha = 1;
        canvasGroup.interactable = true;
    }

    /// <summary>
    /// 界面不显示,退出这个界面，界面被关系
    /// </summary>
    public virtual void OnExit()
    {
        canvasGroup.alpha = 0;
        canvasGroup.interactable = false ;
        gameObject.SetActive(false);
    }

    //页面是否能够交互
    //public virtual void Interactable()
    //{
    //    if (CanvasGro == null) return;
    //    CanvasGro.alpha = 1;
    //    if (CanvasGro.interactable||CanvasGro.alpha == 1) return;
    //    CanvasGro.interactable = true;
    //}
    ////
    //public virtual void NotInteract()
    //{
    //    Debug.Log("1");
    //    if (CanvasGro == null) return;
    //    Debug.Log("2");
    //    CanvasGro.alpha = 0;
    //    CanvasGro.interactable = false;
    //}
}
