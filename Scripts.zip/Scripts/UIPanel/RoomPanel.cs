﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;
using Common;

public class RoomPanel : BasePanel {
    public Text HostPlayername;
    public Text HostCount;
    [Space(1f)]
    public Text EnemyPlayername;
    public Text EnemyCount;
    public GameObject waitSign;

    public RectTransform host;
    public RectTransform enemy;
    public Button startButton;
    public Button exitButton;

    private UserData ud=null;
    private UserData ud1 = null;
    private UserData ud2 = null;

    private ExitRoomRequest exitRoomRequest;
    private StartGameRequest startGameRequest;
    //异步退出房间
    private bool isExit=false;
    //异步开始线程的处理
    private bool isStartGame = false;
    private void Start()
    {
        exitRoomRequest = GetComponent<ExitRoomRequest>();
        startGameRequest = GetComponent<StartGameRequest>();
        startButton.onClick.AddListener(OnClickStartBack);
        exitButton.onClick.AddListener(OnExitBack);
    }

    private void Update()
    {
        if(ud!=null)
        {
            SetHostInfo(ud.userName, ud.totalCount, ud.winCount);
            InitEnemyInfo();
            ud = null;
        }
        if(ud1!=null)
        {
            SetHostInfo(ud1.userName, ud1.totalCount, ud1.winCount);
            if (ud2 != null)
            {
                SetEnemyInfo(ud2.userName, ud2.totalCount, ud2.winCount);  //更新加入房间时，房主的面板
            }
            else
            {
                InitEnemyInfo();
            }
            ud1 = null;
            ud2 = null;
        }
        if(isExit==true)
        {
            OnExitAim();
            isExit = false;
        }
        if(isStartGame)
        {
            gameFac.SetWantJumpScene("BattleScene");
            gameFac.LoadTransitionScene();
            isStartGame = false;
        }
    }
    //创建房间时 处理另一个线程的回应
    public void SetHostInfSync(UserData _ud)
    {
        ud = _ud;
    }
    //加入房间时，处理另一个线程的回应
    public void SetAllInfSync(UserData _ud1,UserData _ud2)
    {
        ud1 = _ud1;
        ud2 = _ud2;
    }
    //异步响应服务器的退出房间请求
    public void ExitResponseSync()
    {
        isExit = true;
    }
    //异步响应服务器的开始游戏请求
    public void StartGameResponse(ReturnCode returnCode)
    {
        if (returnCode == ReturnCode.Success)
        {
            //todo
            //uiMng.PushPanelAsyn(UIPanelType.Game);
           // gameFac.EnterPlayingSync();
            isStartGame = true;
        }
        //没有玩家加入时
        else if (returnCode==ReturnCode.NotFound)
        {
            gameFac.ShowMessageSync("请等待玩家加入");
        }
        else
        {
        //在此异步
            gameFac.ShowMessageSync("请等待房主开始游戏");
        }
    }

    //设置房主数据
    private void SetHostInfo(string _name,string _total,string _win)
    {
        HostPlayername.text = _name;
        HostCount.text = _win+"/"+ _total;

    }

    //设置对手数据
    private void SetEnemyInfo(string _name, string _total, string _win)
    {
        waitSign.SetActive(false);
        EnemyPlayername.text = _name;
        EnemyCount.text = _win + "/" + _total;
        EnemyPlayername.gameObject.SetActive(true);
        EnemyCount.gameObject.SetActive(true);
    }

    //等待对手的加入
    private void InitEnemyInfo()
    {
        waitSign.SetActive(true);
        EnemyPlayername.gameObject.SetActive(false);
        EnemyCount.gameObject.SetActive(false);
    }
    private void OnClickStartBack()
    {
        startGameRequest.SendRequest();
    }

    private void OnExitBack()
    {
        exitRoomRequest.SendRequest();
    }
   
    //载入动画
    private void OnEnterAim()
    {
        host.localPosition = new Vector3(-1000, 0, 0);
        host.DOLocalMoveX(-120, 0.5f);
        enemy.localPosition = new Vector3(1000, 0, 0);
        enemy.DOLocalMoveX(120, 0.5f);
        startButton.transform.localScale= Vector3.zero;
        exitButton.transform.localScale = Vector3.zero;
        startButton.transform.DOScale(1, 0.5f);
        exitButton.transform.DOScale(1, 0.5f);
    }

    //载出动画
    private void OnExitAim()
    {
        host.DOLocalMoveX(-1000, 0.5f);
        enemy.DOLocalMoveX(1000, 0.5f);
        startButton.transform.DOScale(0, 0.5f);
        exitButton.transform.DOScale(0, 0.5f).OnComplete(() => uiMng.PopPanel());
    }


    public override void OnEnter()
    {
        base.OnEnter();
        gameObject.SetActive(true);
        OnEnterAim();
    }
    public override void OnPause()
    {
        base.OnPause();
        gameObject.SetActive(false);
    }
    public override void OnResume()
    {
        base.OnResume();
        gameObject.SetActive(true);
    }
    public override void OnExit()
    {
        base.OnExit();
        gameObject.SetActive(false);
       
    }
}
