﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MainPanel : BasePanel {

    [SerializeField] private Button settingBtn;
    [SerializeField] private Button infoBtn;
    [SerializeField] private Button hallBtn;
    [SerializeField] private Button storeBtn;
    [SerializeField] private Button coinBtn;
    [SerializeField] private Text coinCount;
    [SerializeField] private Text userNameText;

    private int m_coinCount = 0;
    protected override void Awake()
    {
        base.Awake();
    }
    protected void Start()
    {
        if (settingBtn != null) settingBtn.onClick.AddListener(OnSettingCallBack);
        if (infoBtn != null) infoBtn.onClick.AddListener(OnInfoCallBack);
        if (hallBtn != null) hallBtn.onClick.AddListener(OnHallCallBack);
        if (storeBtn != null) storeBtn.onClick.AddListener(OnStoreCallBack);
        if (coinBtn != null) coinBtn.onClick.AddListener(OnCoinCallBack);
    }

    public override void OnEnter()
    {
        base.OnEnter();
        SetUserCoin();
        SetUserName();

    }
    public override void OnPause()
    {
        base.OnPause();
        canvasGroup.alpha = 1;
        canvasGroup.interactable = false;
        settingBtn.enabled = false;
        infoBtn.enabled = false;
        storeBtn.enabled = false;
        hallBtn.enabled = false;
    }
    public override void OnResume()
    {
        base.OnResume();
        canvasGroup.interactable =true;
        settingBtn.enabled=true;
        infoBtn.enabled = true;
        storeBtn.enabled = true;
        hallBtn.enabled = true;
        SetUserCoin();
        SetUserName();
    }

    private void OnSettingCallBack()
    {
       uiMng.PushPanel(UIPanelType.Setting);
       
    }

    private void OnInfoCallBack()
    {
        uiMng.PushPanel(UIPanelType.PlayerInfo);
    }

    private void OnHallCallBack()
    {
        uiMng.PushPanel(UIPanelType.Hall);
    }

    private void OnStoreCallBack()
    {
        uiMng.PushPanel(UIPanelType.Store);
    }

    private void OnCoinCallBack()
    {
        uiMng.ShowMessage("敬请期待");
    }

    /// <summary>
    /// 设置玩家的金币数量
    /// </summary>
    private void SetUserCoin()
    {
        m_coinCount = gameFac.GetUserInfo().Treasure;
        UpdateCoinCount();
    }

    /// <summary>
    /// 设置玩家的昵称
    /// </summary>
    private  void SetUserName()
    {
        userNameText.text = gameFac.GetAccountinfo().AccountName;
    }

    private void UpdateCoinCount()
    {
        coinCount.text = m_coinCount.ToString();
    }
}
