﻿using UnityEngine;
using System.Collections;
using System;


public enum UIPanelType  {
    None,
    Init,
    Login,
    Register,
    Message,
    Main,
    Setting,
    PlayerInfo,
    Hall,
    Store,
    RoomList,
    Room,
    Game
}
