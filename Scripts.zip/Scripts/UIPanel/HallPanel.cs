﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Common;

public class HallPanel : BasePanel {
    [SerializeField] private Button closeBtn;
    [SerializeField] private Button refreshBtn;
    [SerializeField] private Button createRoomBtn;
    [SerializeField] private Button joinRoomBtn;
    private VerticalLayoutGroup verticalLayout;
    private GameObject perRoomPrefab;

    private ListRoomRequset listRoomRequset;
    private CreateRoomRequest createRoomRequest;
    private JoinRoomRequest joinRoomRequest;
    //处理显示房间列表相应的线程冲突
    private List<UserData> userDatas = null;
    private UserData m_ud1 = null;
    private UserData m_ud2 = null;
    protected override void Awake()
    {
        base.Awake();
        listRoomRequset = GetComponent<ListRoomRequset>();
        createRoomRequest = GetComponent<CreateRoomRequest>();
        joinRoomRequest = GetComponent<JoinRoomRequest>();
    }
    private void Start()
    {
        if (closeBtn != null) closeBtn.onClick.AddListener(OnCloseCallBack);
        if (refreshBtn != null) refreshBtn.onClick.AddListener(OnRefreshCallBack);
        if (createRoomBtn != null) createRoomBtn.onClick.AddListener(OnCreateRoomCallBack);
        if (joinRoomBtn != null) joinRoomBtn.onClick.AddListener(OnJoinRoomCallBack);
        verticalLayout = GetComponentInChildren<VerticalLayoutGroup>();
        perRoomPrefab = Resources.Load("UIPanel/RoomItem") as GameObject;
    }
    private void Update()
    {
        if(userDatas!=null)
        {
            LoadRoomList(userDatas);
            userDatas = null;
        }
        //异步线程处理角色对抗面板
        if(m_ud1!=null&&m_ud2!=null)
        {
            BasePanel panel = uiMng.PushPanel(UIPanelType.Room);
            (panel as RoomPanel).SetAllInfSync(m_ud1, m_ud2);
            m_ud1 = null;
            m_ud2 = null;
        }

    }
    public override void OnEnter()
    {
        base.OnEnter();
        listRoomRequset.SendRequest();

    }
    public override void OnPause()
    {
        base.OnPause();
    }
    public override void OnResume()
    {
        base.OnResume();
    }
    public override void OnExit()
    {
        base.OnExit();
    }
    private void OnCloseCallBack()
    {
        uiMng.PopPanel();
    }

    private void OnRefreshCallBack()
    {

    }
    private void OnCreateRoomCallBack()
    {
        BasePanel panel = uiMng.PushPanel(UIPanelType.Room);
        createRoomRequest.SetPanel(panel);
        createRoomRequest.SendRequest();

    }
    private void OnJoinRoomCallBack()
    {

    }


    public void LoadRoomListSync(List<UserData> _userDatas)
    {
        userDatas = _userDatas;
    }

    /// <summary>
    ///通过用户数据加载列表
    /// </summary>
    /// <param name="userDatas"></param>
    public void LoadRoomList(List<UserData> userDatas)
    {
        //先清空列表
        PerRoom[] perRooms = GetComponentsInChildren<PerRoom>();
        foreach (var room in perRooms)
        {
            room.OnDestroySelf();
        }

        int count = userDatas.Count;
        for (int i = 0; i < count; i++)
        {
            GameObject perRoom_prefab = Instantiate(perRoomPrefab);
            perRoom_prefab.transform.SetParent(verticalLayout.transform);
            PerRoom per = perRoom_prefab.GetComponent<PerRoom>();
            perRoom_prefab.GetComponent<RectTransform>().localScale = Vector3.one;
            UserData data = userDatas[i];
            per.SetRoomInfo(data.RoomID, data.userName, data.totalCount, data.winCount, this);
        }

        //自适应房间列表的生成
        int roomCount;
        roomCount= verticalLayout.transform.GetComponentsInChildren<PerRoom>() == null? 0 :
            verticalLayout.transform.GetComponentsInChildren<PerRoom>().Length;
        Vector2 size = verticalLayout.GetComponent<RectTransform>().sizeDelta;
        verticalLayout.GetComponent<RectTransform>().sizeDelta = new Vector2(size.x,
            roomCount * (perRoomPrefab.GetComponent<RectTransform>().sizeDelta.y + verticalLayout.spacing)
            + verticalLayout.padding.top + verticalLayout.padding.bottom);
    }

    /// <summary>
    /// 点击加入房间后发送消息
    /// </summary>
    /// <param name="id"></param>
    public void OnJoinRoomById(int id)
    {
        joinRoomRequest.SendRequest(id);
    }

    public void OnResponseJoinRoom(ReturnCode returnCode,UserData ud1,UserData ud2)
    {
        switch(returnCode)
        {
            case ReturnCode.NotFound:
                gameFac.SendMessage("房间已摧毁不存在");
                break;
            case ReturnCode.Fail:
                gameFac.SendMessage("房间人数已满");
                break;
            case ReturnCode.Success:
                m_ud1 = ud1;
                m_ud2 = ud2;
                break;
        }
    }
}
