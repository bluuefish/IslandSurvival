﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PerRoom : MonoBehaviour {
    public Text username;
    public Text count;
    public Button joinButton;

    private HallPanel hallPanel;
    //对应房间的ID,处理加入按钮的点击
    private int id;
    public int Id
    {
        get { return id; }
        set {value = id;}
    }
	// Use this for initialization
	void Start () {
        joinButton.onClick.AddListener(OnJoinRoom);
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    public void SetRoomInfo( string _id,string _username,string _total,string _win,HallPanel panel)
    {
        id = int.Parse(_id);
        username.text = _username;
        count.text = _win + "/" + _total;
        hallPanel = panel;
    }
    public void OnJoinRoom()
    {
        Debug.Log("加入命令"+Id);
        hallPanel.OnJoinRoomById(Id);
    }

    public void OnDestroySelf()
    {
        Destroy(this.gameObject);
    }
}
