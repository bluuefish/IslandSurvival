﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SettingPanel : BasePanel {
    [SerializeField] private Button closeBtn;
    [SerializeField] private Button quitBtn;
    [SerializeField] private Text soundText;
    [SerializeField] private Slider soundSlider;
    [SerializeField] private GameObject soundOpenIron;
    [SerializeField] private GameObject soundCloseIron;

    protected override void Awake()
    {
        base.Awake();
    }
    protected void Start()
    {
        if (closeBtn != null) closeBtn.onClick.AddListener(OnCloseCallBack);
        if (quitBtn != null) quitBtn.onClick.AddListener(OnQuitCallback);
        soundSlider.onValueChanged.AddListener(OnSoundChangedCallBack);
        gameFac.SetSoundIntensity(0.5f);
        soundSlider.value = gameFac.GetSoundIntensity();
    }
   
    private void OnCloseCallBack()
    {
        uiMng.PopPanel();
    }

    private void OnQuitCallback()
    {
#if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
#elif UNITY_STANDALONE_WIN
        Application.Quit();
#endif
    }

    private void OnSoundChangedCallBack(float value)
    {
        soundText.text = ((int)(value * 100)).ToString();
        if (value>0.01f)
        {
            soundOpenIron.SetActive(true);
            soundCloseIron.SetActive(false);
        } 
        else
        {
            soundOpenIron.SetActive(false);
            soundCloseIron.SetActive(true);
        }
    }
}
