﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Goods : MonoBehaviour {

    public WeaponDescription weaponDescription;
}
