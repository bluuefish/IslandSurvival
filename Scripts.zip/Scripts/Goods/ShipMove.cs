﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShipMove : MonoBehaviour {
    public float speed;
    public  bool moveing=false;
    private  Transform target;
    public Transform pos1;
    public Transform pos2;
	// Use this for initialization
	void Start () {
        // Vector3 dir = target.position - transform.position;
        target = GameObject.Find("wharf").GetComponent<Transform>();
        pos1 = GameObject.Find("ScendPos/pos1").GetComponent<Transform>();
        pos2 = GameObject.Find("ScendPos/pos2").GetComponent<Transform>();

    }
	
	// Update is called once per frame
	void FixedUpdate () {
        if(moveing)
        {
            transform.LookAt(target);
            transform.Translate(Vector3.forward * speed * Time.deltaTime);
        }

        
	}

    private void OnTriggerEnter(Collider other)
    {
        moveing = false;
    }

}
