﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class PivotBasedCameraRig : AbstractTargetFollower {

    //相机的机构
    //cameraRig
    //Pivot
    //camera
    protected Transform m_camera;
    protected Transform m_pivot;

    protected Vector3 m_LastTargetPos;

    protected virtual void Awake()
    {
        m_camera = transform.GetComponentInChildren<Camera>().transform;
        m_pivot = m_camera.parent;
    }
}
