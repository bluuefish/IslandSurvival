﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FreeLookCam : PivotBasedCameraRig {
    [SerializeField]private float m_moveSpeed = 1f;  //节点多快跟上目标的位置
    [Range(0f,10f)][SerializeField] private float m_turnSpeed = 1.5f;  //鼠标移动时旋转的速度大小
    [SerializeField]private  float m_turnSmooth = 0.0f;  //平滑的鼠标的输入对相机的旋转
    [SerializeField] private float m_tiltMax = 75f;     //绕x轴的最大的角度
    [SerializeField] private float m_tiltMin = 45f;      //绕x轴的最小的角度
    [HideInInspector] public bool m_lockCursor;
    private  float verticalLookAngle= 0;
    private float m_lookAngle;    //rig的y轴的旋转
    private float m_tiltAngle;      //节点的x轴的旋转    //!避免鼠标斜向移动时视角出错
    private const float k_lookDistance = 100f;
    private Vector3 pivotEuler;
    private Quaternion pivotRot;
    private Quaternion m_tranTargetRot;

    /// <summary>
    /// 摄像机上下旋转的高度值为-1到1
    /// </summary>
    public float VerticalLookAngle
    {
        get
        {
            return verticalLookAngle;
        }
    }

    protected override void Awake()
    {
        base.Awake();

        Cursor.lockState = m_lockCursor ? CursorLockMode.Locked : CursorLockMode.None;
        Cursor.visible = !m_lockCursor;
        pivotEuler = m_pivot.eulerAngles;
        pivotRot = m_pivot.localRotation;
        m_tranTargetRot = transform.localRotation;
    }
    //protected override void Start()
    //{
    //    base.Start();
    //}
    private void Update()
    {
        HandleRotationMovement();
            Cursor.lockState = m_lockCursor ? CursorLockMode.Locked : CursorLockMode.None;
            Cursor.visible = !m_lockCursor;

    }
    
    private void HandleRotationMovement()
    {
        if (Time.timeScale < float.Epsilon) return;   //安全校验
        //读取输入
        float x = Input.GetAxis("Mouse X");
        float y = Input.GetAxis("Mouse Y");
        //调整摄像机左右看的范围
        m_lookAngle += x *m_turnSpeed;
        //只绕着rig的y轴旋转m_looAngle度
        m_tranTargetRot = Quaternion.Euler(0f, m_lookAngle, 0f);
        //调整摄像机上下倾斜的范围
        m_tiltAngle -= y * m_turnSpeed;
        verticalLookAngle = m_tiltAngle;
        m_tiltAngle = Mathf.Clamp(m_tiltAngle, -m_tiltMin, m_tiltMax);   //控制上下倾斜的范围
        //绕着pivot的x轴旋转m_tiltAngle度
        pivotRot = Quaternion.Euler(m_tiltAngle, pivotEuler.y,pivotEuler.z);
        //Debug.Log(m_tiltAngle);
        //旋转的平滑
        if(m_turnSmooth>0)
        {
            m_pivot.localRotation = Quaternion.Slerp(m_pivot.localRotation, pivotRot, m_turnSmooth * Time.deltaTime);
            transform.localRotation = Quaternion.Slerp(transform.localRotation, m_tranTargetRot, m_turnSmooth * Time.deltaTime);
        }
        else
        {
            m_pivot.localRotation = pivotRot;
            transform.localRotation = m_tranTargetRot;
        }
    }
    protected override void FollowTarget(float datetime)
    {
        if (m_target == null) return;
        transform.position = Vector3.Lerp(transform.position, m_target.position, datetime * m_moveSpeed);
    }

}
