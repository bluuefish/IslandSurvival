﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public  abstract class AbstractTargetFollower : MonoBehaviour {

    [SerializeField]protected Transform m_target;
    [SerializeField]private bool m_AutoFindTarget;
    protected Rigidbody Rig;
    public Transform Target
    {
        get  { return m_target; }
    }

     protected virtual void Start()
    {
       if(m_AutoFindTarget)
        {
            FindAndTarget();
        }
        if (m_target == null) return;
        Rig = GetComponent<Rigidbody>();
    }
    private void FixedUpdate()
    {
        if(m_target!=null&&m_target.gameObject.activeSelf!=false)
        FollowTarget(Time.deltaTime);
    }
    protected abstract void FollowTarget(float datetime);

    public void FindAndTarget()
    {
       
        //if(GameObject.FindGameObjectWithTag("Player").GetComponent<Transform>() != null)
        //{
        //    var tar = GameObject.FindGameObjectWithTag("Player").GetComponent<Transform>();
        //    SetTarget(tar);
        //}
       
    }
    public void SetTarget(Transform newTrans)
    {
        m_target = newTrans;
    }
}
