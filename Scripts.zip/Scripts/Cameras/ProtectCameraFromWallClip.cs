﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ProtectCameraFromWallClip : MonoBehaviour {
    public float moveClipTime = 0.05f;
    public float returnTime = 0.04f;
    public float sphereCastRadius = 0.1f;
    public bool visualiseInEditor;
    public float closestDistance = 0.5f;
    public bool Protecting { get; private set; }
    public string dontTag = "Player";

    private Transform m_Cam;
    private Transform m_pivot;
    private float m_OrginalDist;
    private float m_moveVelocity;
    private float m_currentDist;
    private Ray m_ray = new Ray();
    private RaycastHit[] m_Hits;
    private RayHitComparer m_RayHitComparer;

    private void Start()
    {
        m_Cam = GetComponentInChildren<Camera>().transform;
        m_pivot = m_Cam.parent;
        m_OrginalDist = m_Cam.localPosition.magnitude;
        m_currentDist = m_OrginalDist;

        m_RayHitComparer = new RayHitComparer();
    }

    private void LateUpdate()
    {
        float targetDist = m_OrginalDist;
        m_ray.origin = m_pivot.position + m_pivot.forward * sphereCastRadius;
        m_ray.direction = -m_pivot.forward;
        var cols = Physics.OverlapSphere(m_ray.origin, sphereCastRadius);
        bool initialIntersect = false;
        bool hitSomething = false;
        for(int i=0;i<cols.Length; i++)
        {
            if(!cols[i].isTrigger&&cols[i].attachedRigidbody!=null&&cols[i].attachedRigidbody.CompareTag(dontTag))
            {
                initialIntersect = true;
                break;
            }
        }
        //一开始就碰到某些东西
        if(initialIntersect)
        {
            m_ray.origin += m_pivot.forward * sphereCastRadius;
            m_Hits = Physics.RaycastAll(m_ray, m_OrginalDist - sphereCastRadius);
        }
        else
        {
            m_Hits = Physics.SphereCastAll (m_ray, sphereCastRadius, m_OrginalDist + sphereCastRadius);
        }
        //对碰撞到的信息进行排序
        Array.Sort(m_Hits, m_RayHitComparer);
        float nearst = Mathf.Infinity;
        for (int i = 0; i < m_Hits.Length; i++)
        {
            if(m_Hits[i].distance<nearst&&
               ( !m_Hits[i].collider.isTrigger) && !(m_Hits[i].collider.attachedRigidbody != null &&
                      m_Hits[i].collider.attachedRigidbody.CompareTag(dontTag)))
            {
                nearst = m_Hits[i].distance;
                targetDist = -m_pivot.InverseTransformPoint(m_Hits[i].point).z;
                hitSomething = true;
            }
        }
        //在编辑器下看到视线被遮挡
        if (hitSomething)
        {
            Debug.DrawRay(m_ray.origin, -m_pivot.forward * (targetDist + sphereCastRadius), Color.red);
        }
        //碰到相机后将它移动到更好的位置
        Protecting = hitSomething;
        m_currentDist = Mathf.SmoothDamp(m_currentDist, targetDist, ref m_moveVelocity, m_currentDist > targetDist ? moveClipTime:returnTime);
        m_currentDist = Mathf.Clamp(m_currentDist, closestDistance, m_OrginalDist);
        m_Cam.localPosition = -Vector3.forward * m_currentDist;
    }
}

public class RayHitComparer : IComparer
{
    public int Compare(object x, object y)
    {
        return ((RaycastHit)x).distance.CompareTo(((RaycastHit)y).distance);
    }
}