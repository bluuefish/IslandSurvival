﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Common;

public class RoleData {
    //要加载的的玩家对应模型
    public RoleType RoleType { get; private set; }
    public GameObject RolePrefab { get; private set; }
    //public  GameObject ArrowPrefab { get; private set; }
    //public GameObject ArrowEXPrefab { get; private set; }
    public Transform SpawnPos { get; private set; }
    //构造函数
    public RoleData(RoleType roleType,string rolePath,/*string arrowPath, string exPath,*/Transform pos)
    {
        RoleType = roleType;
        RolePrefab = Resources.Load<GameObject>(rolePath);
        //ArrowPrefab = Resources.Load<GameObject>(arrowPath);
        //ArrowEXPrefab = Resources.Load<GameObject>(exPath);
        //ArrowPrefab.GetComponent<Arrow>().ExPre = ArrowEXPrefab;
        this.SpawnPos = pos;
    }


}
