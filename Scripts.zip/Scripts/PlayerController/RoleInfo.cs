﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Common;

public class RoleInfo:MonoBehaviour {
    public RoleType roleType;
    public bool isLocalRole;
}
