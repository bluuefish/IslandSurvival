﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerAttack : MonoBehaviour {
    private Animator ani;
    public GameObject arrowPre;
    private Transform leftTran;
    private Vector3 dir;
    public PlayerManage PlayerMa { private get; set; }
	// Use this for initialization
	void Start () {
        ani = GetComponent<Animator>();
        leftTran = transform.Find("Bip001/Bip001 Pelvis/Bip001 Spine/Bip001 Neck/Bip001 L Clavicle/Bip001 L UpperArm/Bip001 L Forearm/Bip001 L Hand").GetComponent<Transform>();
	}
	
	// Update is called once per frame
	void Update () {
        if(ani.GetCurrentAnimatorStateInfo(0).IsName("Grounded"))
        {
            if(Input.GetButtonDown("Fire1"))
            {
                Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
                RaycastHit hit;
                Physics.Raycast(ray, out hit);
                Vector3 point = hit.point;
                point.y = transform.position.y;
                dir = point - transform.position;
                transform.rotation = Quaternion.LookRotation(dir);
                    ani.SetTrigger("Crouch");
                    Invoke("Shoot", 1f);
                
            }
        }
		
	}
    private void Shoot()
    {
        PlayerMa.Shoot(arrowPre,leftTran.position,Quaternion.LookRotation(dir));
    }
}
