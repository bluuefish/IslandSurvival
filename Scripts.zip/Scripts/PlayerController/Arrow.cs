﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Common;

public class Arrow : MonoBehaviour {
    public RoleType rt;
    public float speed;
    public GameObject ExPre;
    private Rigidbody rig;
    //判断这只箭是否是本地客户端产生的
    public bool isLocal = false;
    public PlayerManage PlayerMan { get; set; }
	void Start () {
        rig = GetComponent<Rigidbody>();
	}
	
	// Update is called once per frame
	void Update () {
        rig.MovePosition(transform.position + transform.forward * Time.deltaTime * speed);
	}
    private void OnCollisionEnter(Collision collision)
    {
       Vector3 pos=collision.contacts[0].point;
       GameObject exp=Instantiate(ExPre, pos, Quaternion.identity);
        exp.transform.SetParent(transform);
        if(collision.collider.tag=="Player")
        {
            bool isLocalRole = collision.transform.GetComponent<RoleInfo>().isLocalRole;
            if(isLocal!=isLocalRole)
            {
                PlayerMan.AttackEnemy(Random.Range(10, 20));
                GameFacade.Instance.PlayEffectSound(AudioManager.sound_ShootPerson);
            }
           
        }
        else
        {
            GameFacade.Instance.PlayEffectSound(AudioManager.sound_Miss);
        }
        Destroy(this.gameObject, 1f);
    }
}
