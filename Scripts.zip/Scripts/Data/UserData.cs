﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

  public  class UserData
    {
    public string userName { get;  set; }
    public string totalCount { get; set; }
    public string winCount { get; set; }
    public string RoomID { get; set; }
    public UserData(string _RoomID, string _name,string _total,string _win)
    {
        userName = _name;
        totalCount = _total;
        winCount = _win;
        RoomID = _RoomID;
    }

    //根据一串字符串解析对应数据
    public UserData(string data)
    {
        string[] datastr = data.Split(',');
       this.RoomID = datastr[0];
        this.userName = datastr[1];
        this.totalCount = datastr[2];
        this.winCount = datastr[3];
    }
    }
//[Serializable]
//public class AccoutInfo
//{
//    public string AccoutName { get { return _accoutName; } }
//    public string AccoutPassword { get { return _accoutPassword; } }

//    private string _accoutName;
//    private string _accoutPassword;

//    public AccoutInfo(string name,string password)
//    {
//        _accoutName = name;
//        _accoutPassword = password;
//    }

//}


