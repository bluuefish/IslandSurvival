﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(Rigidbody))]
[RequireComponent(typeof(Animator))]
[RequireComponent(typeof(CapsuleCollider))]
public class ThirdPersonCharacter : MonoBehaviour {
    [SerializeField] private float m_moveingTurnSpeed = 360f;
    [SerializeField] private float m_stationaryTurnSpeed = 180f;
    [SerializeField] private float m_jumpPower = 12f;
    [Range(1f, 4f)] private float m_gravityMultiplier = 2f;
    [SerializeField] private float m_runCycleLegOffset = 0.2f;
    [SerializeField] private float m_moveSpeedMultiplier = 1f;
    [SerializeField] private float m_animSpeedMultiplier = 1f;
    [SerializeField] private float m_groundCheckDistance = 0.1f;

    Rigidbody m_rigidbody;
    Animator m_animator;
    CapsuleCollider m_Collider;
    float capsuleColliderHeight;
    Vector3 capsuleCenter;
    bool isGrounded;
    float origGroundCheckDist;
    const float k_half = 0.5f;
    float turnAmount;
    float forwardAmount;
    Vector3 groundNormal;
    bool isCrouching;

    Vector3 movedir;
    private void Start()
    {
        m_animator = GetComponent<Animator>();
        m_rigidbody = GetComponent<Rigidbody>();
        m_Collider = GetComponent<CapsuleCollider>();
        capsuleCenter = m_Collider.center;
        capsuleColliderHeight = m_Collider.height;
        m_rigidbody.constraints = RigidbodyConstraints.FreezeRotationX | RigidbodyConstraints.FreezeRotationY | RigidbodyConstraints.FreezeRotationZ;
        origGroundCheckDist = m_groundCheckDistance;
    }
    private void OnAnimatorMove()
    {
        if(isGrounded&&Time.deltaTime>0)
        {
            //Vector3 v = (m_animator.deltaPosition * m_moveSpeedMultiplier) / Time.deltaTime;
            Vector3 v = movedir * m_moveSpeedMultiplier*Time.deltaTime;
            v.y = m_rigidbody.velocity.y;
            m_rigidbody.velocity = v;
        }
    }
    public void Move(Vector3 move,bool crouch,bool jump)
    {
        movedir = move;
        if (move.magnitude > 1f) move.Normalize();
        move = transform.InverseTransformDirection(move);
        move = Vector3.ProjectOnPlane(move, groundNormal);
        CheckGroundStatus();
        turnAmount = Mathf.Atan2(move.x, move.z);
        forwardAmount = move.z;
        ApplyExtraTurnRotation();
        if(isGrounded)
        {
            HandleGroundMovement(crouch,jump);
        }
        else
        {
            HandleAirBorneMovement();
        }
        ScaleCapsuleForCrouch(crouch);  //缩放角色的碰撞器
        PreventStandingInLowroom();
        UpdateAnimator(move);
    }

    private void CheckGroundStatus()
    {
        RaycastHit hitinfo;
#if UNITY_EDITOR
        Debug.DrawLine(transform.position + (Vector3.up * 0.1f), transform.position + (Vector3.up * 0.1f) + (Vector3.down * m_groundCheckDistance));
#endif
        if(Physics.Raycast(transform.position+(Vector3.up*0.1f),Vector3.down,out hitinfo,m_groundCheckDistance))
        {
            groundNormal = hitinfo.normal;   //射线检测到表面的法线
            isGrounded = true;
            m_animator.applyRootMotion = true;
        }
        else
        {
            groundNormal = Vector3.up;
            isGrounded = false;
            m_animator.applyRootMotion = false;
        }
    }
    private void ApplyExtraTurnRotation()
    {
        //向前运动的越快，转弯就越接近180度；
        float turnSpeed = Mathf.Lerp(m_stationaryTurnSpeed, m_moveingTurnSpeed, forwardAmount);
        transform.Rotate(Vector3.up * turnSpeed*turnAmount*Time.deltaTime);

    }
    private void HandleGroundMovement(bool crouch,bool jump)
    {
        //检查当前状态是允许跳跃
        if(jump&&m_animator.GetCurrentAnimatorStateInfo(0).IsName("Grounded"))
        {
            //跳
            m_rigidbody.velocity = new Vector3(m_rigidbody.velocity.x, m_jumpPower, m_rigidbody.velocity.z);
            isGrounded = false;
            m_animator.applyRootMotion = false;
            m_groundCheckDistance = 0.1f;
        }
    }
    private void HandleAirBorneMovement()
    {
        Vector3 extraGravityForce = (Physics.gravity * m_gravityMultiplier) - Physics.gravity;
        m_rigidbody.AddForce(extraGravityForce);
        m_groundCheckDistance = m_rigidbody.velocity.y < 0 ? origGroundCheckDist : 0.01f;
    }
    private void ScaleCapsuleForCrouch(bool crouch)
    {
        if (isGrounded && crouch)
        {
            if (isCrouching) return;
            m_Collider.center = m_Collider.center / 2f;
            m_Collider.height = m_Collider.height/ 2f;
            isCrouching = true;
        }
        else
        {
            Ray ray = new Ray(m_rigidbody.position + Vector3.up * m_Collider.radius * k_half, Vector3.up);
            float crouchRayLenth = capsuleColliderHeight - m_Collider.radius * k_half;
            if (Physics.SphereCast(ray, m_Collider.radius * k_half, crouchRayLenth, Physics.AllLayers, QueryTriggerInteraction.Ignore))
             {
                isCrouching = true;
                return;
            }
            m_Collider.center = capsuleCenter;
            m_Collider.height = capsuleColliderHeight;
            isCrouching = false;
        }
    }
    private void PreventStandingInLowroom()
    {
        if (!isCrouching)
        {
            Ray ray = new Ray(m_rigidbody.position + Vector3.up * m_Collider.radius * k_half, Vector3.up);
            float crouchRayLenth = capsuleColliderHeight - m_Collider.radius * k_half;
            if (Physics.SphereCast(ray, m_Collider.radius * k_half, crouchRayLenth, Physics.AllLayers, QueryTriggerInteraction.Ignore))
            {
                isCrouching = true;
            }
        }
    }
    private void UpdateAnimator(Vector3 move)
    {
        m_animator.SetFloat("Forward", move.z,0.1f,Time.deltaTime);
        m_animator.SetFloat("Turn", turnAmount, 01f, Time.deltaTime);
        m_animator.SetBool("Crouch", isCrouching);
        m_animator.SetBool("OnGround", isGrounded);
        if(!isGrounded)
        {
            m_animator.SetFloat("Jump", m_rigidbody.velocity.y);
        }
        float runCycle = Mathf.Repeat(m_animator.GetCurrentAnimatorStateInfo(0).normalizedTime + m_runCycleLegOffset, 1);
        float jumpLeg = (runCycle < k_half ? 1 : -1) * forwardAmount;
        if(isGrounded)
        {
            m_animator.SetFloat("JumpLeg", jumpLeg);
        }
        if(isGrounded&&move.magnitude>0)
        {
            m_animator.speed = m_animSpeedMultiplier;
        }
        else
        {
            m_animator.speed = 1;
        }
      
    }
    public void FollowCamForward(Vector3 forward)
    {
       transform.rotation=Quaternion.LookRotation(forward);
    }
}
