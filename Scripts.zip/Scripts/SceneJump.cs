﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
public class SceneJump : MonoBehaviour {
    public  static string _wantJumpScene;
    private const string transtionScene= "TransitionScene";
    private Text proText;
    private Slider proSlider;
    private float tempProgress = 0;
    private AsyncOperation async;

    ///// 单例模式的核心
    ///// 1，定义一个静态的对象 在外界访问 在内部构造
    ///// 2，构造方法私有化

    private static SceneJump _instance;

    public static SceneJump Instance
    {
        get
        {
            if (_instance == null)
            {
                _instance = new SceneJump();
            }
            return _instance;
        }
    }

    void Start () {
        _instance = this;
        if (SceneManager.GetActiveScene().name==transtionScene)
        {
           Debug.Log(_wantJumpScene);
            proText = GameObject.Find("Canvas/loadText").GetComponent<Text>();
            proSlider = GameObject.Find("Canvas/loadSlider").GetComponent<Slider>();
            async=SceneManager.LoadSceneAsync(_wantJumpScene);
            async.allowSceneActivation = false;
            
        }
	}
	
	void Update () {
		if(proText!=null&&proSlider!=null)
        {
            tempProgress = Mathf.Lerp(tempProgress, async.progress, Time.deltaTime);
            proText.text =(int)( tempProgress / 9 * 10 * 100 )+ "%";
            proSlider.value = tempProgress / 9 * 10;
            if(tempProgress>=0.85)
            {
                tempProgress = 0.9f;
                proText.text = 100 + "%";
                proSlider.value = 1;
                async.allowSceneActivation = true;
            }
        }
	}
    public void  SetNextScene(string name)
    {
        _wantJumpScene = name;
    }

    public  void LoadTransitionScene()
    {
        SceneManager.LoadScene(transtionScene);
    }
}
