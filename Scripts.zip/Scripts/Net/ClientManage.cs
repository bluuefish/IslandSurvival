﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Net.Sockets;
using System.Net;
using Common;
using System;

public class ClientManage : BaseManage {

    /// <summary>
    /// 网络的连接状态
    /// </summary>
    public bool NetCondition
    {
        get { return _netCondition; }
    }
    //10.128.232.112
    //39.176.195.188
    //192.168.43.108
    private const string IP= "192.168.43.108";
    private const int PORT= 6688;
    private Socket clientSocket;
    private Message msg = new Message();
    private bool _netCondition=false;

    public ClientManage(GameFacade gf) : base(gf) { }

    public override void OnInit()
    {
        base.OnInit();
        //连接服务器端
        clientSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
        try
        {
            clientSocket.Connect(IP, PORT); //开始连接服务器端
            Start(); //开始进行监听
            _netCondition = true;
        }
        catch (System.Exception e)
        {

            Debug.LogWarning("无法连接服务器，请检查你的网络连接"+e);
            _netCondition = false;
            //gameFacade.ContinueShowMessage("请检查你的网络是否连接");

         //   Application.Quit();
        }
    }

    #region 向服务器端发送消息
    public void SendMessage(RequestCode request,ActionCode action,string data)
    {
        byte[] databytes = Message.PackData(request, action, data);
        clientSocket.Send(databytes);
    }
    #endregion


    #region 接收并处理从服务器传来的消息
    private void Start()
    {
       
        clientSocket.BeginReceive(msg.Data, msg.StartIndex, msg.RemainSize, SocketFlags.None, ReceiveCallback, null);
    }
    private void ReceiveCallback(IAsyncResult ar)
    {
        try
        {
            if (clientSocket == null || clientSocket.Connected == false) return;   //如果socket被关了就不调用
            int cout = clientSocket.EndReceive(ar);
            msg.ReadMessage(cout, OnProcessCallback);
            Start();
        }
        catch (Exception e)
        {

            Debug.Log(e);
        }
    }
    private void OnProcessCallback(RequestCode request,string data)
    {
        GameFacade.Instance.HandleRequest(request, data);
    }
    #endregion












    public override void OnDestroy()
    {
        base.OnDestroy();
        try
        {
            clientSocket.Close();
        }
        catch (System.Exception e)
        {

            Debug.LogWarning("无法关闭与服务器的连接" + e);
        }
    }


}
