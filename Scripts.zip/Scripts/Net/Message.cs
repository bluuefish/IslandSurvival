﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using Common;
using System.Text;
using System.Linq;

public class Message {

    private byte[] data = new byte[1024];
    private int startIndex = 0;

    public byte[] Data
    {
        get { return data; }
    }
    public int StartIndex
    {
        get
        {
            return startIndex;
        }
    }
    public int RemainSize
    {
        get
        {
            return data.Length - startIndex;
        }
    }
    //事件委托知识点，解析消息
    public void ReadMessage(int newAmount, Action<RequestCode, string> OnProcessCallback)
    {
        startIndex += newAmount;
        while (true)
        {
            if (startIndex < 4) return;
            int count = BitConverter.ToInt32(data, 0); //解析消息长度
            RequestCode requestCode = (RequestCode)BitConverter.ToInt32(data, 4); //解析请求类型
            if (startIndex - 4 >= count)
            {
                string s = Encoding.UTF8.GetString(data, 8, count-4);
                //Debug.Log("收到的返回码----" + requestCode);
                //Debug.Log("收到的数据----" + s);
                OnProcessCallback(requestCode,  s);
                Array.Copy(data, count +4, data, 0, startIndex - 4- count);
                startIndex -= (4 + count);
            }
            else
            {
                break;
            }
        }
    }

    //打包服务器向客户端返回的消息
    public static byte[] PackData(RequestCode requestCode, string _data)
    {
        byte[] bytRequest = BitConverter.GetBytes((int)requestCode);
        byte[] data = Encoding.UTF8.GetBytes(_data);
        int dataLength = bytRequest.Length + data.Length;
        byte[] byteLength = BitConverter.GetBytes(dataLength);
        return byteLength.Concat(bytRequest).ToArray<byte>().Concat(data).ToArray<byte>();
    }

    //打包客户端向服务器发送的消息
    public static byte[] PackData(RequestCode requestCode, ActionCode actionCode, string _data)
    {
        byte[] bytRequest = BitConverter.GetBytes((int)requestCode);
        byte[] bytAction = BitConverter.GetBytes((int)actionCode);
        byte[] data = Encoding.UTF8.GetBytes(_data);
        int dataLength = bytRequest.Length +bytAction.Length+data.Length;
        byte[] byteLength = BitConverter.GetBytes(dataLength);
        return byteLength.Concat(bytRequest).ToArray<byte>().Concat(bytAction).ToArray<byte>().Concat(data).ToArray<byte>();
    }
}
		
	

