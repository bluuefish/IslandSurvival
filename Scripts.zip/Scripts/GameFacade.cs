﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Common;

public class GameFacade : MonoBehaviour {
    //充当一个中介者的角色
    private static GameFacade _instance;
    public static GameFacade Instance
    {
        get
        {
            return _instance;
        }
    }
    private UIManager uiMag;
    private AudioManager audMag;
    //private CameraManage camMag;
    private PlayerManage PlaMag;
    private RequestManage reqMag;
    private ClientManage cliMag;
    private SceneManage sceMag;

    /// <summary>
    /// 网络的连接状态
    /// </summary>
    private bool netConnet
    {
        get
        {
            if(cliMag!=null)
            {
                return cliMag.NetCondition;
            }
            return false;
        }
    }
    private bool isPlaying = false;
    //对服务器异步显示处理
    private string tip=null;
    private void Awake()
    {
        if(_instance!=null)
        {
            Destroy(this.gameObject);return;
        }
        _instance = this;
        DontDestroyOnLoad(this.gameObject);
    }


    void Start () {
        OnInit();
	}
	
	void Update () {
        uiMag.Update();
        audMag.Update();
        //camMag.Update();
        PlaMag.Update();
        reqMag.Update();
        cliMag.Update();

        //对服务器异步显示处理
        if(tip!=null)
        {
            ShowMessage(tip);
            tip = null;
        }

        //实例化角色异步处理
        if(isPlaying)
        {
            EnterPlaying();
            isPlaying = false;
        }
    }

    private void LateUpdate()
    {
        if(netConnet)
        {
            uiMag.CurPanelNotInteract = false;
        }else
        {
            uiMag.ContinueShowMessage("无法连接服务器，请检查你的网络连接");
            uiMag.CurPanelNotInteract = true;
        }
    }




    public   void OnInit()
    {
        uiMag = new UIManager(this);
        audMag = new AudioManager(this);
        //camMag = new CameraManage(this);
        PlaMag = new PlayerManage(this);
        reqMag = new RequestManage(this);
        cliMag = new ClientManage(this);
        sceMag = new SceneManage(this);

        uiMag.OnInit();
        audMag.OnInit();
        //camMag.OnInit();
        reqMag.OnInit();
        cliMag.OnInit();
        sceMag.OnInit();
    }


    #region Request的代理部分
    public void AddRequest(RequestCode code, BaseRequest req)
    {
        reqMag.AddRequest(code, req);
    }
    public void RemoveRequest(RequestCode code)
    {
        reqMag.RemoveRequest(code);
    }
    public void HandleRequest(RequestCode request, string data)
    {
        reqMag.HandleRequest(request, data);
    }
    #endregion

    #region Client的代理部分
    public void SendMessage(RequestCode _request, ActionCode _action, string _data)
    {
        cliMag.SendMessage(_request, _action, _data);
    }

    public void NetException()
    {
        
    }
    #endregion

    #region UI的代理部分
    public void ShowMessage(string msg)
    {
        uiMag.ShowMessage(msg);
    }

    public void ContinueShowMessage(string msg)
    {
        uiMag.ContinueShowMessage(msg);
    }

    /// <summary>
    /// 生成一个ui面板
    /// </summary>
    /// <param name="panelType"></param>
    /// <returns></returns>
    public BasePanel PushPanel(UIPanelType panelType)
    {
          return uiMag.PushPanel(panelType);
    }
    //对服务器异步显示处理
    public void ShowMessageSync(string msg)
    {
        tip = msg;
    }

    /// <summary>
    /// 移除所有的ui面板
    /// </summary>
    public void RemoveAllFromPanelDict()
    {
        uiMag.RemoveAllFromPanelDict();
    }

    public BasePanel GetExistPanel(UIPanelType panelType)
    {
       return  uiMag.GetPanelFromDict(panelType);
    }
    #endregion
    #region audio的代理部分
    public void PlayBgSound(string clipname)
    {
        audMag.PlayBgSound(clipname);
    }

    public void PlayEffectSound(string clipname)
    {
        audMag.PlayEffectSound(clipname);
    }

    public void SetSoundIntensity(float value)
    {
        audMag.SetSoundIntensity(value);
    }

    public float GetSoundIntensity()
    {
        return audMag.GetSoundIntensity();
    }
    #endregion
    #region Play的代理部分
    /// <summary>
    /// 初始化playManage
    /// </summary>
    public void SetPlayInit()
    {
        PlaMag.OnInit();
    }

    public void SetPlayData(UserData data)
    {
        PlaMag.UserData = data; 
    }

    public void SetPlayerInfo(AccountInfo account,UserInfo user) //改 09-17
    {
        PlaMag.SetPlayerInfo(account, user);
    }
    public void SetCurrentRoleType(RoleType rt) 
    {
        PlaMag.CurrentRoleType = rt;
    }
    public Transform GetCurrentRoleTran()
    {
        return PlaMag.CurrentRoleGameObject.transform;
    }
    //初始化进入游戏
    private void EnterPlaying()
    {
       
        PlaMag.SpawnRoles();
        PlaMag.AddControSpript();
        PlaMag.AddSyncRoleAction();

        //camMag.FollowTarget();
    }
    //异步进入游戏
    public void EnterPlayingSync()
    {
        isPlaying = true;
    }

    //设置服务器传输的自身的输入指令
    public void SetlocalInputCommend(InputCommend commend)
    {
        PlaMag.CurrentRolemotor.SetSyncInputCommed(commend);
    }
    ////设置服务器传输的对方的输入指令
    //public void SetRomateInputCommend(InputCommend commend)
    //{
    //    PlaMag.RomateRoleMotor.SetSyncInputCommed(commend);
    //}

    //开始对人物进行
    public void StartPlaying()
    {
        //PlaMag.AddControSpript();
       // PlaMag.AddSyncMove();
    }
    //得到角色的最大生命值
    public float GetRoleMaxHealth()
    {
        return PlaMag.CurrentRoleMaxHealth;
    }
    //得到角色的生命值
    public float GetRoleHealth()
    {
        return PlaMag.CurrentRoleHealth;
    }
    //得到角色的子弹最大容量
    public float GetRoleGunClipSize()
    {
        return PlaMag.CurrentGunClipSize;
    }
    //得到角色的子弹数
    public float GetRoleGunClip()
    {
        return PlaMag.CurrentGunClip;
    }
    //得到角色的枪的图标
    public Sprite GetRoleGunIron()
    {
        return PlaMag.CurrentRoleGunIron;
    }
    //得到角色是否在用枪
    public bool IsUseWeapon()
    {
        return PlaMag.isUseWeapen;
    }
    public UserData GetUserData()  //改 09-17
    {
        return PlaMag.UserData;
    }
    /// <summary>
    /// 得到账号信息 09-17
    /// </summary>
    /// <returns></returns>
    public AccountInfo GetAccountinfo()
    {
        return PlaMag.AccountInfo;
    }
    /// <summary>
    /// 得到用户的游戏数据 09-17
    /// </summary>
    /// <returns></returns>
    public UserInfo GetUserInfo()
    {
        return PlaMag.UserInfo;
    }
    //更新玩家信息
    public void UpdateUserData(string total,string win)
    {
        PlaMag.UpdateUserData(total, win);
    }
    public void GameOver()
    {
        PlaMag.GameOver();
        //camMag.WalkThroughScene();
    }

    //得到主游戏场景的摄像头
    public FreeLookCam GetLookCam()
    {
        return PlaMag.lookCam;
    }

    //得到角色是否受伤标志
    public bool GetCanDamageSign()
    {
        return PlaMag.isCanDamage;
    }

    //设置角色是否受伤标志
    public void SetCanDamageSign(bool value)
    {
        PlaMag.CurrentRolemotor.IsCanDamage(value);
        PlaMag.RomateRoleMotor.IsCanDamage(value);
    }
    //设置游戏结束
    public void WhileGameEnd()
    {
        PlaMag.WhileGameEnd();
    }
    #endregion

    #region Scene的代理部分
    /// <summary>
    /// 设置要跳转的场景名
    /// </summary>
    /// <param name="name"></param>
    public void SetWantJumpScene(string name)
    {
        sceMag.SetWantJumpScene(name);
    }

    public void LoadTransitionScene()
    {
        sceMag.LoadTransitionScene();
    }
    #endregion
    public void Destroy()
    {
        uiMag.OnDestroy();
        audMag.OnDestroy();
        //camMag.OnDestroy();
        PlaMag.OnDestroy();
        reqMag.OnDestroy();
        cliMag.OnDestroy();
        sceMag.OnDestroy();
    }

    private void OnDestroy()
    {
        Destroy();
    }
}
