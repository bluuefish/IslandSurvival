﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneManage : BaseManage {

    private const string LoginScene = "LoginScene";
    private const string TransitionScene = "TransitionScene";
    private const string MainScene = "MainScene";
    private const string BattleScene = "BattleScene";

    public SceneManage(GameFacade gf) : base(gf)
    {
    }

    public override void OnInit()
    {
        base.OnInit();
        SceneManager.LoadScene(LoginScene, LoadSceneMode.Single);
        SceneManager.sceneLoaded += SceneLoaded;
        Debug.Log("加载完成了" );
    }

    /// <summary>
    /// 场景加载完的回调
    /// </summary>
    /// <param name="scene"></param>
    /// <param name="mode"></param>
    private void SceneLoaded(Scene scene, LoadSceneMode mode)
    {
        //Debug.Log("加载完成了" + scene.name);
        switch (scene.name)
        {
            case LoginScene:
                {
                    gameFacade.PushPanel(UIPanelType.Message);
                    gameFacade.PushPanel(UIPanelType.Init);
                    break;
                }
            case TransitionScene:
                {

                    break;
                }
            case MainScene:
                {

                    gameFacade.RemoveAllFromPanelDict();
                    gameFacade.PushPanel(UIPanelType.Message);
                    gameFacade.PushPanel(UIPanelType.Main);
                    break;
                }
            case BattleScene:
                {
                    gameFacade.SetPlayInit();
                    gameFacade.RemoveAllFromPanelDict();
                    gameFacade.PushPanel(UIPanelType.Message);
                    BasePanel Panel=gameFacade.PushPanel(UIPanelType.Game);
                    //(Panel as GamePanel).StartPlayerRequest();
                    break;
                }

        }
    }

    /// <summary>
    /// 设置要跳转的场景名
    /// </summary>
    /// <param name="name"></param>
    public void SetWantJumpScene(string name)
    {
        SceneJump._wantJumpScene = name;
    }

    /// <summary>
    /// 场景过渡
    /// </summary>
    public void LoadTransitionScene()
    {
        SceneJump.Instance.LoadTransitionScene();
    }
}
