﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Common;

public class RequestManage : BaseManage
{

    public RequestManage(GameFacade gf) : base(gf) { }

    //储存所有的请求
    Dictionary<RequestCode, BaseRequest> RequestDic = new Dictionary<RequestCode, BaseRequest>();

    public void AddRequest(RequestCode code,BaseRequest req)
    {
        RequestDic.Add(code, req);
    }

    public void RemoveRequest(RequestCode code)
    {
        RequestDic.Remove(code);
    }

    //处理请求
    public void HandleRequest(RequestCode request,string data)
    {
        BaseRequest req=RequestDic.TryGet<RequestCode, BaseRequest>(request);
        if(req==null)
        {
            Debug.Log("对应的请求"+request+ "处理不存在");
            return;
        }
        req.OnResponse(data);
    }
}
