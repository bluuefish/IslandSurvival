﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BaseManage {


    protected GameFacade gameFacade;

    public BaseManage(GameFacade gf)
    {
        this.gameFacade = gf;
    }

    public virtual void Update()
    {
    }

    #region 生命周期
    public virtual void OnInit()
    {
    }

    public virtual void OnDestroy()
    {

    }
    #endregion


}
