﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AudioManager : BaseManage{

    private const string path_pre = "Sounds/";
    public const string sound_Alert = "Alert";
    public const string sound_ArrowShoot = "ArrowShoot";
    public const string sound_Bg_fast = "Bg(fast)";
    public const string sound_Bg_moderate = "Bg(moderate)";
    public const string sound_ButtonClick = "ButtonClick";
    public const string sound_Miss = "Miss";
    public const string sound_ShootPerson = "ShootPerson";
    public const string sound_Timer = "Timer";

    private AudioSource BgAudioSource;
    private AudioSource EffectAudioSource;
    public AudioManager(GameFacade gf) : base(gf) { }
    public override void OnInit()
    {
        GameObject audioObject = new GameObject();
        audioObject.name = "AudioManger";
        GameObject.DontDestroyOnLoad(audioObject);
        BgAudioSource = audioObject.AddComponent<AudioSource>();
        EffectAudioSource = audioObject.AddComponent<AudioSource>();
        base.OnInit();
        PlaySound(BgAudioSource, LoadAudioClip(sound_Bg_moderate), true);
    }

    //加载音乐文件
    private AudioClip LoadAudioClip(string clipname)
    {
        AudioClip clip= Resources.Load<AudioClip>(path_pre + clipname);
        return clip;
       
    }

    //播放音乐文件
    private void PlaySound(AudioSource source, AudioClip clip, bool isLoop)
    {
        source.clip = clip;
        source.Play();
        source.loop = isLoop;
    }

    //播放背景音乐
    public  void PlayBgSound(string clipName)
    {
        PlaySound(BgAudioSource, LoadAudioClip(clipName), true);
    }

    //播放其他音效
    public void PlayEffectSound(string clipName)
    {
        PlaySound(EffectAudioSource, LoadAudioClip(clipName), false);
    }

    public void SetSoundIntensity(float value)
    {
        BgAudioSource.volume = value;
        EffectAudioSource.volume = value;
    }

    public float GetSoundIntensity()
    {
        return BgAudioSource.volume;
    }
}
