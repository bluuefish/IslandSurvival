﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Common;

public class PlayerManage : BaseManage
{
    private AccountInfo m_accountInfo;
    private UserInfo m_userInfo;
    public float CurrentRoleMaxHealth { get; private set; }
    public float CurrentRoleHealth { get; private set; }
    public float CurrentGunClipSize { get; private set; }
    public float CurrentGunClip { get; private set; }
    public Sprite CurrentRoleGunIron { get; private set; }
    public bool isUseWeapen { get; private set; }
    public AccountInfo AccountInfo
    {
        get { return m_accountInfo; }
    }
    public UserInfo UserInfo
    {
        get { return m_userInfo; }
    }
    public void SetPlayerInfo(AccountInfo account,UserInfo user)
    {
        m_accountInfo = account;
        m_userInfo = user;

    }
    private UserData userData;
    //玩家的账号信息
    public UserData UserData
    {
        get { return userData; }
        set { userData = value; }
    }
    //游戏的角色信息
    private Dictionary<RoleType, RoleData> roleDic = new Dictionary<RoleType, RoleData>();
    private Transform roleSpawnTran;
    public RoleType CurrentRoleType { get; set; }
    public GameObject CurrentRoleGameObject { get; private set; }
    public GameObject RomateRoleGameObject { get; private set; }
    private GameObject playerSync;
    private RoleActionRequest roleActionRequest;  //向其他客户端发送请求的脚步
    public  CharacterMotor CurrentRolemotor { get; private set; } //当前客户端的角色类
    public  CharacterMotor RomateRoleMotor { get; private set; }   //映射的对方的角色类
    public FreeLookCam lookCam { get; private set; }

    private ShootRequest SR;
    private DamageRequest DR;
    public PlayerManage(GameFacade gf) : base(gf) { }

    public bool isCanDamage = false;

    public override void OnInit()
    {
        roleSpawnTran = GameObject.Find("RoleSpwans").transform;
        base.OnInit();
        InitRoleDic();
    }

    public override void Update()
    {
        if (CurrentRoleGameObject!=null)
        {
           
            CurrentRoleMaxHealth = CurrentRoleGameObject.GetComponent<CharacterHealth>().MaxHealth;
            CurrentRoleHealth = CurrentRoleGameObject.GetComponent<CharacterHealth>().Health;
            isUseWeapen = CurrentRolemotor.Gun == null ? false : true;
            if (isUseWeapen)
            {
                CurrentGunClipSize = CurrentRolemotor.Gun.ClipSize;
                CurrentGunClip = CurrentRolemotor.Gun.Clip;
                CurrentRoleGunIron = CurrentRolemotor.Gun.NameIcon;
            }
        }
       
    }

    private RoleData GetRoleData(RoleType rt)
    {
        RoleData roleData;
        roleDic.TryGetValue(rt, out roleData);
        return roleData;
    }
    //更新玩家数据
    public void UpdateUserData(string total, string win)
    {
        // UserData.totalCount = total.ToString();
        // UserData.winCount = win.ToString();
        UserInfo.TotalCount = int.Parse(total);
        UserInfo.WinCount = int.Parse(win);
    }

    //初始化角色信息
    private void InitRoleDic()
    {
        roleDic.Add(RoleType.Blue, new RoleData(RoleType.Blue, "Prefabs/Hunter_BLUE",/* "Prefabs/BlueArrow", "Prefabs/EXplosion_Blue",*/ roleSpawnTran.Find("Role1")));
        roleDic.Add(RoleType.red, new RoleData(RoleType.red, "Prefabs/Hunter_RED", /*"Prefabs/RedArrow", "Prefabs/EXplosion_Red",*/ roleSpawnTran.Find("Role2")));

    }
    //实例化角色
    public  void SpawnRoles()
    {
        isCanDamage = false;    //设置角色不受伤害计算
        foreach (var role in roleDic.Values)
        {
            GameObject go=GameObject.Instantiate(role.RolePrefab, role.SpawnPos.position, Quaternion.identity);
            //go.transform.SetParent(role.SpawnPos);
            if(role.RoleType==CurrentRoleType)
            {
                go.tag = "Player";
                CurrentRoleGameObject = go;
                CurrentRolemotor = CurrentRoleGameObject.GetComponent<CharacterMotor>();
                CurrentRolemotor.IsLoalRole = true;  
                //RoleActionRequest rr = CurrentRoleGameObject.AddComponent<RoleActionRequest>();
                CurrentRolemotor.SetPlayManage(this);
                CurrentRolemotor.IsCanDamage(isCanDamage);  //设置角色是否会死亡
                // CurrentRolemotor.SetRoleActionRequest(rr);
                lookCam = Camera.main.transform.parent.parent.GetComponent<FreeLookCam>();
                lookCam.m_lockCursor = true;
                Camera.main.transform.parent.parent.GetComponent<FreeLookCam>().SetTarget(go.transform);
                CurrentRoleGameObject.GetComponent<RoleInfo>().isLocalRole = true;
            }
            else
            {
                RomateRoleGameObject = go;
                RomateRoleMotor = RomateRoleGameObject.GetComponent<CharacterMotor>();
                RomateRoleMotor.IsLoalRole =false;
                RomateRoleMotor.SetPlayManage(this);
                RomateRoleMotor.IsCanDamage(isCanDamage);  //设置角色是否会死亡
                RomateRoleGameObject.GetComponent<RoleInfo>().isLocalRole = false;
            }
        }
    }
  
    //添加控制脚本
    public void AddControSpript()
    {
        CharacterControl cc = CurrentRoleGameObject.AddComponent<CharacterControl>();
        CurrentRoleGameObject.AddComponent<DamageRequest>();
        //PlayerMove pm= CurrentRoleGameObject.AddComponent<PlayerMove>();
        //PlayerAttack pa=CurrentRoleGameObject.AddComponent<PlayerAttack>();
        // pa.PlayerMa = this;
        // RoleType rt=CurrentRoleGameObject.GetComponent<RoleInfo>().roleType;
        // RoleData roleData=GetRoleData(rt);
        // pm.speed = 3f;
        //pa.arrowPre = roleData.ArrowPrefab;
    }
    ////添加同步脚本
    //public void AddSyncMove()
    //{
    //    playerSync = new GameObject("playerSync");
    //    MoveRequest MR = playerSync.AddComponent<MoveRequest>();
    //    MR.SetLoaclPlayer(CurrentRoleGameObject.transform, CurrentRoleGameObject.GetComponent<PlayerMove>());
    //    MR.SetRomatePlayer(RomateRoleGameObject.transform, RomateRoleGameObject.GetComponent<Animator>());
    //    SR = playerSync.AddComponent<ShootRequest>();
    //    DR = playerSync.AddComponent<DamageRequest>();
    //    SR.PlayerMan=this;
    //}
    //添加同步脚本
    public void AddSyncRoleAction()
    {
        playerSync = new GameObject("playerSync");
        RoleActionRequest rr = playerSync.AddComponent<RoleActionRequest>();
        StartDepartRequest sr = playerSync.AddComponent<StartDepartRequest>();
        rr.SetLocalMotor(CurrentRolemotor);
        rr.SetRomateMotor(RomateRoleMotor);
        sr.SetLocalMotor(CurrentRolemotor);
        sr.SetRomateMotor(RomateRoleMotor);
        //MoveRequest MR = playerSync.AddComponent<MoveRequest>();
        //MR.SetLoaclPlayer(CurrentRoleGameObject.transform, CurrentRoleGameObject.GetComponent<PlayerMove>());
        //MR.SetRomatePlayer(RomateRoleGameObject.transform, RomateRoleGameObject.GetComponent<Animator>());
        //SR = playerSync.AddComponent<ShootRequest>();
        //DR = playerSync.AddComponent<DamageRequest>();
        //SR.PlayerMan = this;
    }


    public void ShowTakeIron(Vector3 vector)
    {
       BasePanel panel=gameFacade.GetExistPanel(UIPanelType.Game);
        (panel as GamePanel).ShowTakeIronIn(vector);

    }

    public void HidenTakeIron()
    {
        BasePanel panel = gameFacade.GetExistPanel(UIPanelType.Game);
        (panel as GamePanel).HideTakeIronIn();

    }

    //攻击到敌人
    public void AttackEnemy(int mag)
    {
        DR.SendRequest(mag);
    }
    public void Shoot(GameObject arrow,Vector3 pos ,Quaternion quaternion)
    {
        gameFacade.PlayEffectSound(AudioManager.sound_ArrowShoot);
       GameObject arr=GameObject.Instantiate(arrow, pos, quaternion);
        arr.GetComponent<Arrow>().isLocal = true;
        arr.GetComponent<Arrow>().PlayerMan = this;
        SR.SendRequest(arrow.GetComponent<Arrow>().rt, pos, quaternion.eulerAngles);
    }

    public void RomateShoot(RoleType rt, Vector3 pos, Vector3 rot)
    {
        //GameObject arrowPrefab = GetRoleData(rt).ArrowPrefab;
        //GameObject arr=GameObject.Instantiate(arrowPrefab, pos, Quaternion.Euler(rot));
        //arr.GetComponent<Arrow>().isLocal = false;
        //arr.GetComponent<Arrow>().PlayerMan = this;
    }

    public void WhileGameEnd()
    {
        CurrentRolemotor.gameEnd = true;
    }

   //游戏结束对资源的处理
   public void GameOver()
    {
        GameObject.Destroy(CurrentRoleGameObject);
        GameObject.Destroy(RomateRoleGameObject);
        GameObject.Destroy(playerSync);
        roleDic.Clear();
        SR = null;
        DR = null;
    }
}
